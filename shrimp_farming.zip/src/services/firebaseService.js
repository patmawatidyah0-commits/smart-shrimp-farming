import { initializeApp, getApps } from 'firebase/app'
import { getDatabase, ref, push, query, orderByChild, limitToLast, onValue, off } from 'firebase/database'

const firebaseConfig = {
  apiKey: "AIzaSyBs-X8vLW8RsYMVo0fydMkK5qwq1Y10lHs",
  authDomain: "smart-shrimp-farming-a5a9a.firebaseapp.com",
  databaseURL: "https://smart-shrimp-farming-a5a9a-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "smart-shrimp-farming-a5a9a",
  storageBucket: "smart-shrimp-farming-a5a9a.firebasestorage.app",
  messagingSenderId: "33636757064",
  appId: "1:33636757064:web:feb7680c18285247b1327d",
}

let app = null
let db = null
let isConfigured = false

function init() {
  if (app) return
  try {
    const existing = getApps()
    app = existing.length > 0 ? existing[0] : initializeApp(firebaseConfig)
    db = getDatabase(app)
    isConfigured = true
  } catch (e) {
    console.error('[Firebase] Gagal inisialisasi:', e)
    isConfigured = false
  }
}

export async function saveHistoryRecord(record) {
  init()
  if (!isConfigured || !db) return false
  try {
    const historyRef = ref(db, 'tambak/history')
    await push(historyRef, { ...record, timestamp: record.timestamp || Date.now() })
    return true
  } catch (e) {
    return false
  }
}

export function listenHistory(days = 7, onData) {
  init()
  if (!isConfigured || !db) { onData([]); return () => {} }
  const since = Date.now() - days * 24 * 60 * 60 * 1000
  const historyRef = query(ref(db, 'tambak/history'), orderByChild('timestamp'), limitToLast(500))
  const unsubscribe = onValue(historyRef, (snapshot) => {
    const data = snapshot.val()
    if (!data) { onData([]); return }
    const records = Object.entries(data)
      .map(([id, val]) => ({ id, ...val }))
      .filter((r) => r.timestamp >= since)
      .sort((a, b) => b.timestamp - a.timestamp)
    onData(records)
  })
  return () => off(historyRef, 'value', unsubscribe)
}

export function isFirebaseReady() { return isConfigured }
