class SimulatorService {
  constructor() {
    this.timer = null
    this.callback = null
    this.state = {
      device_id: 'ESP32_TAMBAK_01',
      suhu: 28.5, ph: 7.2, jarak_air: 45, status: 'normal',
      do_terlarut: 6.8, salinitas: 18, kekeruhan: 32,
      pompa: false, aerator: true, rpm: 120,
    }
    this.anomaly = null
  }

  start(onTelemetry) {
    this.callback = onTelemetry
    if (this.timer) clearInterval(this.timer)
    this.timer = setInterval(() => this.tick(), 3000)
    this.tick()
  }

  stop() {
    if (this.timer) { clearInterval(this.timer); this.timer = null }
  }

  setAnomaly(type) { this.anomaly = type; this.tick() }

  clearAnomaly() {
    this.anomaly = null
    this.state.suhu = 28.5; this.state.ph = 7.2; this.state.jarak_air = 45
    this.tick()
  }

  setActuatorSilent(command) {
    if (command === 'PUMP_ON') this.state.pompa = true
    else if (command === 'PUMP_OFF') this.state.pompa = false
    else if (command === 'AERATOR_ON') { this.state.aerator = true; this.state.rpm = 120 }
    else if (command === 'AERATOR_OFF') { this.state.aerator = false; this.state.rpm = 0 }
  }

  tick() {
    let s = 28.5 + (Math.sin(Date.now() / 15000) * 0.7) + ((Math.random() - 0.5) * 0.2)
    let p = 7.2 + (Math.cos(Date.now() / 20000) * 0.3) + ((Math.random() - 0.5) * 0.1)
    let j = 45 + Math.round((Math.sin(Date.now() / 30000) * 3) + ((Math.random() - 0.5) * 1.5))
    if (this.state.pompa) j = Math.max(35, j - 4)
    if (this.anomaly === 'HIGH_TEMP') s = 33.4
    else if (this.anomaly === 'LOW_PH') p = 6.1
    else if (this.anomaly === 'LOW_WATER') j = 68
    s = Number(s.toFixed(1)); p = Number(p.toFixed(1)); j = Math.round(j)
    const status = (s > 31.5 || s < 27.0 || p < 6.8 || p > 8.8 || j > 65 || j < 38) ? 'peringatan' : 'normal'
    this.state.suhu = s; this.state.ph = p; this.state.jarak_air = j; this.state.status = status
    if (this.callback) {
      this.callback({
        device_id: this.state.device_id, suhu: s, ph: p, jarak_air: j, status,
        do_terlarut: Number((6.8 + (Math.random() * 0.2 - 0.1)).toFixed(1)),
        salinitas: 18, kekeruhan: 32,
        pompa: this.state.pompa, aerator: this.state.aerator,
        rpm: this.state.rpm, timestamp: Date.now()
      })
    }
  }
}

export const simulatorService = new SimulatorService()
