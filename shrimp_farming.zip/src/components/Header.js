import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function Header({ onOpenNotifications, onOpenSettings }) {
  const { connectionStatus, isSimulator, setIsSimulator, notifications, language } = useApp()
  const unreadCount = notifications.filter((n) => !n.read).length
  const lang = language || 'id'

  return (
    <View style={s.header}>
      {/* Logo + Title */}
      <View style={s.left}>
        <View style={s.logoBox}>
          <Text style={s.logoIcon}>💧</Text>
        </View>
        <View>
          <Text style={s.appName}>{t(lang, 'appName')}</Text>
          <View style={s.statusRow}>
            <View style={[s.dot, { backgroundColor: connectionStatus === 'connected' ? '#0D9488' : '#DC2626' }]} />
            <Text style={s.statusTxt}>
              {connectionStatus === 'connected' ? t(lang, 'esp32Online') : t(lang, 'esp32Connecting')}
            </Text>
          </View>
        </View>
      </View>

      {/* Actions */}
      <View style={s.right}>
        <TouchableOpacity onPress={() => setIsSimulator(!isSimulator)} style={[s.simBtn, isSimulator && s.simBtnActive]}>
          <Text style={[s.simBtnTxt, isSimulator && s.simBtnTxtActive]}>
            {isSimulator ? 'SIM' : 'MQTT'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={onOpenNotifications} style={s.iconBtn}>
          <Text style={s.iconBtnTxt}>🔔</Text>
          {unreadCount > 0 && (
            <View style={s.badge}>
              <Text style={s.badgeTxt}>{unreadCount}</Text>
            </View>
          )}
        </TouchableOpacity>

        <TouchableOpacity onPress={onOpenSettings} style={s.avatarBtn}>
          <Text style={s.avatarTxt}>👤</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const s = StyleSheet.create({
  header: {
    height: 64, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', backgroundColor: '#ffffff',
    borderBottomWidth: 1, borderBottomColor: '#E2E8F0',
  },
  left: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  logoBox: {
    width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#0D9488',
  },
  logoIcon: { fontSize: 20 },
  appName: { fontSize: 14, fontWeight: '800', color: '#0F172A', letterSpacing: -0.2 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 1 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  statusTxt: { fontSize: 10, color: '#64748B', fontFamily: 'monospace' },
  right: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  simBtn: {
    paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10,
    borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#F8FAFC',
  },
  simBtnActive: { backgroundColor: '#CCFBF1', borderColor: '#99F6E4' },
  simBtnTxt: { fontFamily: 'monospace', fontSize: 11, fontWeight: '700', color: '#64748B' },
  simBtnTxtActive: { color: '#0D9488' },
  iconBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  iconBtnTxt: { fontSize: 20 },
  badge: {
    position: 'absolute', top: 4, right: 4, minWidth: 16, height: 16, paddingHorizontal: 4,
    backgroundColor: '#F97316', borderRadius: 999, alignItems: 'center', justifyContent: 'center',
  },
  badgeTxt: { color: '#ffffff', fontSize: 10, fontWeight: '700', fontFamily: 'monospace' },
  avatarBtn: {
    width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#0D9488',
  },
  avatarTxt: { fontSize: 18 },
})
