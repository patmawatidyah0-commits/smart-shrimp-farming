import React, { useState } from 'react'
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform } from 'react-native'
import { useApp } from '../context/AppContext'

export default function LoginModal() {
  const { login } = useApp()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [showForm, setShowForm] = useState(false)

  const handleSubmit = () => {
    if (!email || !password) { setError('Email dan kata sandi wajib diisi'); return }
    const success = login(email, password)
    if (!success) setError('Email atau kata sandi salah')
  }

  const handleQuickLogin = () => login('admin@tambakudang.id', 'password123')

  return (
    <KeyboardAvoidingView style={s.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* Logo */}
      <View style={s.logoSection}>
        <View style={s.logoBox}>
          <Text style={s.logoIcon}>💧</Text>
        </View>
        <Text style={s.appName}>Smart Shrimp</Text>
        <Text style={s.appSub}>Sistem Budidaya Tambak Udang Cerdas</Text>
      </View>

      {/* Card */}
      <View style={s.card}>
        {!showForm ? (
          <>
            <TouchableOpacity onPress={handleQuickLogin} style={s.primaryBtn}>
              <Text style={s.primaryBtnTxt}>🔑 Masuk ke Aplikasi</Text>
            </TouchableOpacity>
            <View style={s.divider}>
              <View style={s.dividerLine} />
              <Text style={s.dividerTxt}>atau masuk dengan akun lain</Text>
              <View style={s.dividerLine} />
            </View>
            <TouchableOpacity onPress={() => setShowForm(true)} style={s.secondaryBtn}>
              <Text style={s.secondaryBtnTxt}>👤 Login Manual</Text>
            </TouchableOpacity>
          </>
        ) : (
          <View style={s.form}>
            <TouchableOpacity onPress={() => { setShowForm(false); setError('') }} style={s.backBtn}>
              <Text style={s.backBtnTxt}>← Kembali</Text>
            </TouchableOpacity>
            {error !== '' && (
              <View style={s.errorBox}>
                <Text style={s.errorTxt}>{error}</Text>
              </View>
            )}
            <View>
              <Text style={s.inputLabel}>Email</Text>
              <TextInput
                style={s.input} value={email} onChangeText={setEmail}
                placeholder="nama@tambakudang.id" keyboardType="email-address"
                autoCapitalize="none" autoComplete="email"
              />
            </View>
            <View>
              <Text style={s.inputLabel}>Kata Sandi</Text>
              <TextInput
                style={s.input} value={password} onChangeText={setPassword}
                placeholder="••••••••" secureTextEntry
                autoComplete="password"
              />
            </View>
            <TouchableOpacity onPress={handleSubmit} style={s.primaryBtn}>
              <Text style={s.primaryBtnTxt}>🔑 Masuk</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <Text style={s.footer}>Smart Shrimp Farming v1.0 · IoT & MQTT</Text>
    </KeyboardAvoidingView>
  )
}

const s = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: '#0D9488', alignItems: 'center',
    justifyContent: 'center', padding: 24,
  },
  logoSection: { alignItems: 'center', marginBottom: 32, gap: 8 },
  logoBox: {
    width: 80, height: 80, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)',
  },
  logoIcon: { fontSize: 44 },
  appName: { fontSize: 24, fontWeight: '800', color: '#ffffff' },
  appSub: { fontSize: 13, color: 'rgba(255,255,255,0.8)' },
  card: {
    width: '100%', backgroundColor: '#ffffff', borderRadius: 24,
    padding: 20, gap: 12,
  },
  primaryBtn: {
    height: 52, borderRadius: 16, backgroundColor: '#0D9488',
    alignItems: 'center', justifyContent: 'center',
  },
  primaryBtnTxt: { fontSize: 15, fontWeight: '700', color: '#ffffff' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dividerLine: { flex: 1, height: 1, backgroundColor: '#E2E8F0' },
  dividerTxt: { fontSize: 11, color: '#94A3B8' },
  secondaryBtn: {
    height: 44, borderRadius: 16, backgroundColor: '#F8FAFC',
    alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: '#E2E8F0',
  },
  secondaryBtnTxt: { fontSize: 13, fontWeight: '700', color: '#0F172A' },
  form: { gap: 12 },
  backBtn: { marginBottom: 4 },
  backBtnTxt: { fontSize: 12, color: '#64748B' },
  errorBox: { padding: 12, borderRadius: 12, backgroundColor: '#FEF2F2', borderWidth: 1, borderColor: '#FECACA' },
  errorTxt: { fontSize: 12, fontWeight: '600', color: '#DC2626' },
  inputLabel: { fontSize: 11, color: '#64748B', fontWeight: '500', marginBottom: 4 },
  input: {
    height: 44, paddingHorizontal: 12, borderRadius: 12,
    backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0',
    fontSize: 14, color: '#0F172A',
  },
  footer: { marginTop: 24, fontSize: 11, color: 'rgba(255,255,255,0.6)' },
})
