import React from 'react'
import { View, Text, TouchableOpacity, ScrollView, Modal, StyleSheet } from 'react-native'
import { useApp } from '../context/AppContext'

const typeIcon = { warning: '⚠️', schedule: '⏰', info: 'ℹ️' }
const typeBg   = { warning: '#FEF9C3', schedule: '#EFF6FF', info: '#DCFCE7' }
const typeColor= { warning: '#CA8A04', schedule: '#2563EB', info: '#16A34A' }

export default function NotificationModal({ isOpen, onClose }) {
  const { notifications, markNotificationAsRead, clearAllNotifications } = useApp()

  return (
    <Modal visible={isOpen} animationType="slide" transparent onRequestClose={onClose}>
      <View style={s.overlay}>
        <TouchableOpacity style={s.backdrop} onPress={onClose} activeOpacity={1} />
        <View style={s.sheet}>
          {/* Handle */}
          <View style={s.handle} />

          {/* Header */}
          <View style={s.header}>
            <View style={s.headerLeft}>
              <Text style={s.headerIcon}>🔔</Text>
              <Text style={s.headerTitle}>Notifikasi Sistem</Text>
              <View style={s.countBadge}>
                <Text style={s.countTxt}>{notifications.length}</Text>
              </View>
            </View>
            <View style={s.headerRight}>
              {notifications.length > 0 && (
                <TouchableOpacity onPress={clearAllNotifications}>
                  <Text style={s.clearTxt}>Hapus Semua</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity onPress={onClose} style={s.closeBtn}>
                <Text style={s.closeTxt}>✕</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* List */}
          <ScrollView style={s.list} contentContainerStyle={s.listContent}>
            {notifications.length === 0 ? (
              <View style={s.empty}>
                <Text style={s.emptyIcon}>🔕</Text>
                <Text style={s.emptyTxt}>Belum ada notifikasi baru.</Text>
              </View>
            ) : (
              notifications.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  onPress={() => markNotificationAsRead(item.id)}
                  style={[s.item, item.read && s.itemRead]}
                  activeOpacity={0.8}
                >
                  <View style={[s.itemIcon, { backgroundColor: typeBg[item.type] || '#F8FAFC' }]}>
                    <Text style={s.itemIconTxt}>{typeIcon[item.type] || 'ℹ️'}</Text>
                  </View>
                  <View style={s.itemBody}>
                    <View style={s.itemRow}>
                      <Text style={s.itemTitle} numberOfLines={1}>{item.title}</Text>
                      <Text style={s.itemTime}>{item.time}</Text>
                    </View>
                    <Text style={s.itemMsg}>{item.message}</Text>
                  </View>
                  {!item.read && <View style={[s.unreadDot, { backgroundColor: typeColor[item.type] || '#0D9488' }]} />}
                </TouchableOpacity>
              ))
            )}
          </ScrollView>

          {/* Footer */}
          <View style={s.footer}>
            <TouchableOpacity onPress={onClose} style={s.closeFullBtn}>
              <Text style={s.closeFullTxt}>Tutup</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  )
}

const s = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end' },
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)' },
  sheet: {
    backgroundColor: '#ffffff', borderTopLeftRadius: 28, borderTopRightRadius: 28,
    maxHeight: '85%', paddingTop: 8,
  },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: '#E2E8F0', alignSelf: 'center', marginBottom: 8 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#E2E8F0',
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerIcon: { fontSize: 20 },
  headerTitle: { fontSize: 16, fontWeight: '700', color: '#0F172A' },
  countBadge: { backgroundColor: '#0D9488', borderRadius: 999, paddingHorizontal: 8, paddingVertical: 2 },
  countTxt: { color: '#fff', fontSize: 11, fontWeight: '700', fontFamily: 'monospace' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  clearTxt: { fontSize: 12, color: '#DC2626', fontWeight: '600' },
  closeBtn: { width: 32, height: 32, borderRadius: 16, backgroundColor: '#F1F5F9', alignItems: 'center', justifyContent: 'center' },
  closeTxt: { fontSize: 14, color: '#64748B' },
  list: { flex: 1 },
  listContent: { padding: 16, gap: 10 },
  empty: { paddingVertical: 48, alignItems: 'center', gap: 8 },
  emptyIcon: { fontSize: 40 },
  emptyTxt: { fontSize: 12, color: '#64748B' },
  item: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12, padding: 14,
    borderRadius: 16, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0',
  },
  itemRead: { opacity: 0.7 },
  itemIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  itemIconTxt: { fontSize: 18 },
  itemBody: { flex: 1 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  itemTitle: { fontSize: 12, fontWeight: '700', color: '#0F172A', flex: 1, marginRight: 8 },
  itemTime: { fontSize: 10, color: '#64748B', fontFamily: 'monospace' },
  itemMsg: { fontSize: 11, color: '#475569', lineHeight: 16 },
  unreadDot: { width: 8, height: 8, borderRadius: 4, marginTop: 4 },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#E2E8F0' },
  closeFullBtn: {
    height: 44, borderRadius: 14, backgroundColor: '#0D9488',
    alignItems: 'center', justifyContent: 'center',
  },
  closeFullTxt: { fontSize: 14, fontWeight: '700', color: '#ffffff' },
})
