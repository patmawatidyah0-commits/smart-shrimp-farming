import React from 'react'
import { View, Text, StyleSheet } from 'react-native'

export default function Sparkline({ data = [], strokeColor = '#0D9488', height = 32 }) {
  if (!data || data.length < 2) {
    return (
      <View style={[styles.container, { height }]}>
        <Text style={styles.loadingTxt}>Mengumpulkan data...</Text>
      </View>
    )
  }

  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const count = data.length

  return (
    <View style={[styles.container, { height }]}>
      <View style={styles.chartRow}>
        {data.map((val, idx) => {
          const ratio = Math.max(0.12, (val - min) / range)
          const barHeight = Math.max(4, Math.round(ratio * (height - 8)))
          const isLast = idx === count - 1

          return (
            <View key={idx} style={styles.barCol}>
              <View
                style={[
                  styles.bar,
                  {
                    height: barHeight,
                    backgroundColor: isLast ? '#0284C7' : strokeColor,
                    opacity: isLast ? 1 : 0.45 + (idx / count) * 0.5,
                  },
                ]}
              />
              {isLast && <View style={[styles.dot, { backgroundColor: strokeColor }]} />}
            </View>
          )
        })}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    justifyContent: 'center',
  },
  loadingTxt: {
    fontSize: 10,
    color: '#94A3B8',
    fontFamily: 'monospace',
  },
  chartRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: '100%',
    paddingVertical: 2,
    gap: 2,
  },
  barCol: {
    flex: 1,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'flex-end',
    position: 'relative',
  },
  bar: {
    width: '75%',
    maxWidth: 6,
    borderRadius: 3,
  },
  dot: {
    position: 'absolute',
    top: 2,
    width: 4,
    height: 4,
    borderRadius: 2,
  },
})

