import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function BottomNav() {
  const { activeTab, setActiveTab, language } = useApp()
  const insets = useSafeAreaInsets()
  const lang = language || 'id'
  const nav = t(lang, 'nav')

  const navItems = [
    { id: 'home',       label: nav.home,      icon: '🏠' },
    { id: 'monitoring', label: nav.monitoring, icon: '📊' },
    { id: 'kontrol',    label: nav.kontrol,    icon: '🎛' },
    { id: 'histori',    label: nav.histori,    icon: '📋' },
    { id: 'panduan',    label: nav.panduan,    icon: '📖' },
    { id: 'profil',     label: nav.profil,     icon: '👤' },
  ]

  return (
    <View style={[s.nav, { paddingBottom: insets.bottom || 8 }]}>
      {navItems.map((item) => {
        const isActive = activeTab === item.id
        return (
          <TouchableOpacity
            key={item.id}
            onPress={() => setActiveTab(item.id)}
            style={s.navItem}
            activeOpacity={0.7}
          >
            {isActive && <View style={s.activeBar} />}
            <View style={[s.iconBox, isActive && s.iconBoxActive]}>
              <Text style={s.icon}>{item.icon}</Text>
            </View>
            <Text style={[s.label, isActive && s.labelActive]}>{item.label}</Text>
          </TouchableOpacity>
        )
      })}
    </View>
  )
}

const s = StyleSheet.create({
  nav: {
    flexDirection: 'row', backgroundColor: '#ffffff',
    borderTopWidth: 1, borderTopColor: '#E2E8F0',
    paddingTop: 4,
  },
  navItem: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingVertical: 4, minHeight: 52, position: 'relative',
  },
  activeBar: {
    position: 'absolute', top: 0, width: 28, height: 3,
    borderBottomLeftRadius: 4, borderBottomRightRadius: 4,
    backgroundColor: '#0D9488',
  },
  iconBox: {
    width: 32, height: 32, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  iconBoxActive: { backgroundColor: '#CCFBF1' },
  icon: { fontSize: 16 },
  label: { fontSize: 10, fontWeight: '700', color: '#94A3B8', marginTop: 1 },
  labelActive: { color: '#0D9488' },
})
