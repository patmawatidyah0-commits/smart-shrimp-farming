import React, { useState } from 'react'
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Switch,
  StyleSheet,
  Alert,
} from 'react-native'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function ProfileScreen() {
  const {
    user,
    thresholds,
    setThresholds,
    brokerConfig,
    setBrokerConfig,
    isSimulator,
    setIsSimulator,
    logout,
    language,
  } = useApp()

  const lang = language || 'id'
  const [tempTh, setTempTh] = useState({ ...thresholds })
  const [tempBroker, setTempBroker] = useState({ ...brokerConfig })
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setThresholds(tempTh)
    setBrokerConfig(tempBroker)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const handleLogout = () => {
    Alert.alert(
      'Konfirmasi Keluar',
      'Apakah Anda yakin ingin keluar dari akun?',
      [
        { text: 'Batal', style: 'cancel' },
        { text: 'Keluar', style: 'destructive', onPress: logout },
      ]
    )
  }

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.container} showsVerticalScrollIndicator={false}>
      <View style={s.header}>
        <Text style={s.title}>{t(lang, 'profileTitle')}</Text>
        <Text style={s.sub}>{t(lang, 'profileSub')}</Text>
      </View>

      {/* User Card */}
      <View style={s.userCard}>
        <View style={s.userAvatar}>
          <Text style={{ fontSize: 24, color: '#ffffff' }}>👤</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={s.userName}>{user.name}</Text>
          <Text style={s.userRole}>{user.role}</Text>
          <Text style={s.userEmail}>{user.email}</Text>
        </View>
        <TouchableOpacity onPress={handleLogout} style={s.logoutBtn} activeOpacity={0.8}>
          <Text style={s.logoutTxt}>🚪</Text>
        </TouchableOpacity>
      </View>

      {/* Team Card */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: '#F0FDF4' }]}>
          <Text style={{ fontSize: 16 }}>👥</Text>
          <Text style={s.cardHeaderTitle}>{t(lang, 'team')}</Text>
        </View>
        <View style={s.cardBody}>
          {user.team.map((member, i) => (
            <View key={i} style={s.teamItem}>
              <View style={s.memberInitial}>
                <Text style={s.memberInitialTxt}>{member.name.charAt(0)}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.memberName}>{member.name}</Text>
                <Text style={s.memberRole}>{member.role}</Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* Development Sprints Timeline */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: '#F5F3FF' }]}>
          <Text style={{ fontSize: 16 }}>📊</Text>
          <Text style={s.cardHeaderTitle}>{t(lang, 'timeline')}</Text>
        </View>
        <View style={s.cardBody}>
          {t(lang, 'sprints').map((sprint, i) => (
            <View key={i} style={s.timelineItem}>
              <Text style={s.timelineLabel}>{sprint.label}</Text>
              <View style={[s.statusBadge, { backgroundColor: sprint.bg }]}>
                <Text style={[s.statusBadgeTxt, { color: sprint.color }]}>
                  {sprint.status}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* Sensor Thresholds Configuration Card */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: '#F0FDFA' }]}>
          <Text style={{ fontSize: 16 }}>⚙️</Text>
          <View style={{ flex: 1 }}>
            <Text style={s.cardHeaderTitle}>{t(lang, 'threshold')}</Text>
            <Text style={s.cardHeaderSub}>{t(lang, 'thresholdSub')}</Text>
          </View>
        </View>

        <View style={s.cardBody}>
          <View style={s.inputsGrid}>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'tempMin')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempTh.suhuMin)}
                onChangeText={(v) => setTempTh({ ...tempTh, suhuMin: parseFloat(v) || 0 })}
              />
            </View>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'tempMax')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempTh.suhuMax)}
                onChangeText={(v) => setTempTh({ ...tempTh, suhuMax: parseFloat(v) || 0 })}
              />
            </View>
          </View>

          <View style={s.inputsGrid}>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'phMin')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempTh.phMin)}
                onChangeText={(v) => setTempTh({ ...tempTh, phMin: parseFloat(v) || 0 })}
              />
            </View>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'phMax')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempTh.phMax)}
                onChangeText={(v) => setTempTh({ ...tempTh, phMax: parseFloat(v) || 0 })}
              />
            </View>
          </View>

          <View style={s.inputsGrid}>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'waterMin')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempTh.jarakMin)}
                onChangeText={(v) => setTempTh({ ...tempTh, jarakMin: parseInt(v, 10) || 0 })}
              />
            </View>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'waterMax')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempTh.jarakMax)}
                onChangeText={(v) => setTempTh({ ...tempTh, jarakMax: parseInt(v, 10) || 0 })}
              />
            </View>
          </View>
        </View>
      </View>

      {/* MQTT Broker Configuration Card */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: '#EFF6FF' }]}>
          <Text style={{ fontSize: 16 }}>📡</Text>
          <Text style={s.cardHeaderTitle}>{t(lang, 'mqttConfig')}</Text>
        </View>

        <View style={s.cardBody}>
          {/* Simulator Toggle */}
          <View style={s.simToggleRow}>
            <View style={{ flex: 1 }}>
              <Text style={s.simToggleTitle}>{t(lang, 'useSimulator')}</Text>
              <Text style={s.simToggleSub}>{t(lang, 'useSimulatorSub')}</Text>
            </View>
            <Switch
              value={isSimulator}
              onValueChange={setIsSimulator}
              trackColor={{ false: '#CBD5E1', true: '#0D9488' }}
              thumbColor="#ffffff"
            />
          </View>

          {/* Broker Host */}
          <View style={s.fieldGroup}>
            <Text style={s.inputLabel}>{t(lang, 'brokerHost')}</Text>
            <TextInput
              style={s.textInput}
              value={tempBroker.host}
              onChangeText={(v) => setTempBroker({ ...tempBroker, host: v })}
            />
          </View>

          {/* Port and Path */}
          <View style={s.inputsGrid}>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'portWs')}</Text>
              <TextInput
                style={s.textInput}
                keyboardType="numeric"
                value={String(tempBroker.port)}
                onChangeText={(v) => setTempBroker({ ...tempBroker, port: parseInt(v, 10) || 8084 })}
              />
            </View>
            <View style={s.inputCol}>
              <Text style={s.inputLabel}>{t(lang, 'path')}</Text>
              <TextInput
                style={s.textInput}
                value={tempBroker.path}
                onChangeText={(v) => setTempBroker({ ...tempBroker, path: v })}
              />
            </View>
          </View>

          {/* Topics */}
          <View style={s.fieldGroup}>
            <Text style={s.inputLabel}>{t(lang, 'topicSensor')}</Text>
            <TextInput
              style={s.textInput}
              value={tempBroker.topicSensor}
              onChangeText={(v) => setTempBroker({ ...tempBroker, topicSensor: v })}
            />
          </View>

          <View style={s.fieldGroup}>
            <Text style={s.inputLabel}>{t(lang, 'topicControl')}</Text>
            <TextInput
              style={s.textInput}
              value={tempBroker.topicControl}
              onChangeText={(v) => setTempBroker({ ...tempBroker, topicControl: v })}
            />
          </View>
        </View>
      </View>

      {/* Success Notification Alert */}
      {saved && (
        <View style={s.saveAlert}>
          <Text style={{ fontSize: 16 }}>✅</Text>
          <Text style={s.saveAlertTxt}>{t(lang, 'saveSuccess')}</Text>
        </View>
      )}

      {/* Save Button */}
      <TouchableOpacity onPress={handleSave} style={s.saveBtn} activeOpacity={0.8}>
        <Text style={{ fontSize: 16, color: '#ffffff' }}>💾</Text>
        <Text style={s.saveBtnTxt}>{t(lang, 'saveBtn')}</Text>
      </TouchableOpacity>
    </ScrollView>
  )
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { padding: 16, paddingBottom: 28 },
  header: { marginBottom: 16 },
  title: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 2 },
  sub: { fontSize: 12, color: '#64748B' },
  userCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderRadius: 20,
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginBottom: 14,
  },
  userAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: '#0D9488',
    alignItems: 'center',
    justifyContent: 'center',
  },
  userName: { fontSize: 15, fontWeight: '700', color: '#0F172A' },
  userRole: { fontSize: 12, color: '#64748B', marginTop: 1 },
  userEmail: { fontFamily: 'monospace', fontSize: 11, color: '#0D9488', marginTop: 2 },
  logoutBtn: {
    padding: 10,
    borderRadius: 12,
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  logoutTxt: { fontSize: 18 },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#ffffff',
    overflow: 'hidden',
    marginBottom: 14,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  cardHeaderTitle: { fontSize: 14, fontWeight: '700', color: '#0F172A' },
  cardHeaderSub: { fontFamily: 'monospace', fontSize: 10, color: '#64748B', marginTop: 1 },
  cardBody: { padding: 14, gap: 10 },
  teamItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 10,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  memberInitial: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: '#0D9488',
    alignItems: 'center',
    justifyContent: 'center',
  },
  memberInitialTxt: { fontSize: 13, fontWeight: '800', color: '#ffffff' },
  memberName: { fontSize: 13, fontWeight: '700', color: '#0F172A' },
  memberRole: { fontSize: 11, color: '#64748B', marginTop: 1 },
  timelineItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  timelineLabel: { fontSize: 12, fontWeight: '600', color: '#0F172A', flex: 1, marginRight: 8 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999 },
  statusBadgeTxt: { fontFamily: 'monospace', fontSize: 9, fontWeight: '700' },
  inputsGrid: { flexDirection: 'row', gap: 10 },
  inputCol: { flex: 1 },
  fieldGroup: { marginBottom: 2 },
  inputLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B',
    marginBottom: 4,
  },
  textInput: {
    height: 42,
    paddingHorizontal: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#F8FAFC',
    fontFamily: 'monospace',
    fontSize: 12,
    color: '#0F172A',
  },
  simToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    borderRadius: 14,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginBottom: 4,
  },
  simToggleTitle: { fontSize: 13, fontWeight: '700', color: '#0F172A' },
  simToggleSub: { fontSize: 11, color: '#64748B', marginTop: 1 },
  saveAlert: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 14,
    backgroundColor: '#DCFCE7',
    borderWidth: 1,
    borderColor: '#86EFAC',
    marginBottom: 12,
  },
  saveAlertTxt: { flex: 1, fontSize: 12, fontWeight: '600', color: '#16A34A' },
  saveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 50,
    borderRadius: 16,
    backgroundColor: '#0D9488',
    marginBottom: 12,
  },
  saveBtnTxt: { fontSize: 14, fontWeight: '700', color: '#ffffff' },
})

