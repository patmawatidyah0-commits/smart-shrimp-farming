import React, { useState } from 'react'
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function MonitoringScreen() {
  const { telemetry, history, thresholds, language } = useApp()
  const lang = language || 'id'
  const [sel, setSel] = useState('suhu')

  const configs = {
    suhu: {
      label: t(lang, 'tempWater'),
      unit: '°C',
      sensor: 'DS18B20 Digital',
      min: thresholds.suhuMin,
      max: thresholds.suhuMax,
      color: '#0D9488',
      bg: '#CCFBF1',
      icon: '🌡',
      ex: (d) => d.suhu,
      desc: t(lang, 'suhuDesc'),
    },
    ph: {
      label: t(lang, 'phWater'),
      unit: 'pH',
      sensor: 'Analog pH Probe',
      min: thresholds.phMin,
      max: thresholds.phMax,
      color: '#7C3AED',
      bg: '#EDE9FE',
      icon: '💧',
      ex: (d) => d.ph,
      desc: t(lang, 'phDesc'),
    },
    jarak_air: {
      label: t(lang, 'waterLevel'),
      unit: 'cm',
      sensor: 'HC-SR04',
      min: thresholds.jarakMin,
      max: thresholds.jarakMax,
      color: '#2563EB',
      bg: '#DBEAFE',
      icon: '🌊',
      ex: (d) => d.jarak_air,
      desc: t(lang, 'jarakDesc'),
    },
  }

  const cfg = configs[sel]
  const values = history.slice(0, 20).reverse().map(cfg.ex)
  const minVal = values.length ? Math.min(...values) : cfg.min
  const maxVal = values.length ? Math.max(...values) : cfg.max
  const avgVal = values.length ? (values.reduce((a, b) => a + b, 0) / values.length).toFixed(1) : 0
  const curVal = cfg.ex(telemetry)
  const isOk = curVal >= cfg.min && curVal <= cfg.max

  // Chart range calculations
  const displayMin = Math.min(minVal, cfg.min - 0.5)
  const displayMax = Math.max(maxVal, cfg.max + 0.5)
  const range = displayMax - displayMin || 1

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.container} showsVerticalScrollIndicator={false}>
      <Text style={s.title}>{t(lang, 'monitorTitle')}</Text>
      <Text style={s.sub}>{t(lang, 'monitorSub')}</Text>

      {/* Selector Tabs */}
      <View style={s.selectorRow}>
        {Object.entries(configs).map(([key, c]) => {
          const v = c.ex(telemetry)
          const ok = v >= c.min && v <= c.max
          const active = sel === key
          return (
            <TouchableOpacity
              key={key}
              onPress={() => setSel(key)}
              style={[s.selectorBtn, active && { backgroundColor: c.color, borderColor: c.color }]}
              activeOpacity={0.8}
            >
              <Text style={{ fontSize: 20 }}>{c.icon}</Text>
              <Text style={[s.selectorLabel, active && { color: '#ffffff' }]}>{c.label}</Text>
              <Text style={[s.selectorVal, active && { color: '#ffffff' }]}>{v}</Text>
              <View
                style={[
                  s.selectorBadge,
                  {
                    backgroundColor: ok
                      ? active
                        ? 'rgba(255,255,255,0.25)'
                        : '#DCFCE7'
                      : '#FEE2E2',
                  },
                ]}
              >
                <Text
                  style={{
                    fontFamily: 'monospace',
                    fontSize: 9,
                    fontWeight: '700',
                    color: ok ? (active ? '#ffffff' : '#16A34A') : '#DC2626',
                  }}
                >
                  {ok ? 'OK' : t(lang, 'warn')}
                </Text>
              </View>
            </TouchableOpacity>
          )
        })}
      </View>

      {/* Main Chart Card */}
      <View style={s.card}>
        <View style={[s.cardTop, { backgroundColor: cfg.bg }]}>
          <View style={s.cardTopLeft}>
            <View style={[s.iconBox, { backgroundColor: cfg.color }]}>
              <Text style={{ fontSize: 22 }}>{cfg.icon}</Text>
            </View>
            <View>
              <Text style={s.cardTitle}>{cfg.label}</Text>
              <Text style={s.cardSensor}>{cfg.sensor}</Text>
            </View>
          </View>
          <View style={s.cardTopRight}>
            <Text style={[s.curVal, { color: cfg.color }]}>
              {curVal}
              <Text style={s.curUnit}> {cfg.unit}</Text>
            </Text>
            <View style={[s.statusBadge, { backgroundColor: isOk ? cfg.color : '#DC2626' }]}>
              <Text style={s.statusBadgeTxt}>{isOk ? 'NORMAL' : 'WARNING'}</Text>
            </View>
          </View>
        </View>

        <Text style={s.desc}>{cfg.desc}</Text>

        {/* Visual Trend Chart */}
        <View style={s.chartContainer}>
          <View style={s.chartHeader}>
            <Text style={s.chartLegend}>
              {t(lang, 'idealZone', cfg.min, cfg.max, cfg.unit)}
            </Text>
            <Text style={s.chartSub}>{values.length} {t(lang, 'points')}</Text>
          </View>

          {/* Chart Board */}
          <View style={s.chartBoard}>
            {/* Safe Range Zone Background Band */}
            <View
              style={[
                s.safeBand,
                {
                  bottom: `${Math.max(0, ((cfg.min - displayMin) / range) * 100)}%`,
                  height: `${Math.min(100, Math.max(12, ((cfg.max - cfg.min) / range) * 100))}%`,
                  backgroundColor: cfg.color + '15',
                  borderColor: cfg.color + '40',
                },
              ]}
            >
              <View style={s.safeBandLabelRow}>
                <Text style={[s.safeBandLabel, { color: cfg.color }]}>
                  Batas Aman ({cfg.min} - {cfg.max} {cfg.unit})
                </Text>
              </View>
            </View>

            {/* Data Columns */}
            <View style={s.columnsRow}>
              {values.map((v, i) => {
                const ratio = Math.max(0.08, Math.min(1, (v - displayMin) / range))
                const isLatest = i === values.length - 1
                const inSafe = v >= cfg.min && v <= cfg.max

                return (
                  <View key={i} style={s.colItem}>
                    <View
                      style={[
                        s.colBar,
                        {
                          height: `${Math.round(ratio * 100)}%`,
                          backgroundColor: isLatest
                            ? cfg.color
                            : inSafe
                            ? cfg.color + '80'
                            : '#EF4444',
                        },
                      ]}
                    />
                    {isLatest && (
                      <View style={[s.activeDotRing, { borderColor: cfg.color }]}>
                        <View style={[s.activeDot, { backgroundColor: cfg.color }]} />
                      </View>
                    )}
                  </View>
                )
              })}
            </View>
          </View>
        </View>

        {/* Summary Stats Row (Min, Avg, Max) */}
        <View style={s.statsRow}>
          {[
            { label: t(lang, 'min'), val: minVal, accent: false },
            { label: t(lang, 'avg'), val: avgVal, accent: true },
            { label: t(lang, 'max'), val: maxVal, accent: false },
          ].map((stat, i) => (
            <View key={i} style={[s.statBox, stat.accent && { backgroundColor: cfg.bg, borderColor: cfg.color + '40' }]}>
              <Text style={s.statLabel}>{stat.label}</Text>
              <Text style={[s.statVal, stat.accent && { color: cfg.color }]}>{stat.val}</Text>
              <Text style={s.statUnit}>{cfg.unit}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Sensor Specs */}
      <View style={s.card}>
        <Text style={s.specTitle}>⚙ {t(lang, 'sensorSpec')}</Text>
        {t(lang, 'sensorRows').map(([label, val], i, arr) => (
          <View key={i} style={[s.specRow, i < arr.length - 1 && s.specRowBorder]}>
            <Text style={s.specLabel}>{label}</Text>
            <Text style={s.specVal}>{val}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  )
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { padding: 16, paddingBottom: 24 },
  title: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 2 },
  sub: { fontSize: 12, color: '#64748B', marginBottom: 16 },
  selectorRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  selectorBtn: {
    flex: 1,
    padding: 12,
    borderRadius: 16,
    alignItems: 'center',
    gap: 4,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#ffffff',
  },
  selectorLabel: { fontSize: 10, fontWeight: '600', color: '#64748B' },
  selectorVal: { fontSize: 15, fontWeight: '800', color: '#0F172A' },
  selectorBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999 },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#ffffff',
    marginBottom: 12,
    overflow: 'hidden',
  },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16 },
  cardTopLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  cardTitle: { fontSize: 14, fontWeight: '700', color: '#0F172A' },
  cardSensor: { fontFamily: 'monospace', fontSize: 10, color: '#64748B', marginTop: 1 },
  cardTopRight: { alignItems: 'flex-end' },
  curVal: { fontSize: 28, fontWeight: '800' },
  curUnit: { fontSize: 14, color: '#64748B', fontWeight: '400' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 2, borderRadius: 999, marginTop: 2 },
  statusBadgeTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', color: '#ffffff' },
  desc: { fontSize: 12, color: '#334155', padding: 16, paddingTop: 10, paddingBottom: 8 },
  chartContainer: { paddingHorizontal: 16, paddingBottom: 14 },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  chartLegend: { fontSize: 11, fontWeight: '600', color: '#475569' },
  chartSub: { fontFamily: 'monospace', fontSize: 10, color: '#94A3B8' },
  chartBoard: {
    height: 130,
    backgroundColor: '#F8FAFC',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    position: 'relative',
    overflow: 'hidden',
    justifyContent: 'flex-end',
  },
  safeBand: {
    position: 'absolute',
    left: 0,
    right: 0,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderStyle: 'dashed',
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  safeBandLabelRow: { opacity: 0.8 },
  safeBandLabel: { fontFamily: 'monospace', fontSize: 9, fontWeight: '700' },
  columnsRow: {
    flexDirection: 'row',
    height: '100%',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    paddingBottom: 6,
    zIndex: 2,
    gap: 3,
  },
  colItem: {
    flex: 1,
    height: '100%',
    alignItems: 'center',
    justifyContent: 'flex-end',
    position: 'relative',
  },
  colBar: {
    width: '80%',
    maxWidth: 8,
    borderRadius: 4,
  },
  activeDotRing: {
    position: 'absolute',
    top: 2,
    width: 10,
    height: 10,
    borderRadius: 5,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
  },
  activeDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  statsRow: { flexDirection: 'row', gap: 10, padding: 16, paddingTop: 0 },
  statBox: {
    flex: 1,
    alignItems: 'center',
    padding: 12,
    borderRadius: 14,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  statLabel: { fontSize: 10, color: '#64748B' },
  statVal: { fontSize: 16, fontWeight: '800', color: '#0F172A', marginTop: 2 },
  statUnit: { fontFamily: 'monospace', fontSize: 9, color: '#64748B' },
  specTitle: { fontSize: 14, fontWeight: '700', color: '#0F172A', padding: 16 },
  specRow: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 16, paddingVertical: 10 },
  specRowBorder: { borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  specLabel: { fontSize: 12, color: '#64748B' },
  specVal: { fontFamily: 'monospace', fontSize: 11, fontWeight: '600', color: '#0F172A' },
})

