import React, { useState } from 'react'
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

const colorMap = [
  { bg: '#EFF6FF', text: '#2563EB', border: '#BFDBFE', btnBg: '#2563EB', stepBg: '#F8FAFC' },
  { bg: '#CCFBF1', text: '#0D9488', border: '#99F6E4', btnBg: '#0D9488', stepBg: '#F0FDFA' },
  { bg: '#FFF7ED', text: '#F97316', border: '#FED7AA', btnBg: '#F97316', stepBg: '#FFFBEB' },
  { bg: '#EDE9FE', text: '#7C3AED', border: '#DDD6FE', btnBg: '#7C3AED', stepBg: '#F5F3FF' },
  { bg: '#FEF2F2', text: '#DC2626', border: '#FECACA', btnBg: '#DC2626', stepBg: '#FEF2F2' },
]

const tabIcons = {
  beranda: '🏠',
  monitoring: '📊',
  kontrol: '🎛',
  histori: '📋',
  notifikasi: '🔔',
}

const stepIcons = {
  monitor_heart: '💓',
  thermostat: '🌡',
  waves: '🌊',
  electrical_services: '⚡',
  analytics: '📈',
  show_chart: '📊',
  summarize: '📑',
  smart_toy: '🤖',
  tune: '🎛',
  mode_fan: '🌀',
  water_pump: '💧',
  science: '🧪',
  calendar_today: '📅',
  filter_list: '🔍',
  search: '🔎',
  download: '📥',
  warning: '⚠️',
  info: 'ℹ️',
  done_all: '✓',
  delete: '🗑',
}

export default function GuideScreen() {
  const { language, setLanguage } = useApp()
  const lang = language || 'id'
  const [activeIdx, setActiveIdx] = useState(0)

  const pages = t(lang, 'guidePages') || []
  const tips = t(lang, 'tips') || []
  const current = pages[activeIdx] || pages[0]
  const c = colorMap[activeIdx] || colorMap[0]

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={s.headerRow}>
        <View style={{ flex: 1 }}>
          <Text style={s.title}>{t(lang, 'guideTitle')}</Text>
          <Text style={s.sub}>{t(lang, 'guideSub')}</Text>
        </View>

        {/* Language Toggle */}
        <View style={s.langToggle}>
          {['id', 'en'].map((l) => {
            const isL = lang === l
            return (
              <TouchableOpacity
                key={l}
                onPress={() => setLanguage(l)}
                style={[s.langBtn, isL && s.langBtnActive]}
                activeOpacity={0.8}
              >
                <Text style={[s.langTxt, isL && s.langTxtActive]}>
                  {l === 'id' ? '🇮🇩 ID' : '🇬🇧 EN'}
                </Text>
              </TouchableOpacity>
            )
          })}
        </View>
      </View>

      {/* Horizontal Category Tabs */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={s.tabsScroll}
        style={s.tabsWrap}
      >
        {pages.map((g, i) => {
          const col = colorMap[i] || colorMap[0]
          const isActive = activeIdx === i
          const icon = tabIcons[g.id] || '📖'

          return (
            <TouchableOpacity
              key={g.id}
              onPress={() => setActiveIdx(i)}
              style={[
                s.catTab,
                {
                  backgroundColor: isActive ? col.btnBg : '#ffffff',
                  borderColor: isActive ? col.btnBg : col.border,
                },
              ]}
              activeOpacity={0.8}
            >
              <Text style={{ fontSize: 14 }}>{icon}</Text>
              <Text
                style={[
                  s.catLabel,
                  { color: isActive ? '#ffffff' : col.text },
                ]}
              >
                {g.title}
              </Text>
            </TouchableOpacity>
          )
        })}
      </ScrollView>

      {/* Guide Content Card */}
      {current && (
        <View style={[s.card, { borderColor: c.border }]}>
          {/* Card Header */}
          <View style={[s.cardTop, { backgroundColor: c.bg, borderBottomColor: c.border }]}>
            <View style={[s.cardIconBox, { backgroundColor: c.btnBg }]}>
              <Text style={{ fontSize: 24 }}>{tabIcons[current.id] || '📖'}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.cardTitle}>{current.title}</Text>
              <Text style={s.cardSub}>
                {current.steps.length} {lang === 'en' ? 'guide steps' : 'langkah panduan'}
              </Text>
            </View>
          </View>

          {/* Steps List */}
          <View style={s.stepsList}>
            {current.steps.map((step, i) => {
              const icon = stepIcons[step.icon] || '👉'
              return (
                <View
                  key={i}
                  style={[s.stepItem, { backgroundColor: c.stepBg, borderColor: c.border }]}
                >
                  <View style={[s.stepBadge, { backgroundColor: c.btnBg }]}>
                    <Text style={s.stepIconTxt}>{icon}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[s.stepNumber, { color: c.text }]}>#{i + 1}</Text>
                    <Text style={s.stepText}>{step.text}</Text>
                  </View>
                </View>
              )
            })}
          </View>
        </View>
      )}

      {/* Quick Tips Card */}
      <View style={s.tipsCard}>
        <View style={s.tipsHeader}>
          <Text style={{ fontSize: 18 }}>💡</Text>
          <Text style={s.tipsTitle}>{t(lang, 'tipsTitle')}</Text>
        </View>
        <View style={s.tipsBody}>
          {tips.map((tip, i) => (
            <View key={i} style={s.tipItem}>
              <Text style={s.tipArrow}>›</Text>
              <Text style={s.tipText}>{tip}</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  )
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { padding: 16, paddingBottom: 28 },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  title: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 2 },
  sub: { fontSize: 12, color: '#64748B' },
  langToggle: {
    flexDirection: 'row',
    padding: 3,
    backgroundColor: '#ffffff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    gap: 4,
  },
  langBtn: {
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  langBtnActive: {
    backgroundColor: '#0D9488',
  },
  langTxt: { fontSize: 11, fontWeight: '700', color: '#64748B' },
  langTxtActive: { color: '#ffffff' },
  tabsWrap: { marginBottom: 16 },
  tabsScroll: { gap: 8, paddingRight: 8 },
  catTab: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  catLabel: { fontSize: 12, fontWeight: '700' },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    backgroundColor: '#ffffff',
    overflow: 'hidden',
    marginBottom: 14,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderBottomWidth: 1,
  },
  cardIconBox: {
    width: 46,
    height: 46,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardTitle: { fontSize: 15, fontWeight: '700', color: '#0F172A' },
  cardSub: { fontSize: 11, color: '#64748B', marginTop: 1 },
  stepsList: { padding: 14, gap: 10 },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
  },
  stepBadge: {
    width: 28,
    height: 28,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 1,
  },
  stepIconTxt: { fontSize: 14, color: '#ffffff' },
  stepNumber: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', marginBottom: 2 },
  stepText: { fontSize: 12, color: '#0F172A', lineHeight: 18 },
  tipsCard: {
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#FED7AA',
    backgroundColor: '#ffffff',
    overflow: 'hidden',
  },
  tipsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFF7ED',
    borderBottomWidth: 1,
    borderBottomColor: '#FED7AA',
  },
  tipsTitle: { fontSize: 14, fontWeight: '700', color: '#0F172A' },
  tipsBody: { padding: 12, gap: 8 },
  tipItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    padding: 10,
    borderRadius: 12,
    backgroundColor: '#FFFBEB',
    borderWidth: 1,
    borderColor: '#FEF3C7',
  },
  tipArrow: { fontSize: 16, color: '#F97316', fontWeight: '800', lineHeight: 16 },
  tipText: { flex: 1, fontSize: 12, color: '#334155', lineHeight: 17 },
})

