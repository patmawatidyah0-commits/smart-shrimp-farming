import React, { useState, useMemo } from 'react'
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, Alert, Share } from 'react-native'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

function startOfDay(date) { const d = new Date(date); d.setHours(0, 0, 0, 0); return d.getTime() }
function getDayRange(key) {
  const now = Date.now(), todayStart = startOfDay(now)
  switch (key) {
    case 'today': return { from: todayStart, to: now }
    case 'yesterday': return { from: todayStart - 86400000, to: todayStart - 1 }
    case '3days': return { from: todayStart - 2 * 86400000, to: now }
    case '7days': return { from: todayStart - 6 * 86400000, to: now }
    default: return { from: 0, to: now }
  }
}
function bucketKey(ts, g) {
  const d = new Date(ts)
  switch (g) {
    case 'second': return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}-${d.getMinutes()}-${d.getSeconds()}`
    case 'minute': return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}-${d.getMinutes()}`
    case 'hour': return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}`
    default: return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
  }
}
function groupHistory(history, g) {
  const buckets = new Map()
  for (const item of history) {
    const k = bucketKey(item.timestamp, g)
    if (!buckets.has(k)) buckets.set(k, [])
    buckets.get(k).push(item)
  }
  return Array.from(buckets.values()).map((group) => {
    const count = group.length
    return { id: group[0].id, timestamp: group[0].timestamp, suhu: Number((group.reduce((s, i) => s + i.suhu, 0) / count).toFixed(1)), ph: Number((group.reduce((s, i) => s + i.ph, 0) / count).toFixed(1)), jarak_air: Math.round(group.reduce((s, i) => s + i.jarak_air, 0) / count), status: group.some(i => i.status !== 'normal') ? 'peringatan' : 'normal', count }
  })
}
function formatLabel(ts, g, lang) {
  const d = new Date(ts)
  const locale = lang === 'en' ? 'en-US' : 'id-ID'
  switch (g) {
    case 'second': return d.toLocaleTimeString(locale)
    case 'minute': return d.toLocaleString(locale, { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
    case 'hour': return d.toLocaleString(locale, { day: '2-digit', month: 'short', hour: '2-digit' }) + ':00'
    default: return d.toLocaleDateString(locale, { weekday: 'long', day: '2-digit', month: 'long' })
  }
}

export default function HistoryScreen() {
  const { history, firebaseHistory, useFirebase, clearHistory, language } = useApp()
  const lang = language || 'id'
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [granularity, setGranularity] = useState('minute')
  const [dayFilter, setDayFilter] = useState('today')
  const [search, setSearch] = useState('')

  const GRAN = [{ key: 'second', label: t(lang,'second') }, { key: 'minute', label: t(lang,'minute') }, { key: 'hour', label: t(lang,'hour') }, { key: 'day', label: t(lang,'day') }]
  const DAY = [{ key: 'today', label: t(lang,'today') }, { key: 'yesterday', label: t(lang,'yesterday') }, { key: '3days', label: t(lang,'days3') }, { key: '7days', label: t(lang,'days7') }, { key: 'all', label: t(lang,'all') }]

  const allHistory = useMemo(() => {
    if (useFirebase && firebaseHistory.length > 0) {
      const ids = new Set(history.map(h => h.id))
      return [...history, ...firebaseHistory.filter(h => !ids.has(h.id))].sort((a, b) => b.timestamp - a.timestamp)
    }
    return history
  }, [history, firebaseHistory, useFirebase])

  const dayFiltered = useMemo(() => { const { from, to } = getDayRange(dayFilter); return allHistory.filter(h => h.timestamp >= from && h.timestamp <= to) }, [allHistory, dayFilter])
  const grouped = useMemo(() => groupHistory(dayFiltered, granularity), [dayFiltered, granularity])
  const filtered = useMemo(() => grouped.filter(item => {
    const ms = statusFilter === 'ALL' ? true : statusFilter === 'NORMAL' ? item.status === 'normal' : item.status !== 'normal'
    const ms2 = search === '' || item.id.toLowerCase().includes(search.toLowerCase()) || item.suhu.toString().includes(search) || item.ph.toString().includes(search)
    return ms && ms2
  }), [grouped, statusFilter, search])

  const handleExportCSV = async () => {
    if (filtered.length === 0) {
      Alert.alert('Info', 'Tidak ada data untuk diekspor.')
      return
    }
    const headers = 'ID,Waktu,Suhu (C),pH,Ketinggian (cm),Status\n'
    const rows = filtered
      .map(
        (item) =>
          `"${item.id}","${new Date(item.timestamp).toISOString()}","${item.suhu}","${item.ph}","${item.jarak_air}","${item.status}"`
      )
      .join('\n')
    const csvContent = headers + rows

    try {
      await Share.share({
        title: 'Export Telemetri Tambak Udang',
        message: csvContent,
      })
    } catch (e) {
      Alert.alert('Error', 'Gagal membagikan file CSV.')
    }
  }

  const normalCount = filtered.filter(h => h.status === 'normal').length
  const warningCount = filtered.filter(h => h.status !== 'normal').length

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.container} showsVerticalScrollIndicator={false}>
      <View style={s.titleRow}>
        <View>
          <Text style={s.title}>{t(lang,'historyTitle')}</Text>
          <Text style={s.sub}>{t(lang,'historySub')}</Text>
        </View>
        {useFirebase && (
          <View style={s.fbBadge}>
            <Text style={s.fbTxt}>☁ {t(lang,'firebase')}</Text>
          </View>
        )}
      </View>

      {/* Stats */}
      <View style={s.statsRow}>
        {[{ label: t(lang,'show'), val: filtered.length, bg: '#F8FAFC', border: '#E2E8F0', color: '#0F172A' }, { label: t(lang,'normal'), val: normalCount, bg: '#DCFCE7', border: '#86EFAC', color: '#16A34A' }, { label: t(lang,'warning'), val: warningCount, bg: '#FEF9C3', border: '#FDE047', color: '#CA8A04' }].map((s2, i) => (
          <View key={i} style={[s.statBox, { backgroundColor: s2.bg, borderColor: s2.border }]}>
            <Text style={[s.statLabel, { color: s2.color }]}>{s2.label}</Text>
            <Text style={[s.statVal, { color: s2.color }]}>{s2.val}</Text>
          </View>
        ))}
      </View>

      {/* Day filter */}
      <Text style={s.filterLabel}>{t(lang,'timeRange')}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
        <View style={{ flexDirection: 'row', gap: 6 }}>
          {DAY.map((d) => (
            <TouchableOpacity key={d.key} onPress={() => setDayFilter(d.key)} style={[s.pill, dayFilter === d.key && s.pillActive]}>
              <Text style={[s.pillTxt, dayFilter === d.key && s.pillTxtActive]}>{d.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      {/* Granularity */}
      <Text style={s.filterLabel}>{t(lang,'showPer')}</Text>
      <View style={s.granRow}>
        {GRAN.map((g) => (
          <TouchableOpacity key={g.key} onPress={() => setGranularity(g.key)} style={[s.granBtn, granularity === g.key && s.granBtnActive]}>
            <Text style={[s.granTxt, granularity === g.key && s.granTxtActive]}>{g.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Search & Actions */}
      <View style={s.searchRow}>
        <TextInput value={search} onChangeText={setSearch} placeholder={t(lang,'search')} style={s.searchInput} placeholderTextColor="#94A3B8" />
        <TouchableOpacity onPress={handleExportCSV} style={s.csvBtn} activeOpacity={0.8}>
          <Text style={s.csvBtnTxt}>📥 {t(lang,'csv')}</Text>
        </TouchableOpacity>
        {history.length > 0 && (
          <TouchableOpacity onPress={clearHistory} style={s.deleteBtn}>
            <Text style={{ fontSize: 16 }}>🗑</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Status filter */}
      <View style={s.statusRow}>
        {[['ALL', t(lang,'all')], ['NORMAL', t(lang,'normal')], ['WARNING', t(lang,'warning')]].map(([key, label]) => (
          <TouchableOpacity key={key} onPress={() => setStatusFilter(key)} style={[s.pill, statusFilter === key && s.pillActive]}>
            <Text style={[s.pillTxt, statusFilter === key && s.pillTxtActive]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List */}
      {filtered.length === 0 ? (
        <View style={s.emptyBox}>
          <Text style={{ fontSize: 36 }}>📭</Text>
          <Text style={s.emptyTxt}>{t(lang,'noData')}</Text>
          {dayFilter !== 'all' && (
            <TouchableOpacity onPress={() => setDayFilter('all')} style={[s.pill, s.pillActive, { marginTop: 8 }]}>
              <Text style={s.pillTxtActive}>{t(lang,'showAllData')}</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : filtered.map((item) => (
        <View key={`${item.id}-${item.timestamp}`} style={s.histItem}>
          <View style={s.histItemTop}>
            <Text style={s.histTime}>{formatLabel(item.timestamp, granularity, lang)}</Text>
            {item.count > 1 && <View style={s.countBadge}><Text style={s.countTxt}>{item.count} data</Text></View>}
            <View style={[s.statusBadge, { backgroundColor: item.status === 'normal' ? '#DCFCE7' : '#FEF9C3', borderColor: item.status === 'normal' ? '#86EFAC' : '#FDE047' }]}>
              <View style={[s.statusDot, { backgroundColor: item.status === 'normal' ? '#16A34A' : '#CA8A04' }]} />
              <Text style={[s.statusTxt, { color: item.status === 'normal' ? '#16A34A' : '#CA8A04' }]}>{item.status.toUpperCase()}</Text>
            </View>
          </View>
          <View style={s.histItemData}>
            <View style={s.dataCol}><Text style={s.dataLabel}>{t(lang,'tempCol')}</Text><Text style={[s.dataVal, { color: '#0D9488' }]}>{item.suhu} °C</Text></View>
            <View style={s.dataCol}><Text style={s.dataLabel}>{t(lang,'phCol')}</Text><Text style={[s.dataVal, { color: '#7C3AED' }]}>{item.ph} pH</Text></View>
            <View style={s.dataCol}><Text style={s.dataLabel}>{t(lang,'waterCol')}</Text><Text style={[s.dataVal, { color: '#2563EB' }]}>{item.jarak_air} cm</Text></View>
          </View>
        </View>
      ))}
    </ScrollView>
  )
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { padding: 16, paddingBottom: 24 },
  titleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 },
  title: { fontSize: 20, fontWeight: '800', color: '#0F172A' },
  sub: { fontSize: 12, color: '#64748B', marginTop: 2 },
  fbBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999, backgroundColor: '#CCFBF1', borderWidth: 1, borderColor: '#99F6E4' },
  fbTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', color: '#0D9488' },
  statsRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  statBox: { flex: 1, padding: 12, borderRadius: 14, borderWidth: 1 },
  statLabel: { fontSize: 11 },
  statVal: { fontSize: 18, fontWeight: '800', marginTop: 2 },
  filterLabel: { fontSize: 11, color: '#475569', fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 },
  pill: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 999, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E2E8F0' },
  pillActive: { backgroundColor: '#0D9488', borderColor: '#0D9488' },
  pillTxt: { fontSize: 12, fontWeight: '700', color: '#475569' },
  pillTxtActive: { color: '#fff' },
  granRow: { flexDirection: 'row', gap: 6, padding: 4, borderRadius: 14, backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E2E8F0', marginBottom: 12 },
  granBtn: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 10 },
  granBtnActive: { backgroundColor: '#0D9488' },
  granTxt: { fontSize: 11, fontWeight: '700', color: '#475569' },
  granTxtActive: { color: '#fff' },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  searchInput: { flex: 1, height: 40, paddingHorizontal: 12, borderRadius: 12, fontFamily: 'monospace', fontSize: 12, color: '#0F172A', borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#fff' },
  csvBtn: { height: 40, paddingHorizontal: 14, borderRadius: 12, backgroundColor: '#0D9488', alignItems: 'center', justifyContent: 'center' },
  csvBtnTxt: { fontSize: 12, fontWeight: '700', color: '#fff' },
  deleteBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', alignItems: 'center', justifyContent: 'center' },
  statusRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  emptyBox: { padding: 32, borderRadius: 20, alignItems: 'center', gap: 8, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E2E8F0' },
  emptyTxt: { fontSize: 12, color: '#64748B' },
  histItem: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, padding: 14, marginBottom: 8 },
  histItemTop: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  histTime: { flex: 1, fontFamily: 'monospace', fontSize: 11, color: '#475569' },
  countBadge: { paddingHorizontal: 6, paddingVertical: 2, borderRadius: 999, backgroundColor: '#F1F5F9', borderWidth: 1, borderColor: '#E2E8F0' },
  countTxt: { fontFamily: 'monospace', fontSize: 10, color: '#64748B' },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 999, borderWidth: 1 },
  statusDot: { width: 6, height: 6, borderRadius: 3 },
  statusTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700' },
  histItemData: { flexDirection: 'row', gap: 8, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#F1F5F9' },
  dataCol: { flex: 1 },
  dataLabel: { fontSize: 10, color: '#94A3B8' },
  dataVal: { fontFamily: 'monospace', fontWeight: '700', fontSize: 13, marginTop: 2 },
})
