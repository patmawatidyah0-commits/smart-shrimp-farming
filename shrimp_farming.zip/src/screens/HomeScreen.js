import React from 'react'
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'
import Sparkline from '../components/Sparkline'

export default function HomeScreen() {
  const { telemetry, history, pump, aerator, rpm, autoMode, togglePump, toggleAerator, setActiveTab, connectionStatus, language } = useApp()
  const lang = language || 'id'
  const tempHistory = history.map((h) => h.suhu).reverse()
  const phHistory = history.map((h) => h.ph).reverse()
  const tempMin = tempHistory.length ? Math.min(...tempHistory) : 27.8
  const tempMax = tempHistory.length ? Math.max(...tempHistory) : 29.4
  const phMin = phHistory.length ? Math.min(...phHistory) : 6.9
  const phMax = phHistory.length ? Math.max(...phHistory) : 7.8
  const waterCapacity = Math.min(100, Math.max(10, Math.round(100 - ((telemetry.jarak_air - 30) / 50) * 100)))
  const isNormal = telemetry.status === 'normal'
  const suhuOk = telemetry.suhu >= 27.0 && telemetry.suhu <= 32.0
  const phOk = telemetry.ph >= 6.8 && telemetry.ph <= 8.8

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.container} showsVerticalScrollIndicator={false}>
      {/* Hero Banner */}
      <View style={s.heroBanner}>
        <View style={s.heroCircle1} />
        <View style={s.heroCircle2} />
        <View style={s.heroTop}>
          <View>
            <Text style={s.heroLabel}>{t(lang, 'pond')}</Text>
            <Text style={s.heroTitle}>{t(lang, 'greeting')}</Text>
            <Text style={s.heroDate}>{new Date().toLocaleDateString(lang === 'en' ? 'en-US' : 'id-ID', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
          </View>
          <View style={[s.liveBadge, connectionStatus !== 'connected' && s.liveBadgeOff]}>
            <View style={s.liveDot} />
            <Text style={s.liveTxt}>{connectionStatus === 'connected' ? t(lang, 'live') : t(lang, 'off')}</Text>
          </View>
        </View>
        <View style={[s.statusRow, !isNormal && s.statusRowWarn]}>
          <View style={[s.statusIcon, !isNormal && s.statusIconWarn]}>
            <Text style={s.statusIconTxt}>{isNormal ? '✓' : '⚠'}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.statusTitle}>{isNormal ? t(lang, 'allNormal') : t(lang, 'needAttention')}</Text>
            <Text style={s.statusSub}>{isNormal ? t(lang, 'normalDetail', telemetry.do_terlarut, telemetry.salinitas, telemetry.kekeruhan) : t(lang, 'openMonitor')}</Text>
          </View>
          <View style={s.statusBadge}>
            <Text style={s.statusBadgeTxt}>{isNormal ? t(lang, 'safe') : t(lang, 'warn')}</Text>
          </View>
        </View>
      </View>

      {/* Section Header */}
      <View style={s.sectionHeader}>
        <Text style={s.sectionTitle}>{t(lang, 'sensorParam')}</Text>
        <View style={s.livePill}>
          <View style={s.livePillDot} />
          <Text style={s.livePillTxt}>{t(lang, 'live')}</Text>
        </View>
      </View>

      {/* Suhu & pH */}
      <View style={s.cardRow}>
        {/* Suhu */}
        <View style={[s.sensorCard, { flex: 1, marginRight: 6 }]}>
          <View style={[s.sensorCardTop, { backgroundColor: suhuOk ? '#CCFBF1' : '#FEE2E2' }]}>
            <View style={s.sensorCardTopRow}>
              <View style={[s.sensorIcon, { backgroundColor: suhuOk ? '#0D9488' : '#DC2626' }]}>
                <Text style={s.sensorIconTxt}>🌡</Text>
              </View>
              <View style={[s.badge, { backgroundColor: suhuOk ? '#0D9488' : '#DC2626' }]}>
                <Text style={s.badgeTxt}>{suhuOk ? 'NORMAL' : t(lang, 'warn')}</Text>
              </View>
            </View>
            <Text style={s.sensorLabel}>{t(lang, 'tempWater')}</Text>
            <View style={s.valueRow}>
              <Text style={s.valueText}>{telemetry.suhu}</Text>
              <Text style={s.valueUnit}>°C</Text>
            </View>
          </View>
          <View style={s.sensorCardBot}>
            <Text style={s.rangeText}>{tempMin}° – {tempMax}°</Text>
            <Sparkline data={tempHistory} strokeColor="#0D9488" height={32} />
          </View>
        </View>

        {/* pH */}
        <View style={[s.sensorCard, { flex: 1, marginLeft: 6 }]}>
          <View style={[s.sensorCardTop, { backgroundColor: phOk ? '#EDE9FE' : '#FEE2E2' }]}>
            <View style={s.sensorCardTopRow}>
              <View style={[s.sensorIcon, { backgroundColor: phOk ? '#7C3AED' : '#DC2626' }]}>
                <Text style={s.sensorIconTxt}>💧</Text>
              </View>
              <View style={[s.badge, { backgroundColor: phOk ? '#7C3AED' : '#DC2626' }]}>
                <Text style={s.badgeTxt}>{phOk ? 'NORMAL' : t(lang, 'warn')}</Text>
              </View>
            </View>
            <Text style={s.sensorLabel}>{t(lang, 'phWater')}</Text>
            <View style={s.valueRow}>
              <Text style={s.valueText}>{telemetry.ph}</Text>
              <Text style={s.valueUnit}>pH</Text>
            </View>
          </View>
          <View style={s.sensorCardBot}>
            <Text style={s.rangeText}>{phMin} – {phMax}</Text>
            <Sparkline data={phHistory} strokeColor="#7C3AED" height={32} />
          </View>
        </View>
      </View>

      {/* Ketinggian Air */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: '#DBEAFE' }]}>
          <View style={[s.cardHeaderIcon, { backgroundColor: '#2563EB' }]}>
            <Text style={s.sensorIconTxt}>🌊</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.cardHeaderTitle}>{t(lang, 'waterLevel')}</Text>
            <Text style={s.cardHeaderSub}>{t(lang, 'ideal')}: 38–65 cm</Text>
          </View>
          <Text style={s.bigValue}>{telemetry.jarak_air}<Text style={s.bigValueUnit}> cm</Text></Text>
        </View>
        <View style={s.cardBody}>
          <View style={s.progressRow}>
            <Text style={s.progressLabel}>{t(lang, 'capacity', waterCapacity)}</Text>
            <Text style={[s.progressLabel, { color: '#2563EB' }]}>{t(lang, 'safeZone')}</Text>
          </View>
          <View style={s.progressBar}>
            <View style={[s.progressFill, { width: `${waterCapacity}%` }]} />
          </View>
        </View>
      </View>

      {/* Aktuator */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: autoMode ? '#F0FDF4' : '#F8FAFC' }]}>
          <Text style={s.cardHeaderTitle}>⚡ {t(lang, 'actuatorRelay')}</Text>
          <View style={[s.modeBadge, { backgroundColor: autoMode ? '#CCFBF1' : '#F1F5F9' }]}>
            <Text style={[s.modeBadgeTxt, { color: autoMode ? '#0D9488' : '#475569' }]}>
              {autoMode ? t(lang, 'autoMode') : t(lang, 'manualMode')}
            </Text>
          </View>
        </View>
        {autoMode && (
          <View style={s.infoBox}>
            <Text style={s.infoTxt}>{t(lang, 'relayLocked')}<Text style={{ fontWeight: '700', color: '#0D9488' }}>{t(lang, 'relayLockedLink')}</Text>{t(lang, 'relayLockedEnd')}</Text>
          </View>
        )}
        <View style={[s.cardBody, s.actuatorRow]}>
          <TouchableOpacity onPress={toggleAerator} disabled={autoMode} style={[s.actuatorBtn, aerator && !autoMode && s.actuatorBtnActive, autoMode && s.actuatorBtnDisabled]}>
            <View style={s.actuatorBtnTop}>
              <View style={[s.actuatorIcon, { backgroundColor: aerator && !autoMode ? '#0D9488' : '#E2E8F0' }]}>
                <Text style={s.sensorIconTxt}>{autoMode ? '🔒' : '🌀'}</Text>
              </View>
              <View style={[s.badge, { backgroundColor: aerator && !autoMode ? '#0D9488' : '#E2E8F0' }]}>
                <Text style={[s.badgeTxt, { color: aerator && !autoMode ? '#fff' : '#94A3B8' }]}>{aerator ? 'ON' : 'OFF'}</Text>
              </View>
            </View>
            <Text style={s.actuatorName}>{t(lang, 'aerator')}</Text>
            <Text style={[s.actuatorSub, { color: aerator && !autoMode ? '#0D9488' : '#94A3B8' }]}>
              {autoMode ? t(lang, 'auto') : aerator ? t(lang, 'rpm', rpm) : t(lang, 'standby')}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={togglePump} disabled={autoMode} style={[s.actuatorBtn, pump && !autoMode && s.actuatorBtnPump, autoMode && s.actuatorBtnDisabled]}>
            <View style={s.actuatorBtnTop}>
              <View style={[s.actuatorIcon, { backgroundColor: pump && !autoMode ? '#F97316' : '#E2E8F0' }]}>
                <Text style={s.sensorIconTxt}>{autoMode ? '🔒' : '💦'}</Text>
              </View>
              <View style={[s.badge, { backgroundColor: pump && !autoMode ? '#F97316' : '#E2E8F0' }]}>
                <Text style={[s.badgeTxt, { color: pump && !autoMode ? '#fff' : '#94A3B8' }]}>{pump ? 'ON' : 'OFF'}</Text>
              </View>
            </View>
            <Text style={s.actuatorName}>{t(lang, 'pump')}</Text>
            <Text style={[s.actuatorSub, { color: pump && !autoMode ? '#F97316' : '#94A3B8' }]}>
              {autoMode ? t(lang, 'auto') : pump ? t(lang, 'active') : t(lang, 'standby')}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* CTA */}
      <View style={s.ctaRow}>
        <TouchableOpacity onPress={() => setActiveTab('monitoring')} style={[s.ctaBtn, { backgroundColor: '#0D9488' }]}>
          <Text style={s.ctaBtnTxt}>📊 {t(lang, 'monitoring')}</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setActiveTab('kontrol')} style={[s.ctaBtn, { backgroundColor: '#F97316' }]}>
          <Text style={s.ctaBtnTxt}>🎛 {t(lang, 'control')}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  )
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { padding: 16, paddingBottom: 24 },
  heroBanner: { borderRadius: 24, padding: 20, marginBottom: 16, overflow: 'hidden', backgroundColor: '#0D9488', position: 'relative' },
  heroCircle1: { position: 'absolute', top: -40, right: -40, width: 140, height: 140, borderRadius: 70, backgroundColor: 'rgba(255,255,255,0.07)' },
  heroCircle2: { position: 'absolute', bottom: -30, left: -30, width: 100, height: 100, borderRadius: 50, backgroundColor: 'rgba(255,255,255,0.07)' },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 },
  heroLabel: { fontFamily: 'monospace', fontSize: 10, color: 'rgba(255,255,255,0.65)', letterSpacing: 1, marginBottom: 2 },
  heroTitle: { fontSize: 22, fontWeight: '800', color: '#fff' },
  heroDate: { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 4 },
  liveBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.18)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.25)' },
  liveBadgeOff: { backgroundColor: 'rgba(239,68,68,0.3)' },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#fff' },
  liveTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', color: '#fff' },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.15)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  statusRowWarn: { backgroundColor: 'rgba(239,68,68,0.25)', borderColor: 'rgba(239,68,68,0.4)' },
  statusIcon: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.2)' },
  statusIconWarn: { backgroundColor: 'rgba(239,68,68,0.3)' },
  statusIconTxt: { fontSize: 18, color: '#fff' },
  statusTitle: { fontSize: 13, fontWeight: '700', color: '#fff' },
  statusSub: { fontSize: 11, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.2)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.25)' },
  statusBadgeTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', color: '#fff' },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionTitle: { fontSize: 15, fontWeight: '700', color: '#0F172A' },
  livePill: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, backgroundColor: '#CCFBF1', borderWidth: 1, borderColor: '#99F6E4' },
  livePillDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#0D9488' },
  livePillTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', color: '#0D9488' },
  cardRow: { flexDirection: 'row', marginBottom: 12 },
  sensorCard: { borderRadius: 20, overflow: 'hidden', borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#fff' },
  sensorCardTop: { padding: 14 },
  sensorCardTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  sensorIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  sensorIconTxt: { fontSize: 16 },
  badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 999 },
  badgeTxt: { fontFamily: 'monospace', fontSize: 10, fontWeight: '700', color: '#fff' },
  sensorLabel: { fontSize: 11, fontWeight: '600', color: '#0F172A', textTransform: 'uppercase', letterSpacing: 0.5 },
  valueRow: { flexDirection: 'row', alignItems: 'baseline', gap: 2, marginTop: 2 },
  valueText: { fontSize: 28, fontWeight: '800', color: '#0F172A' },
  valueUnit: { fontSize: 13, color: '#475569' },
  sensorCardBot: { padding: 10, backgroundColor: '#fff' },
  rangeText: { fontFamily: 'monospace', fontSize: 10, color: '#475569', marginBottom: 6 },
  card: { borderRadius: 20, overflow: 'hidden', borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#fff', marginBottom: 12 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 10, borderBottomWidth: 1, borderBottomColor: '#E2E8F0' },
  cardHeaderIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  cardHeaderTitle: { fontSize: 13, fontWeight: '700', color: '#0F172A', flex: 1 },
  cardHeaderSub: { fontFamily: 'monospace', fontSize: 10, color: '#475569' },
  bigValue: { fontSize: 24, fontWeight: '800', color: '#0F172A' },
  bigValueUnit: { fontSize: 13, color: '#475569', fontWeight: '400' },
  cardBody: { padding: 12, backgroundColor: '#fff' },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  progressLabel: { fontFamily: 'monospace', fontSize: 10, color: '#475569' },
  progressBar: { height: 10, borderRadius: 999, backgroundColor: '#E2E8F0', overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 999, backgroundColor: '#2563EB' },
  infoBox: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 10, margin: 12, marginBottom: 0, borderRadius: 12, backgroundColor: '#CCFBF1', borderWidth: 1, borderColor: '#99F6E4' },
  infoTxt: { fontSize: 11, color: '#0F172A', flex: 1 },
  actuatorRow: { flexDirection: 'row', gap: 10 },
  actuatorBtn: { flex: 1, padding: 14, borderRadius: 16, borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#F8FAFC' },
  actuatorBtnActive: { borderColor: '#0D9488', borderWidth: 1.5, backgroundColor: '#CCFBF1' },
  actuatorBtnPump: { borderColor: '#F97316', borderWidth: 1.5, backgroundColor: '#FFF7ED' },
  actuatorBtnDisabled: { opacity: 0.45 },
  actuatorBtnTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  actuatorIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  actuatorName: { fontSize: 12, fontWeight: '700', color: '#0F172A' },
  actuatorSub: { fontSize: 11, marginTop: 2 },
  ctaRow: { flexDirection: 'row', gap: 12 },
  ctaBtn: { flex: 1, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  ctaBtnTxt: { fontSize: 13, fontWeight: '700', color: '#fff' },
  modeBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  modeBadgeTxt: { fontSize: 10, fontWeight: '700' },
})
