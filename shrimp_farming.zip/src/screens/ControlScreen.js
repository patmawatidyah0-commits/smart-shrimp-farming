import React from 'react'
import { View, Text, ScrollView, TouchableOpacity, Switch, StyleSheet } from 'react-native'
import { useApp } from '../context/AppContext'
import { simulatorService } from '../services/simulatorService'
import { t } from '../i18n'

export default function ControlScreen() {
  const { pump, aerator, rpm, autoMode, togglePump, toggleAerator, toggleAutoMode, language } = useApp()
  const lang = language || 'id'

  const handleSimulate = (type) => {
    if (type === 'RESET') simulatorService.clearAnomaly()
    else simulatorService.setAnomaly(type)
  }

  return (
    <ScrollView style={s.scroll} contentContainerStyle={s.container} showsVerticalScrollIndicator={false}>
      <Text style={s.title}>{t(lang,'controlTitle')}</Text>
      <Text style={s.sub}>{t(lang,'controlSub')}</Text>

      {/* Mode */}
      <View style={s.card}>
        <View style={[s.cardHeader, { backgroundColor: autoMode ? '#CCFBF1' : '#F1F5F9' }]}>
          <View style={[s.iconBox, { backgroundColor: autoMode ? '#0D9488' : '#94A3B8' }]}>
            <Text style={{ fontSize: 20 }}>{autoMode ? '🤖' : '🎛'}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.cardTitle}>{t(lang,'modeControl')}</Text>
            <Text style={s.cardSub}>{autoMode ? t(lang,'modeAutoSub') : t(lang,'modeManualSub')}</Text>
          </View>
          <Switch value={autoMode} onValueChange={toggleAutoMode} trackColor={{ false: '#CBD5E1', true: '#0D9488' }} thumbColor="#fff" />
        </View>
        <View style={s.cardBody}>
          {autoMode ? (
            <View style={s.infoBox}>
              <Text style={s.infoTitle}>ℹ️ {t(lang,'manualDisabled')}</Text>
              <Text style={s.infoSub}>{t(lang,'manualDisabledSub')}</Text>
            </View>
          ) : (
            <View style={[s.infoBox, { backgroundColor: '#FFF7ED', borderColor: '#FED7AA' }]}>
              <Text style={[s.infoTitle, { color: '#F97316' }]}>✅ {t(lang,'manualActive')}</Text>
            </View>
          )}
        </View>
      </View>

      {/* Aerator */}
      <View style={[s.card, autoMode && { opacity: 0.55 }]}>
        <View style={[s.cardHeader, { backgroundColor: aerator ? '#CCFBF1' : '#F1F5F9' }]}>
          <View style={[s.iconBox, { backgroundColor: aerator ? '#0D9488' : '#94A3B8' }]}>
            <Text style={{ fontSize: 20 }}>🌀</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.cardTitle}>{t(lang,'aeratorRelay')}</Text>
            <Text style={s.cardSub}>{t(lang,'gpio27')}</Text>
          </View>
          <View style={[s.badge, { backgroundColor: aerator ? '#0D9488' : '#E2E8F0' }]}>
            <Text style={[s.badgeTxt, { color: aerator ? '#fff' : '#94A3B8' }]}>{aerator ? 'ON' : 'OFF'}</Text>
          </View>
        </View>
        <View style={[s.cardBody, { flexDirection: 'row', justifyContent: 'space-between' }]}>
          <View>
            <Text style={s.metaLabel}>{t(lang,'rotSpeed')}</Text>
            <Text style={s.metaVal}>{aerator ? t(lang,'rpm',rpm) : t(lang,'offRpm')}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={s.metaLabel}>{autoMode ? t(lang,'controlledBy') : t(lang,'payload')}</Text>
            <Text style={[s.metaVal, { color: '#0D9488' }]}>{autoMode ? t(lang,'sensorAuto') : JSON.stringify({ command: aerator ? 'AERATOR_ON' : 'AERATOR_OFF' })}</Text>
          </View>
        </View>
        <View style={{ padding: 12, paddingTop: 0 }}>
          <TouchableOpacity onPress={toggleAerator} disabled={autoMode} style={[s.ctaBtn, { backgroundColor: autoMode ? '#CBD5E1' : aerator ? '#F97316' : '#0D9488' }]}>
            <Text style={s.ctaBtnTxt}>{autoMode ? `🔒 ${t(lang,'locked')}` : aerator ? `🔴 ${t(lang,'turnOff')} Aerator` : `🟢 ${t(lang,'turnOn')} Aerator`}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Pompa */}
      <View style={[s.card, autoMode && { opacity: 0.55 }]}>
        <View style={[s.cardHeader, { backgroundColor: pump ? '#DBEAFE' : '#F1F5F9' }]}>
          <View style={[s.iconBox, { backgroundColor: pump ? '#2563EB' : '#94A3B8' }]}>
            <Text style={{ fontSize: 20 }}>💦</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={s.cardTitle}>{t(lang,'pumpRelay')}</Text>
            <Text style={s.cardSub}>{t(lang,'gpio26')}</Text>
          </View>
          <View style={[s.badge, { backgroundColor: pump ? '#2563EB' : '#E2E8F0' }]}>
            <Text style={[s.badgeTxt, { color: pump ? '#fff' : '#94A3B8' }]}>{pump ? 'ON' : 'OFF'}</Text>
          </View>
        </View>
        <View style={[s.cardBody, { flexDirection: 'row', justifyContent: 'space-between' }]}>
          <View>
            <Text style={s.metaLabel}>{t(lang,'flowStatus')}</Text>
            <Text style={s.metaVal}>{pump ? t(lang,'debit') : t(lang,'standby')}</Text>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={s.metaLabel}>{autoMode ? t(lang,'controlledBy') : t(lang,'payload')}</Text>
            <Text style={[s.metaVal, { color: '#2563EB' }]}>{autoMode ? t(lang,'sensorAuto') : JSON.stringify({ command: pump ? 'PUMP_ON' : 'PUMP_OFF' })}</Text>
          </View>
        </View>
        <View style={{ padding: 12, paddingTop: 0 }}>
          <TouchableOpacity onPress={togglePump} disabled={autoMode} style={[s.ctaBtn, { backgroundColor: autoMode ? '#CBD5E1' : pump ? '#F97316' : '#2563EB' }]}>
            <Text style={s.ctaBtnTxt}>{autoMode ? `🔒 ${t(lang,'locked')}` : pump ? `🔴 ${t(lang,'turnOff')} Pompa` : `🟢 ${t(lang,'turnOn')} Pompa`}</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Sandbox */}
      <View style={s.card}>
        <View style={s.cardHeader}>
          <Text style={s.cardTitle}>🧪 {t(lang,'sandboxTitle')}</Text>
        </View>
        <Text style={s.sandboxSub}>{t(lang,'sandboxSub')}</Text>
        <View style={[s.cardBody, { flexDirection: 'row', flexWrap: 'wrap', gap: 10 }]}>
          {[
            { type: 'HIGH_TEMP', label: t(lang,'hotTemp'), sub: t(lang,'hotTempSub'), color: '#F97316', bg: '#FFF7ED', border: '#FED7AA' },
            { type: 'LOW_PH', label: t(lang,'lowPh'), sub: t(lang,'lowPhSub'), color: '#7C3AED', bg: '#EDE9FE', border: '#DDD6FE' },
            { type: 'LOW_WATER', label: t(lang,'lowWater'), sub: t(lang,'lowWaterSub'), color: '#2563EB', bg: '#EFF6FF', border: '#BFDBFE' },
            { type: 'RESET', label: t(lang,'resetNormal'), sub: t(lang,'resetNormalSub'), color: '#0D9488', bg: '#CCFBF1', border: '#99F6E4' },
          ].map((item) => (
            <TouchableOpacity key={item.type} onPress={() => handleSimulate(item.type)} style={[s.sandboxBtn, { backgroundColor: item.bg, borderColor: item.border }]}>
              <Text style={[s.sandboxBtnTitle, { color: item.color }]}>{item.label}</Text>
              <Text style={s.sandboxBtnSub}>{item.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </ScrollView>
  )
}

const s = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#F8FAFC' },
  container: { padding: 16, paddingBottom: 24 },
  title: { fontSize: 20, fontWeight: '800', color: '#0F172A', marginBottom: 2 },
  sub: { fontSize: 12, color: '#64748B', marginBottom: 16 },
  card: { borderRadius: 20, borderWidth: 1, borderColor: '#E2E8F0', backgroundColor: '#fff', marginBottom: 12, overflow: 'hidden' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12, borderBottomWidth: 1, borderBottomColor: '#E2E8F0', backgroundColor: '#F8FAFC' },
  iconBox: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  cardTitle: { fontSize: 14, fontWeight: '700', color: '#0F172A' },
  cardSub: { fontSize: 11, color: '#64748B', marginTop: 1 },
  badge: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 999 },
  badgeTxt: { fontFamily: 'monospace', fontSize: 12, fontWeight: '700' },
  cardBody: { padding: 12 },
  infoBox: { padding: 12, borderRadius: 14, backgroundColor: '#CCFBF1', borderWidth: 1, borderColor: '#99F6E4' },
  infoTitle: { fontSize: 12, fontWeight: '700', color: '#0F172A' },
  infoSub: { fontSize: 11, color: '#64748B', marginTop: 2 },
  metaLabel: { fontSize: 11, color: '#64748B' },
  metaVal: { fontFamily: 'monospace', fontSize: 13, fontWeight: '700', color: '#0F172A', marginTop: 2 },
  ctaBtn: { height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  ctaBtnTxt: { fontSize: 13, fontWeight: '700', color: '#fff' },
  sandboxSub: { fontSize: 12, color: '#64748B', paddingHorizontal: 16, paddingBottom: 8 },
  sandboxBtn: { width: '47%', padding: 12, borderRadius: 14, borderWidth: 1 },
  sandboxBtnTitle: { fontSize: 12, fontWeight: '700' },
  sandboxBtnSub: { fontSize: 11, color: '#64748B', marginTop: 2 },
})
