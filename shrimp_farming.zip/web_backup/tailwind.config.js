/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        // PRIMARY — Cyan/Teal
        "primary":                    "#06B6D4",
        "primary-container":          "#0891B2",
        "on-primary":                 "#ffffff",
        "primary-fixed":              "#CFFAFE",
        "primary-fixed-dim":          "#A5F3FC",
        "on-primary-fixed":           "#083344",
        "on-primary-fixed-variant":   "#0E7490",

        // TERTIARY — Violet
        "tertiary":                   "#A78BFA",
        "tertiary-container":         "#7C3AED",
        "on-tertiary":                "#ffffff",
        "on-tertiary-container":      "#ffffff",

        // SURFACE — Dark (background gelap)
        "surface":                    "#0F172A",
        "surface-bright":             "#1E293B",
        "surface-dim":                "#0A0F1E",
        "surface-container-lowest":   "#1E293B",
        "surface-container-low":      "#263248",
        "surface-container":          "#2D3A50",
        "surface-container-high":     "#364358",
        "surface-container-highest":  "#3E4D63",

        // ON-SURFACE — Teks TERANG agar terbaca di background gelap
        "on-surface":                 "#F1F5F9",
        "on-surface-variant":         "#CBD5E1",

        // SECONDARY
        "secondary":                  "#38BDF8",
        "secondary-container":        "#0284C7",
        "on-secondary-container":     "#ffffff",
        "secondary-fixed":            "#E0F2FE",

        // OUTLINE
        "outline":                    "#475569",
        "outline-variant":            "#334155",

        // ERROR
        "error":                      "#F87171",
        "error-container":            "#7F1D1D",
        "on-error-container":         "#FCA5A5",
      },
      fontFamily: {
        sans: ["'Plus Jakarta Sans'", "system-ui", "-apple-system", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      boxShadow: {
        card:   "0 4px 24px rgba(0,0,0,0.4)",
        glow:   "0 0 20px rgba(6,182,212,0.3)",
        glowsm: "0 0 10px rgba(6,182,212,0.2)",
        warm:   "0 0 16px rgba(249,115,22,0.25)",
      }
    },
  },
  plugins: [],
}
