import React, { createContext, useContext, useState, useEffect, useRef } from 'react'
import { mqttService } from '../services/mqttService'
import { simulatorService } from '../services/simulatorService'
import { saveHistoryRecord, listenHistory, isFirebaseReady } from '../services/firebaseService'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [user, setUser] = useState({
    name: 'Dyah Eka Patmawati',
    role: 'Pengelola Tambak A1',
    email: 'dyah@tambakudang.id',
    team: [
      { name: 'Dyah Eka Patmawati', role: 'Analisis PRD & Pengembangan Mobile App' },
      { name: 'M. Zidan Ihya U.A', role: 'Arsitektur IoT & Pengujian Sensor' },
      { name: 'Risky Prasetyo', role: '-' }
    ]
  })

  const [isLoggedIn, setIsLoggedIn] = useState(true)
  const [activeTab, setActiveTab] = useState('home')

  const [isSimulator, setIsSimulator] = useState(true)
  const [connectionStatus, setConnectionStatus] = useState('connected')

  const [telemetry, setTelemetry] = useState({
    device_id: 'ESP32_TAMBAK_01',
    suhu: 28.5,
    ph: 7.2,
    jarak_air: 45,
    status: 'normal',
    do_terlarut: 6.8,
    salinitas: 18,
    kekeruhan: 32,
    timestamp: Date.now()
  })

  const [history, setHistory] = useState(() => {
    const initial = []
    const baseTime = Date.now() - 3600000
    for (let i = 0; i < 20; i++) {
      const time = baseTime + (i * 180000)
      const suhu = Number((28.2 + Math.sin(i * 0.4) * 0.7).toFixed(1))
      const ph = Number((7.3 + Math.cos(i * 0.5) * 0.3).toFixed(1))
      const jarak_air = Math.round(44 + Math.sin(i * 0.3) * 4)
      initial.push({
        id: `LOG-${i + 100}`,
        timestamp: time,
        suhu,
        ph,
        jarak_air,
        status: (suhu > 32.0 || ph < 6.8 || jarak_air > 65) ? 'peringatan' : 'normal'
      })
    }
    return initial
  })

  const [pump, setPump] = useState(false)
  const [aerator, setAerator] = useState(true)
  const [rpm, setRpm] = useState(120)
  const [autoMode, setAutoMode] = useState(true)
  const [language, setLanguage] = useState('id') // 'id' | 'en'
  const [firebaseHistory, setFirebaseHistory] = useState([])
  const [useFirebase, setUseFirebase] = useState(false)

  const [thresholds, setThresholds] = useState({
    suhuMin: 27.0,
    suhuMax: 32.0,
    phMin: 6.8,
    phMax: 8.8,
    jarakMin: 38,
    jarakMax: 65
  })

  const [brokerConfig, setBrokerConfig] = useState({
    protocol: 'wss',
    host: 'broker.emqx.io',
    port: 8084,
    path: '/mqtt',
    topicSensor: 'tambak/sensor',
    topicControl: 'tambak/control',
    clientId: `shrimp_mobile_${Math.floor(Math.random() * 10000)}`
  })

  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'Kondisi Kolam Normal',
      message: 'Parameter air optimal untuk pembesaran udang Vaname (DOC-42).',
      time: '08:41 WIB',
      type: 'info',
      read: false
    },
    {
      id: 2,
      title: 'Pemberian Pakan Terjadwal',
      message: 'Jadwal pemberian pakan otomatis berikutnya jam 09:00 WIB.',
      time: '08:00 WIB',
      type: 'schedule',
      read: false
    }
  ])

  const autoModeRef = useRef(autoMode)
  autoModeRef.current = autoMode

  const pumpRef = useRef(pump)
  pumpRef.current = pump

  const aeratorRef = useRef(aerator)
  aeratorRef.current = aerator

  const thresholdsRef = useRef(thresholds)
  thresholdsRef.current = thresholds

  // Firebase history listener
  useEffect(() => {
    if (!isFirebaseReady()) return
    setUseFirebase(true)
    const unsub = listenHistory(7, (records) => {
      setFirebaseHistory(records)
    })
    return () => unsub()
  }, [])

  useEffect(() => {
    if (isSimulator) {
      setConnectionStatus('connected')
      simulatorService.start((data) => {
        handleIncomingData(data)
      })
      return () => {
        simulatorService.stop()
      }
    } else {
      mqttService.connect(brokerConfig)
      const unsubStatus = mqttService.onStatusChange((status) => {
        setConnectionStatus(status)
      })
      const unsubMessage = mqttService.onMessage((topic, data) => {
        if (topic === brokerConfig.topicSensor && typeof data === 'object') {
          handleIncomingData(data)
        }
      })
      return () => {
        unsubStatus()
        unsubMessage()
        mqttService.disconnect()
      }
    }
  }, [isSimulator, brokerConfig])

  const handleIncomingData = (data) => {
    const rawSuhu = typeof data.suhu === 'number' ? data.suhu : 28.5
    const rawPh = typeof data.ph === 'number' ? data.ph : 7.2
    const rawJarak = typeof data.jarak_air === 'number' ? data.jarak_air : 45
    const rawDeviceId = data.device_id || 'ESP32_TAMBAK_01'

    let computedStatus = 'normal'
    const th = thresholdsRef.current

    if (
      rawSuhu < th.suhuMin || rawSuhu > th.suhuMax ||
      rawPh < th.phMin || rawPh > th.phMax ||
      rawJarak < th.jarakMin || rawJarak > th.jarakMax
    ) {
      computedStatus = 'peringatan'
    }

    setTelemetry({
      device_id: rawDeviceId,
      suhu: rawSuhu,
      ph: rawPh,
      jarak_air: rawJarak,
      status: computedStatus,
      do_terlarut: data.do_terlarut || 6.8,
      salinitas: data.salinitas || 18,
      kekeruhan: data.kekeruhan || 32,
      timestamp: Date.now()
    })

    const newRecord = {
      id: `LOG-${Date.now()}`,
      timestamp: Date.now(),
      suhu: rawSuhu,
      ph: rawPh,
      jarak_air: rawJarak,
      status: computedStatus
    }

    setHistory((prev) => [newRecord, ...prev.slice(0, 49)])

    // Simpan ke Firebase jika tersedia
    saveHistoryRecord(newRecord)

    // Auto mode: hanya jalankan otomasi, TIDAK overwrite state aktuator dari payload simulator
    if (autoModeRef.current) {
      if (rawJarak > th.jarakMax && !pumpRef.current) {
        sendCommand('PUMP_ON')
        triggerAlertNotification(
          'Pompa Dihidupkan Otomatis',
          `Ketinggian air ${rawJarak} cm melebihi batas (${th.jarakMax} cm). Pompa sirkulasi dihidupkan untuk menaikkan level air. Kondisi pompa: AKTIF.`,
          'warning'
        )
      } else if (rawJarak <= th.jarakMin && pumpRef.current) {
        sendCommand('PUMP_OFF')
        triggerAlertNotification(
          'Pompa Dimatikan Otomatis',
          `Ketinggian air ${rawJarak} cm sudah di batas aman (≤${th.jarakMin} cm). Pompa sirkulasi dimatikan. Kondisi pompa: NONAKTIF.`,
          'info'
        )
      }

      if ((rawSuhu > th.suhuMax || rawPh < th.phMin) && !aeratorRef.current) {
        const alasan = rawSuhu > th.suhuMax
          ? `Suhu ${rawSuhu}°C melebihi batas aman (${th.suhuMax}°C)`
          : `pH ${rawPh} di bawah batas aman (${th.phMin})`
        sendCommand('AERATOR_ON')
        triggerAlertNotification(
          'Aerator Dihidupkan Otomatis',
          `${alasan}. Aerator diaktifkan untuk meningkatkan kadar oksigen terlarut. Kondisi aerator: AKTIF ${rpm} RPM.`,
          'warning'
        )
      }
    }
  }

  const triggerAlertNotification = (title, message, type = 'warning') => {
    const newNotif = {
      id: Date.now(),
      title,
      message,
      time: new Intl.DateTimeFormat('id-ID', { hour: '2-digit', minute: '2-digit' }).format(new Date()) + ' WIB',
      type,
      read: false
    }
    setNotifications((prev) => [newNotif, ...prev.slice(0, 20)])
  }

  const sendCommand = (cmd) => {
    // Update React state dulu sebagai source of truth
    if (cmd === 'PUMP_ON') {
      setPump(true)
      pumpRef.current = true
    } else if (cmd === 'PUMP_OFF') {
      setPump(false)
      pumpRef.current = false
    } else if (cmd === 'AERATOR_ON') {
      setAerator(true)
      setRpm(120)
      aeratorRef.current = true
    } else if (cmd === 'AERATOR_OFF') {
      setAerator(false)
      setRpm(0)
      aeratorRef.current = false
    }

    // Kirim ke simulator/broker tanpa trigger tick balik
    if (isSimulator) {
      simulatorService.setActuatorSilent(cmd)
    } else {
      mqttService.publishCommand(brokerConfig.topicControl, { command: cmd })
    }
  }

  const togglePump = () => {
    const nextState = !pumpRef.current
    sendCommand(nextState ? 'PUMP_ON' : 'PUMP_OFF')
  }

  const toggleAerator = () => {
    const nextState = !aeratorRef.current
    sendCommand(nextState ? 'AERATOR_ON' : 'AERATOR_OFF')
  }

  const toggleAutoMode = () => {
    setAutoMode((prev) => !prev)
  }

  const markNotificationAsRead = (id) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    )
  }

  const clearAllNotifications = () => {
    setNotifications([])
  }

  const clearHistory = () => {
    setHistory([])
  }

  const exportHistoryCsv = () => {
    const headers = 'ID,Waktu,Suhu (C),pH,Jarak Air (cm),Status\n'
    const rows = history
      .map((item) => {
        const timeStr = new Date(item.timestamp).toISOString()
        return `${item.id},${timeStr},${item.suhu},${item.ph},${item.jarak_air},${item.status}`
      })
      .join('\n')
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `histori_sensor_tambak_${Date.now()}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const login = (email, password) => {
    if (email && password) {
      setIsLoggedIn(true)
      return true
    }
    return false
  }

  const logout = () => {
    setIsLoggedIn(false)
  }

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        isLoggedIn,
        login,
        logout,
        activeTab,
        setActiveTab,
        isSimulator,
        setIsSimulator,
        connectionStatus,
        telemetry,
        history,
        pump,
        aerator,
        rpm,
        autoMode,
        togglePump,
        toggleAerator,
        toggleAutoMode,
        thresholds,
        setThresholds,
        brokerConfig,
        setBrokerConfig,
        notifications,
        markNotificationAsRead,
        clearAllNotifications,
        clearHistory,
        exportHistoryCsv,
        sendCommand,
        language,
        setLanguage,
        firebaseHistory,
        useFirebase
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error('useApp must be used within an AppProvider')
  }
  return context
}
