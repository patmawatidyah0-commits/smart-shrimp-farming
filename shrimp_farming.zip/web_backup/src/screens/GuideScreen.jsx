import React, { useState } from 'react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

const colorMap = [
  { bg: '#EFF6FF', text: '#2563EB', border: '#BFDBFE', gradBtn: 'linear-gradient(135deg,#2563EB,#0284C7)', stepBg: '#EFF6FF' },
  { bg: '#CCFBF1', text: '#0D9488', border: '#99F6E4', gradBtn: 'linear-gradient(135deg,#0D9488,#0F766E)', stepBg: '#CCFBF1' },
  { bg: '#FFF7ED', text: '#F97316', border: '#FED7AA', gradBtn: 'linear-gradient(135deg,#F97316,#EA580C)', stepBg: '#FFF7ED' },
  { bg: '#EDE9FE', text: '#7C3AED', border: '#DDD6FE', gradBtn: 'linear-gradient(135deg,#7C3AED,#6D28D9)', stepBg: '#EDE9FE' },
  { bg: '#FEF2F2', text: '#DC2626', border: '#FECACA', gradBtn: 'linear-gradient(135deg,#DC2626,#B91C1C)', stepBg: '#FEF2F2' },
]

export default function GuideScreen() {
  const { language, setLanguage } = useApp()
  const lang = language || 'id'
  const [activeIdx, setActiveIdx] = useState(0)

  const pages = t(lang, 'guidePages')
  const tips  = t(lang, 'tips')
  const current = pages[activeIdx]
  const c = colorMap[activeIdx]

  const TXT = '#0F172A'
  const TXTS = '#475569'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', paddingBottom: '112px' }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginTop: '16px' }}>
        <div>
          <h2 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '20px', color: TXT }}>
            {t(lang, 'guideTitle')}
          </h2>
          <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: TXTS, marginTop: '2px' }}>
            {t(lang, 'guideSub')}
          </p>
        </div>

        {/* Language toggle */}
        <div style={{ display: 'flex', gap: '4px', padding: '4px', borderRadius: '12px', border: '1px solid #E2E8F0', background: '#ffffff' }}>
          {['id', 'en'].map((l) => (
            <button key={l} onClick={() => setLanguage(l)}
              style={{
                padding: '6px 10px', borderRadius: '8px', fontFamily: 'Plus Jakarta Sans,sans-serif',
                fontSize: '12px', fontWeight: 700, border: 'none', cursor: 'pointer', transition: 'all 0.2s',
                background: lang === l ? 'linear-gradient(135deg,#0D9488,#0F766E)' : 'transparent',
                color: lang === l ? '#ffffff' : '#64748B'
              }}>
              {l === 'id' ? '🇮🇩 ID' : '🇬🇧 EN'}
            </button>
          ))}
        </div>
      </div>

      {/* Tab navigation */}
      <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '4px' }}>
        {pages.map((g, i) => {
          const col = colorMap[i]
          const isActive = activeIdx === i
          return (
            <button key={g.id} onClick={() => setActiveIdx(i)}
              style={{
                display: 'flex', alignItems: 'center', gap: '6px',
                padding: '8px 12px', borderRadius: '14px', border: isActive ? 'none' : `1px solid ${col.border}`,
                background: isActive ? col.gradBtn : '#ffffff',
                color: isActive ? '#ffffff' : col.text,
                fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', fontWeight: 700,
                whiteSpace: 'nowrap', flexShrink: 0, cursor: 'pointer',
                boxShadow: isActive ? `0 4px 12px ${col.text}30` : '0 1px 4px rgba(0,0,0,0.06)',
                transition: 'all 0.2s'
              }}>
              <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>{g.icon}</span>
              {g.title}
            </button>
          )
        })}
      </div>

      {/* Guide content card */}
      <div style={{ borderRadius: '20px', overflow: 'hidden', border: `1px solid ${c.border}`, boxShadow: '0 2px 12px rgba(15,23,42,0.08)', backgroundColor: '#ffffff' }}>
        {/* Card header */}
        <div style={{ padding: '16px', display: 'flex', alignItems: 'center', gap: '14px', background: c.bg, borderBottom: `1px solid ${c.border}` }}>
          <div style={{ width: 48, height: 48, borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: c.gradBtn }}>
            <span className="material-symbols-outlined" style={{ color: '#ffffff', fontSize: '26px' }}>{current.icon}</span>
          </div>
          <div>
            <h3 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '15px', color: TXT }}>{current.title}</h3>
            <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: TXTS, marginTop: '1px' }}>
              {current.steps.length} {lang === 'en' ? 'guide steps' : 'langkah panduan'}
            </p>
          </div>
        </div>

        {/* Steps */}
        <div style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {current.steps.map((step, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'flex-start', gap: '12px', padding: '12px',
              borderRadius: '14px', background: c.stepBg, border: `1px solid ${c.border}`
            }}>
              <div style={{ width: 28, height: 28, borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: '1px', background: c.gradBtn }}>
                <span className="material-symbols-outlined" style={{ color: '#ffffff', fontSize: '14px' }}>{step.icon}</span>
              </div>
              <div style={{ flex: 1 }}>
                <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', fontWeight: 700, color: c.text, marginRight: '4px' }}>#{i + 1}</span>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: TXT, lineHeight: 1.5 }}>{step.text}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tips card */}
      <div style={{ borderRadius: '20px', border: '1px solid #FED7AA', boxShadow: '0 2px 12px rgba(15,23,42,0.08)', backgroundColor: '#ffffff', overflow: 'hidden' }}>
        <div style={{ padding: '14px 16px', background: 'linear-gradient(135deg,#FFF7ED,#FFEDD5)', borderBottom: '1px solid #FED7AA' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: TXT, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span className="material-symbols-outlined" style={{ color: '#F97316', fontSize: '18px' }}>lightbulb</span>
            {t(lang, 'tipsTitle')}
          </h4>
        </div>
        <div style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {tips.map((tip, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: '10px', padding: '12px', borderRadius: '14px', background: '#FFF7ED', border: '1px solid #FED7AA' }}>
              <span className="material-symbols-outlined" style={{ color: '#F97316', fontSize: '16px', flexShrink: 0, marginTop: '1px' }}>chevron_right</span>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: TXT, lineHeight: 1.5 }}>{tip}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  )
}
