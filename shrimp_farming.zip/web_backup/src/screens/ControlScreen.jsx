import React from 'react'
import { useApp } from '../context/AppContext'
import { simulatorService } from '../services/simulatorService'
import { t } from '../i18n'

export default function ControlScreen() {
  const { pump, aerator, rpm, autoMode, togglePump, toggleAerator, toggleAutoMode, language } = useApp()
  const lang = language || 'id'

  const handleSimulateAnomaly = (type) => {
    if (type === 'RESET') simulatorService.clearAnomaly()
    else simulatorService.setAnomaly(type)
  }

  const C = { white: '#ffffff', textDark: '#0F172A', textLight: '#64748B', border: '#E2E8F0', shadow: '0 2px 12px rgba(15,23,42,0.08)' }
  const card = { borderRadius: '20px', overflow: 'hidden', border: `1px solid ${C.border}`, boxShadow: C.shadow, backgroundColor: C.white }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', paddingBottom: '112px' }}>

      <div style={{ marginTop: '16px' }}>
        <h2 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '20px', color: C.textDark }}>{t(lang, 'controlTitle')}</h2>
        <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight, marginTop: '4px' }}>{t(lang, 'controlSub')}</p>
      </div>

      {/* Mode Pengendalian */}
      <div style={card}>
        <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: autoMode ? 'linear-gradient(135deg,#CCFBF1,#A7F3D0)' : 'linear-gradient(135deg,#F1F5F9,#E2E8F0)', borderBottom: `1px solid ${C.border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: 40, height: 40, borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: autoMode ? 'linear-gradient(135deg,#0D9488,#0F766E)' : '#94A3B8' }}>
              <span className="material-symbols-outlined" style={{ color: C.white, fontSize: '20px' }}>{autoMode ? 'smart_toy' : 'tune'}</span>
            </div>
            <div>
              <h3 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark }}>{t(lang, 'modeControl')}</h3>
              <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight, marginTop: '1px' }}>
                {autoMode ? t(lang, 'modeAutoSub') : t(lang, 'modeManualSub')}
              </p>
            </div>
          </div>
          <button type="button" onClick={toggleAutoMode}
            style={{ position: 'relative', display: 'inline-flex', height: '28px', width: '52px', flexShrink: 0, cursor: 'pointer', borderRadius: '999px', border: 'none', backgroundColor: autoMode ? '#0D9488' : '#CBD5E1', transition: 'background-color 0.2s ease' }}>
            <span style={{ display: 'inline-block', height: '22px', width: '22px', transform: autoMode ? 'translateX(26px)' : 'translateX(3px)', marginTop: '3px', borderRadius: '50%', backgroundColor: C.white, boxShadow: '0 1px 4px rgba(0,0,0,0.2)', transition: 'transform 0.2s ease', pointerEvents: 'none' }} />
          </button>
        </div>
        <div style={{ padding: '12px 16px', backgroundColor: C.white }}>
          {autoMode ? (
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px', padding: '12px', borderRadius: '14px', background: '#CCFBF1', border: '1px solid #99F6E4' }}>
              <span className="material-symbols-outlined" style={{ color: '#0D9488', fontSize: '18px', flexShrink: 0, marginTop: '1px' }}>info</span>
              <div>
                <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '12px', color: C.textDark }}>{t(lang, 'manualDisabled')}</p>
                <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight, marginTop: '2px' }}>{t(lang, 'manualDisabledSub')}</p>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px', borderRadius: '14px', background: '#FFF7ED', border: '1px solid #FED7AA' }}>
              <span className="material-symbols-outlined" style={{ color: '#F97316', fontSize: '18px', flexShrink: 0 }}>check_circle</span>
              <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textDark, fontWeight: 500 }}>{t(lang, 'manualActive')}</p>
            </div>
          )}
        </div>
      </div>

      {/* Aerator Card */}
      <div style={{ ...card, opacity: autoMode ? 0.55 : 1 }}>
        <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: aerator ? 'linear-gradient(135deg,#CCFBF1,#A7F3D0)' : 'linear-gradient(135deg,#F1F5F9,#E2E8F0)', borderBottom: `1px solid ${C.border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: 44, height: 44, borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: aerator ? 'linear-gradient(135deg,#0D9488,#0F766E)' : '#94A3B8' }}>
              <span className={`material-symbols-outlined ${aerator && !autoMode ? 'animate-spin' : ''}`} style={{ color: C.white, fontSize: '24px' }}>mode_fan</span>
            </div>
            <div>
              <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark }}>{t(lang, 'aeratorRelay')}</h4>
              <p style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', color: C.textLight }}>{t(lang, 'gpio27')}</p>
            </div>
          </div>
          <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '12px', fontWeight: 700, padding: '4px 12px', borderRadius: '999px', background: aerator ? '#0D9488' : '#E2E8F0', color: aerator ? C.white : C.textLight }}>
            {aerator ? 'ON' : 'OFF'}
          </span>
        </div>
        <div style={{ padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#F8FAFC', borderBottom: `1px solid ${C.border}` }}>
          <div>
            <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight }}>{t(lang, 'rotSpeed')}</p>
            <p style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '14px', color: C.textDark, marginTop: '2px' }}>{aerator ? t(lang, 'rpm', rpm) : t(lang, 'offRpm')}</p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight }}>{autoMode ? t(lang, 'controlledBy') : t(lang, 'payload')}</p>
            <p style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '11px', color: '#0D9488', marginTop: '2px' }}>
              {autoMode ? t(lang, 'sensorAuto') : JSON.stringify({ command: aerator ? 'AERATOR_ON' : 'AERATOR_OFF' })}
            </p>
          </div>
        </div>
        <div style={{ padding: '12px 16px' }}>
          <button type="button" onClick={toggleAerator} disabled={autoMode}
            style={{ width: '100%', height: '44px', borderRadius: '14px', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '13px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', border: 'none', cursor: autoMode ? 'not-allowed' : 'pointer', color: C.white, background: autoMode ? '#CBD5E1' : aerator ? 'linear-gradient(135deg,#F97316,#EA580C)' : 'linear-gradient(135deg,#0D9488,#0F766E)', transition: 'all 0.2s' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>{autoMode ? 'lock' : aerator ? 'power_settings_new' : 'bolt'}</span>
            {autoMode ? t(lang, 'locked') : aerator ? `${t(lang, 'turnOff')} Aerator` : `${t(lang, 'turnOn')} Aerator`}
          </button>
        </div>
      </div>

      {/* Pompa Card */}
      <div style={{ ...card, opacity: autoMode ? 0.55 : 1 }}>
        <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: pump ? 'linear-gradient(135deg,#DBEAFE,#E0F2FE)' : 'linear-gradient(135deg,#F1F5F9,#E2E8F0)', borderBottom: `1px solid ${C.border}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: 44, height: 44, borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: pump ? 'linear-gradient(135deg,#2563EB,#0284C7)' : '#94A3B8' }}>
              <span className="material-symbols-outlined" style={{ color: C.white, fontSize: '24px' }}>water_pump</span>
            </div>
            <div>
              <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark }}>{t(lang, 'pumpRelay')}</h4>
              <p style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', color: C.textLight }}>{t(lang, 'gpio26')}</p>
            </div>
          </div>
          <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '12px', fontWeight: 700, padding: '4px 12px', borderRadius: '999px', background: pump ? '#2563EB' : '#E2E8F0', color: pump ? C.white : C.textLight }}>
            {pump ? 'ON' : 'OFF'}
          </span>
        </div>
        <div style={{ padding: '12px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#F8FAFC', borderBottom: `1px solid ${C.border}` }}>
          <div>
            <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight }}>{t(lang, 'flowStatus')}</p>
            <p style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '14px', color: C.textDark, marginTop: '2px' }}>{pump ? t(lang, 'debit') : t(lang, 'standby')}</p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight }}>{autoMode ? t(lang, 'controlledBy') : t(lang, 'payload')}</p>
            <p style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '11px', color: '#2563EB', marginTop: '2px' }}>
              {autoMode ? t(lang, 'sensorAuto') : JSON.stringify({ command: pump ? 'PUMP_ON' : 'PUMP_OFF' })}
            </p>
          </div>
        </div>
        <div style={{ padding: '12px 16px' }}>
          <button type="button" onClick={togglePump} disabled={autoMode}
            style={{ width: '100%', height: '44px', borderRadius: '14px', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '13px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', border: 'none', cursor: autoMode ? 'not-allowed' : 'pointer', color: C.white, background: autoMode ? '#CBD5E1' : pump ? 'linear-gradient(135deg,#F97316,#EA580C)' : 'linear-gradient(135deg,#2563EB,#0284C7)', transition: 'all 0.2s' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>{autoMode ? 'lock' : pump ? 'power_settings_new' : 'waves'}</span>
            {autoMode ? t(lang, 'locked') : pump ? `${t(lang, 'turnOff')} Pompa` : `${t(lang, 'turnOn')} Pompa`}
          </button>
        </div>
      </div>

      {/* Sandbox */}
      <div style={card}>
        <div style={{ padding: '14px 16px', borderBottom: `1px solid ${C.border}`, background: 'linear-gradient(135deg,#F8FAFC,#F1F5F9)' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span className="material-symbols-outlined" style={{ color: '#7C3AED', fontSize: '18px' }}>science</span>
            {t(lang, 'sandboxTitle')}
          </h4>
          <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight, marginTop: '4px' }}>{t(lang, 'sandboxSub')}</p>
        </div>
        <div style={{ padding: '12px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
          {[
            { type: 'HIGH_TEMP', label: t(lang, 'hotTemp'), sub: t(lang, 'hotTempSub'), color: '#F97316', bg: '#FFF7ED', border: '#FED7AA' },
            { type: 'LOW_PH',   label: t(lang, 'lowPh'),   sub: t(lang, 'lowPhSub'),   color: '#7C3AED', bg: '#EDE9FE', border: '#DDD6FE' },
            { type: 'LOW_WATER',label: t(lang, 'lowWater'),sub: t(lang, 'lowWaterSub'),color: '#2563EB', bg: '#EFF6FF', border: '#BFDBFE' },
            { type: 'RESET',    label: t(lang, 'resetNormal'), sub: t(lang, 'resetNormalSub'), color: '#0D9488', bg: '#CCFBF1', border: '#99F6E4' },
          ].map((item) => (
            <button key={item.type} type="button" onClick={() => handleSimulateAnomaly(item.type)}
              style={{ padding: '12px', borderRadius: '14px', textAlign: 'left', background: item.bg, border: `1px solid ${item.border}`, cursor: 'pointer', transition: 'all 0.2s' }}>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '12px', color: item.color, display: 'block' }}>{item.label}</span>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight, marginTop: '2px', display: 'block' }}>{item.sub}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
