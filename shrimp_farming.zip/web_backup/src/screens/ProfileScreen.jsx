import React, { useState } from 'react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function ProfileScreen() {
  const { user, thresholds, setThresholds, brokerConfig, setBrokerConfig, isSimulator, setIsSimulator, logout, language } = useApp()
  const lang = language || 'id'
  const [tempTh, setTempTh] = useState({ ...thresholds })
  const [tempBroker, setTempBroker] = useState({ ...brokerConfig })
  const [saved, setSaved] = useState(false)

  const handleSave = (e) => {
    e.preventDefault()
    setThresholds(tempTh)
    setBrokerConfig(tempBroker)
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const C = { textDark: '#0F172A', textLight: '#64748B', border: '#E2E8F0', white: '#ffffff', shadow: '0 2px 12px rgba(15,23,42,0.08)' }
  const card = { borderRadius: '20px', border: `1px solid ${C.border}`, boxShadow: C.shadow, backgroundColor: C.white, overflow: 'hidden' }
  const inputStyle = { width: '100%', height: '40px', padding: '0 12px', borderRadius: '12px', fontFamily: 'JetBrains Mono,monospace', fontSize: '12px', color: C.textDark, border: `1px solid ${C.border}`, background: '#F8FAFC', outline: 'none', boxSizing: 'border-box' }
  const labelStyle = { fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight, fontWeight: 500, display: 'block', marginBottom: '4px' }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', paddingBottom: '112px' }}>

      <div style={{ marginTop: '16px' }}>
        <h2 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '20px', color: C.textDark }}>{t(lang,'profileTitle')}</h2>
        <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight, marginTop: '2px' }}>{t(lang,'profileSub')}</p>
      </div>

      {/* User Card */}
      <div style={{ ...card, padding: '16px', display: 'flex', alignItems: 'center', gap: '14px' }}>
        <div style={{ width: 56, height: 56, borderRadius: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: 'linear-gradient(135deg,#0D9488,#0F766E)' }}>
          <span className="material-symbols-outlined" style={{ color: C.white, fontSize: '30px' }}>person</span>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h3 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '15px', color: C.textDark }}>{user.name}</h3>
          <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight, marginTop: '1px' }}>{user.role}</p>
          <p style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '11px', color: '#0D9488', marginTop: '2px' }}>{user.email}</p>
        </div>
        <button type="button" onClick={logout}
          style={{ padding: '8px', borderRadius: '12px', background: '#FEF2F2', border: '1px solid #FECACA', color: '#DC2626', cursor: 'pointer' }}>
          <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>logout</span>
        </button>
      </div>

      {/* Team */}
      <div style={card}>
        <div style={{ padding: '14px 16px', borderBottom: `1px solid ${C.border}`, background: 'linear-gradient(135deg,#F0FDF4,#CCFBF1)' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span className="material-symbols-outlined" style={{ color: '#0D9488', fontSize: '18px' }}>group</span>
            {t(lang,'team')}
          </h4>
        </div>
        <div style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {user.team.map((member, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 12px', borderRadius: '14px', background: '#F8FAFC', border: `1px solid ${C.border}` }}>
              <div style={{ width: 36, height: 36, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: 'linear-gradient(135deg,#0D9488,#0F766E)', fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '14px', color: C.white }}>
                {member.name.charAt(0)}
              </div>
              <div>
                <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '13px', color: C.textDark }}>{member.name}</p>
                <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight, marginTop: '1px' }}>{member.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div style={card}>
        <div style={{ padding: '14px 16px', borderBottom: `1px solid ${C.border}`, background: 'linear-gradient(135deg,#EDE9FE,#DDD6FE)' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span className="material-symbols-outlined" style={{ color: '#7C3AED', fontSize: '18px' }}>timeline</span>
            {t(lang,'timeline')}
          </h4>
        </div>
        <div style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {t(lang,'sprints').map((s, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', borderRadius: '12px', background: '#F8FAFC', border: `1px solid ${C.border}` }}>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 600, fontSize: '12px', color: C.textDark, flex: 1, marginRight: '8px' }}>{s.label}</span>
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', fontWeight: 700, padding: '3px 8px', borderRadius: '999px', background: s.bg, color: s.color, flexShrink: 0 }}>{s.status}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Threshold Form */}
      <form onSubmit={handleSave} style={{ ...card, padding: '16px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark, display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span className="material-symbols-outlined" style={{ color: '#0D9488', fontSize: '18px' }}>tune</span>
            {t(lang,'threshold')}
          </h4>
          <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', color: C.textLight }}>{t(lang,'thresholdSub')}</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
          {[
            { key: 'suhuMin', label: t(lang,'tempMin'), type: 'number', step: '0.1', parse: parseFloat },
            { key: 'suhuMax', label: t(lang,'tempMax'), type: 'number', step: '0.1', parse: parseFloat },
            { key: 'phMin',   label: t(lang,'phMin'),   type: 'number', step: '0.1', parse: parseFloat },
            { key: 'phMax',   label: t(lang,'phMax'),   type: 'number', step: '0.1', parse: parseFloat },
            { key: 'jarakMin',label: t(lang,'waterMin'),type: 'number', step: '1',   parse: parseInt },
            { key: 'jarakMax',label: t(lang,'waterMax'),type: 'number', step: '1',   parse: parseInt },
          ].map((f) => (
            <div key={f.key}>
              <label style={labelStyle}>{f.label}</label>
              <input type={f.type} step={f.step} value={tempTh[f.key]}
                onChange={e => setTempTh({ ...tempTh, [f.key]: f.parse(e.target.value) || 0 })}
                style={inputStyle} />
            </div>
          ))}
        </div>

        <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: '16px' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark, display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <span className="material-symbols-outlined" style={{ color: '#2563EB', fontSize: '18px' }}>router</span>
            {t(lang,'mqttConfig')}
          </h4>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', borderRadius: '14px', background: '#F8FAFC', border: `1px solid ${C.border}`, marginBottom: '12px' }}>
            <div>
              <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '13px', color: C.textDark }}>{t(lang,'useSimulator')}</p>
              <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: C.textLight, marginTop: '1px' }}>{t(lang,'useSimulatorSub')}</p>
            </div>
            <button type="button" onClick={() => setIsSimulator(!isSimulator)}
              style={{ position: 'relative', display: 'inline-flex', height: '26px', width: '48px', flexShrink: 0, cursor: 'pointer', borderRadius: '999px', border: 'none', backgroundColor: isSimulator ? '#0D9488' : '#CBD5E1', transition: 'background-color 0.2s ease' }}>
              <span style={{ display: 'inline-block', height: '20px', width: '20px', transform: isSimulator ? 'translateX(24px)' : 'translateX(3px)', marginTop: '3px', borderRadius: '50%', backgroundColor: C.white, boxShadow: '0 1px 3px rgba(0,0,0,0.2)', transition: 'transform 0.2s ease', pointerEvents: 'none' }} />
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {[
              { key: 'host', label: t(lang,'brokerHost') },
              { key: 'topicSensor', label: t(lang,'topicSensor') },
              { key: 'topicControl', label: t(lang,'topicControl') },
            ].map((f) => (
              <div key={f.key}>
                <label style={labelStyle}>{f.label}</label>
                <input type="text" value={tempBroker[f.key]} onChange={e => setTempBroker({ ...tempBroker, [f.key]: e.target.value })} style={inputStyle} />
              </div>
            ))}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
              <div>
                <label style={labelStyle}>{t(lang,'portWs')}</label>
                <input type="number" value={tempBroker.port} onChange={e => setTempBroker({ ...tempBroker, port: parseInt(e.target.value) || 8084 })} style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>{t(lang,'path')}</label>
                <input type="text" value={tempBroker.path} onChange={e => setTempBroker({ ...tempBroker, path: e.target.value })} style={inputStyle} />
              </div>
            </div>
          </div>
        </div>

        {saved && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '12px', borderRadius: '14px', background: '#DCFCE7', border: '1px solid #86EFAC' }}>
            <span className="material-symbols-outlined" style={{ color: '#16A34A', fontSize: '18px' }}>check_circle</span>
            <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', fontWeight: 600, color: '#16A34A' }}>{t(lang,'saveSuccess')}</span>
          </div>
        )}

        <button type="submit"
          style={{ width: '100%', height: '48px', borderRadius: '14px', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '14px', fontWeight: 700, color: C.white, border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', background: 'linear-gradient(135deg,#0D9488,#0891B2)', boxShadow: '0 4px 12px rgba(13,148,136,0.3)' }}>
          <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>save</span>
          {t(lang,'saveBtn')}
        </button>
      </form>
    </div>
  )
}
