import React, { useState, useMemo } from 'react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

function startOfDay(date) { const d = new Date(date); d.setHours(0,0,0,0); return d.getTime() }
function getDayRange(key, lang) {
  const now = Date.now(), todayStart = startOfDay(now)
  switch (key) {
    case 'today':     return { from: todayStart, to: now }
    case 'yesterday': return { from: todayStart - 86400000, to: todayStart - 1 }
    case '3days':     return { from: todayStart - 2 * 86400000, to: now }
    case '7days':     return { from: todayStart - 6 * 86400000, to: now }
    default:          return { from: 0, to: now }
  }
}
function bucketKey(ts, g) {
  const d = new Date(ts)
  switch (g) {
    case 'second': return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}-${d.getMinutes()}-${d.getSeconds()}`
    case 'minute': return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}-${d.getMinutes()}`
    case 'hour':   return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}-${d.getHours()}`
    case 'day':    return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
    default:       return String(ts)
  }
}
function groupHistory(history, g) {
  const buckets = new Map()
  for (const item of history) { const k = bucketKey(item.timestamp, g); if (!buckets.has(k)) buckets.set(k, []); buckets.get(k).push(item) }
  return Array.from(buckets.values()).map((group) => {
    const count = group.length
    return { id: group[0].id, timestamp: group[0].timestamp, suhu: Number((group.reduce((s,i) => s+i.suhu, 0)/count).toFixed(1)), ph: Number((group.reduce((s,i) => s+i.ph, 0)/count).toFixed(1)), jarak_air: Math.round(group.reduce((s,i) => s+i.jarak_air, 0)/count), status: group.some(i => i.status !== 'normal') ? 'peringatan' : 'normal', count }
  })
}
function formatLabel(ts, g, lang) {
  const d = new Date(ts), fmt = (opt) => new Intl.DateTimeFormat(lang === 'en' ? 'en-US' : 'id-ID', opt).format(d)
  switch (g) {
    case 'second': return fmt({ hour: '2-digit', minute: '2-digit', second: '2-digit' })
    case 'minute': return fmt({ day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
    case 'hour':   return fmt({ day: '2-digit', month: 'short', hour: '2-digit' }) + ':00'
    case 'day':    return fmt({ weekday: 'long', day: '2-digit', month: 'long' })
    default:       return String(ts)
  }
}

export default function HistoryScreen() {
  const { history, firebaseHistory, useFirebase, exportHistoryCsv, clearHistory, language } = useApp()
  const lang = language || 'id'
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [granularity, setGranularity] = useState('minute')
  const [dayFilter, setDayFilter] = useState('today')
  const [search, setSearch] = useState('')

  const GRAN = [
    { key: 'second', label: t(lang,'second'), icon: 'timer' },
    { key: 'minute', label: t(lang,'minute'), icon: 'schedule' },
    { key: 'hour',   label: t(lang,'hour'),   icon: 'hourglass_bottom' },
    { key: 'day',    label: t(lang,'day'),     icon: 'calendar_today' },
  ]
  const DAY = [
    { key: 'today',     label: t(lang,'today') },
    { key: 'yesterday', label: t(lang,'yesterday') },
    { key: '3days',     label: t(lang,'days3') },
    { key: '7days',     label: t(lang,'days7') },
    { key: 'all',       label: t(lang,'all') },
  ]

  const allHistory = useMemo(() => {
    if (useFirebase && firebaseHistory.length > 0) {
      const ids = new Set(history.map(h => h.id))
      return [...history, ...firebaseHistory.filter(h => !ids.has(h.id))].sort((a,b) => b.timestamp - a.timestamp)
    }
    return history
  }, [history, firebaseHistory, useFirebase])

  const dayFiltered = useMemo(() => { const { from, to } = getDayRange(dayFilter); return allHistory.filter(h => h.timestamp >= from && h.timestamp <= to) }, [allHistory, dayFilter])
  const grouped = useMemo(() => groupHistory(dayFiltered, granularity), [dayFiltered, granularity])
  const filtered = useMemo(() => grouped.filter(item => {
    const ms = statusFilter === 'ALL' ? true : statusFilter === 'NORMAL' ? item.status === 'normal' : item.status !== 'normal'
    const ms2 = search === '' || item.id.toLowerCase().includes(search.toLowerCase()) || item.suhu.toString().includes(search) || item.ph.toString().includes(search)
    return ms && ms2
  }), [grouped, statusFilter, search])

  const normalCount = filtered.filter(h => h.status === 'normal').length
  const warningCount = filtered.filter(h => h.status !== 'normal').length
  const C = { textDark: '#0F172A', textLight: '#64748B', border: '#E2E8F0', white: '#ffffff' }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', paddingBottom: '112px' }}>
      <div style={{ marginTop: '12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h2 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '20px', color: '#0F172A' }}>{t(lang,'historyTitle')}</h2>
          {useFirebase && (
            <span style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '2px 8px', borderRadius: '999px', background: '#CCFBF1', color: '#0D9488', border: '1px solid #99F6E4', fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', fontWeight: 700 }}>
              <span className="material-symbols-outlined" style={{ fontSize: '12px' }}>cloud_done</span>
              {t(lang,'firebase')}
            </span>
          )}
        </div>
        <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: '#475569', marginTop: '2px' }}>{t(lang,'historySub')}</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
        {[
          { label: t(lang,'show'), val: filtered.length, bg: '#F8FAFC', border: '#E2E8F0', color: '#0F172A' },
          { label: t(lang,'normal'), val: normalCount, bg: '#DCFCE7', border: '#86EFAC', color: '#16A34A' },
          { label: t(lang,'warning'), val: warningCount, bg: '#FEF9C3', border: '#FDE047', color: '#CA8A04' },
        ].map((s, i) => (
          <div key={i} style={{ padding: '12px', borderRadius: '14px', display: 'flex', flexDirection: 'column', background: s.bg, border: `1px solid ${s.border}` }}>
            <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: s.color }}>{s.label}</span>
            <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '18px', fontWeight: 800, color: s.color, marginTop: '2px' }}>{s.val}</span>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
        <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t(lang,'timeRange')}</p>
        <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', paddingBottom: '2px' }}>
          {DAY.map((d) => (
            <button key={d.key} onClick={() => setDayFilter(d.key)}
              style={{ padding: '6px 14px', borderRadius: '999px', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap', flexShrink: 0, border: 'none', cursor: 'pointer', background: dayFilter === d.key ? '#0D9488' : '#ffffff', color: dayFilter === d.key ? '#ffffff' : '#475569', boxShadow: dayFilter === d.key ? 'none' : '0 1px 3px rgba(15,23,42,0.1)', transition: 'all 0.2s' }}>
              {d.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
        <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', color: '#475569', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t(lang,'showPer')}</p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '6px', padding: '4px', borderRadius: '14px', background: '#F1F5F9', border: '1px solid #E2E8F0' }}>
          {GRAN.map((g) => (
            <button key={g.key} onClick={() => setGranularity(g.key)}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '8px 4px', borderRadius: '10px', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '11px', fontWeight: 700, gap: '2px', border: 'none', cursor: 'pointer', background: granularity === g.key ? '#0D9488' : 'transparent', color: granularity === g.key ? '#ffffff' : '#475569', transition: 'all 0.2s' }}>
              <span className="material-symbols-outlined" style={{ fontSize: '16px', color: granularity === g.key ? '#ffffff' : '#0D9488' }}>{g.icon}</span>
              {g.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <div style={{ position: 'relative', flex: 1 }}>
          <span className="material-symbols-outlined" style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', fontSize: '18px', color: '#94A3B8' }}>search</span>
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder={t(lang,'search')}
            style={{ width: '100%', height: '40px', paddingLeft: '36px', paddingRight: '12px', borderRadius: '12px', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: '#0F172A', border: '1px solid #E2E8F0', background: '#ffffff', outline: 'none', boxSizing: 'border-box' }} />
        </div>
        <button onClick={exportHistoryCsv}
          style={{ height: '40px', padding: '0 14px', borderRadius: '12px', background: 'linear-gradient(135deg,#0D9488,#0F766E)', color: '#ffffff', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '4px', flexShrink: 0, border: 'none', cursor: 'pointer' }}>
          <span className="material-symbols-outlined" style={{ fontSize: '16px' }}>download</span>
          {t(lang,'csv')}
        </button>
        {history.length > 0 && (
          <button onClick={clearHistory}
            style={{ height: '40px', padding: '0 10px', borderRadius: '12px', background: '#F8FAFC', border: '1px solid #E2E8F0', color: '#94A3B8', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, cursor: 'pointer' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>delete</span>
          </button>
        )}
      </div>

      <div style={{ display: 'flex', gap: '8px' }}>
        {[['ALL', t(lang,'all')], ['NORMAL', t(lang,'normal')], ['WARNING', t(lang,'warning')]].map(([key, label]) => (
          <button key={key} onClick={() => setStatusFilter(key)}
            style={{ padding: '6px 14px', borderRadius: '999px', fontFamily: 'JetBrains Mono,monospace', fontSize: '11px', fontWeight: 700, border: 'none', cursor: 'pointer', background: statusFilter === key ? '#0D9488' : '#F1F5F9', color: statusFilter === key ? '#ffffff' : '#475569', transition: 'all 0.2s' }}>
            {label}
          </button>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {filtered.length === 0 ? (
          <div style={{ padding: '32px', borderRadius: '20px', textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', background: '#ffffff', border: '1px solid #E2E8F0' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '36px', color: '#CBD5E1' }}>inbox</span>
            <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: '#64748B' }}>{t(lang,'noData')}</p>
            {dayFilter !== 'all' && (
              <button onClick={() => setDayFilter('all')}
                style={{ marginTop: '4px', padding: '6px 16px', borderRadius: '999px', background: '#0D9488', color: '#ffffff', fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', fontWeight: 700, border: 'none', cursor: 'pointer' }}>
                {t(lang,'showAllData')}
              </button>
            )}
          </div>
        ) : filtered.map((item) => (
          <div key={`${item.id}-${item.timestamp}`} style={{ background: '#ffffff', border: '1px solid #E2E8F0', boxShadow: '0 2px 8px rgba(15,23,42,0.06)', padding: '14px', borderRadius: '16px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0 }}>
                <span className="material-symbols-outlined" style={{ fontSize: '14px', color: '#94A3B8', flexShrink: 0 }}>
                  {GRAN.find(g => g.key === granularity)?.icon}
                </span>
                <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '11px', color: '#475569', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {formatLabel(item.timestamp, granularity, lang)}
                </span>
                {item.count > 1 && (
                  <span style={{ flexShrink: 0, padding: '2px 6px', borderRadius: '999px', background: '#F1F5F9', color: '#64748B', border: '1px solid #E2E8F0', fontFamily: 'JetBrains Mono,monospace', fontSize: '10px' }}>
                    {item.count} data
                  </span>
                )}
              </div>
              <span style={{ flexShrink: 0, display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: '999px', fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', fontWeight: 700, background: item.status === 'normal' ? '#DCFCE7' : '#FEF9C3', color: item.status === 'normal' ? '#16A34A' : '#CA8A04', border: `1px solid ${item.status === 'normal' ? '#86EFAC' : '#FDE047'}` }}>
                <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: item.status === 'normal' ? '#16A34A' : '#CA8A04' }} />
                {item.status.toUpperCase()}
              </span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', paddingTop: '10px', borderTop: '1px solid #F1F5F9' }}>
              <div>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '10px', color: '#94A3B8', display: 'block' }}>{t(lang,'tempCol')}</span>
                <span style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '13px', color: '#0D9488' }}>{item.suhu} °C</span>
              </div>
              <div>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '10px', color: '#94A3B8', display: 'block' }}>{t(lang,'phCol')}</span>
                <span style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '13px', color: '#7C3AED' }}>{item.ph} pH</span>
              </div>
              <div>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '10px', color: '#94A3B8', display: 'block' }}>{t(lang,'waterCol')}</span>
                <span style={{ fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, fontSize: '13px', color: '#2563EB' }}>{item.jarak_air} cm</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
