import React from 'react'
import { useApp } from '../context/AppContext'
import Sparkline from '../components/Sparkline'
import { t } from '../i18n'

export default function HomeScreen() {
  const {
    telemetry, history, pump, aerator, rpm,
    autoMode, togglePump, toggleAerator, setActiveTab, connectionStatus, language
  } = useApp()

  const lang = language || 'id'
  const tempHistory = history.map((h) => h.suhu).reverse()
  const phHistory   = history.map((h) => h.ph).reverse()
  const tempMin = tempHistory.length ? Math.min(...tempHistory) : 27.8
  const tempMax = tempHistory.length ? Math.max(...tempHistory) : 29.4
  const phMin   = phHistory.length   ? Math.min(...phHistory)   : 6.9
  const phMax   = phHistory.length   ? Math.max(...phHistory)   : 7.8
  const waterCapacity = Math.min(100, Math.max(10, Math.round(100 - ((telemetry.jarak_air - 30) / 50) * 100)))
  const isNormal = telemetry.status === 'normal'
  const suhuOk = telemetry.suhu >= 27.0 && telemetry.suhu <= 32.0
  const phOk   = telemetry.ph  >= 6.8  && telemetry.ph  <= 8.8

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', paddingBottom: '112px' }}>

      {/* Hero Banner */}
      <div style={{
        borderRadius: '24px', padding: '20px', marginTop: '16px', position: 'relative', overflow: 'hidden',
        background: 'linear-gradient(135deg, #0D9488 0%, #0891B2 60%, #2563EB 100%)'
      }}>
        <div style={{ position: 'absolute', top: -40, right: -40, width: 140, height: 140, borderRadius: '50%', background: 'rgba(255,255,255,0.07)' }} />
        <div style={{ position: 'absolute', bottom: -30, left: -30, width: 100, height: 100, borderRadius: '50%', background: 'rgba(255,255,255,0.07)' }} />
        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div>
              <p style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', color: 'rgba(255,255,255,0.65)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: '2px' }}>
                {t(lang, 'pond')}
              </p>
              <h1 style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 800, fontSize: '22px', color: '#ffffff', lineHeight: 1.2 }}>
                {t(lang, 'greeting')}
              </h1>
              <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '12px', color: 'rgba(255,255,255,0.7)', marginTop: '4px' }}>
                {new Date().toLocaleDateString(lang === 'en' ? 'en-US' : 'id-ID', { weekday: 'long', day: 'numeric', month: 'long' })}
              </p>
            </div>
            <div style={{
              display: 'flex', alignItems: 'center', gap: '6px', padding: '6px 12px', borderRadius: '999px',
              background: 'rgba(255,255,255,0.18)', border: '1px solid rgba(255,255,255,0.25)',
              fontSize: '10px', fontFamily: 'JetBrains Mono, monospace', fontWeight: 700, color: '#ffffff'
            }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#ffffff' }} />
              {connectionStatus === 'connected' ? t(lang, 'live') : t(lang, 'off')}
            </div>
          </div>

          <div style={{
            display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 14px', borderRadius: '16px',
            background: isNormal ? 'rgba(255,255,255,0.15)' : 'rgba(239,68,68,0.25)',
            border: isNormal ? '1px solid rgba(255,255,255,0.2)' : '1px solid rgba(239,68,68,0.4)'
          }}>
            <div style={{ width: 40, height: 40, borderRadius: '12px', flexShrink: 0, background: 'rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span className="material-symbols-outlined" style={{ color: '#ffffff', fontSize: '22px' }}>
                {isNormal ? 'verified' : 'warning'}
              </span>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '13px', color: '#ffffff' }}>
                {isNormal ? t(lang, 'allNormal') : t(lang, 'needAttention')}
              </p>
              <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '11px', color: 'rgba(255,255,255,0.7)', marginTop: '2px' }}>
                {isNormal ? t(lang, 'normalDetail', telemetry.do_terlarut, telemetry.salinitas, telemetry.kekeruhan) : t(lang, 'openMonitor')}
              </p>
            </div>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', fontWeight: 700, flexShrink: 0, padding: '4px 10px', borderRadius: '10px', background: 'rgba(255,255,255,0.2)', color: '#ffffff', border: '1px solid rgba(255,255,255,0.25)' }}>
              {isNormal ? t(lang, 'safe') : t(lang, 'warn')}
            </span>
          </div>
        </div>
      </div>

      {/* Section title */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 2px' }}>
        <h3 style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '15px', color: '#0F172A' }}>
          {t(lang, 'sensorParam')}
        </h3>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 10px', borderRadius: '999px', background: '#CCFBF1', border: '1px solid #99F6E4' }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#0D9488' }} />
          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', fontWeight: 700, color: '#0D9488' }}>{t(lang, 'live')}</span>
        </div>
      </div>

      {/* Suhu & pH */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        {/* Suhu */}
        <div style={{ borderRadius: '20px', overflow: 'hidden', border: '1px solid #E2E8F0', boxShadow: '0 2px 12px rgba(15,23,42,0.08)', backgroundColor: '#ffffff' }}>
          <div style={{ padding: '14px 14px 10px', background: suhuOk ? 'linear-gradient(135deg,#CCFBF1,#A7F3D0)' : 'linear-gradient(135deg,#FEE2E2,#FECACA)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
              <div style={{ width: 36, height: 36, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: suhuOk ? 'linear-gradient(135deg,#0D9488,#0F766E)' : 'linear-gradient(135deg,#DC2626,#B91C1C)' }}>
                <span className="material-symbols-outlined" style={{ color: '#fff', fontSize: '18px' }}>thermostat</span>
              </div>
              <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', fontWeight: 700, padding: '2px 8px', borderRadius: '999px', background: suhuOk ? '#0D9488' : '#DC2626', color: '#ffffff' }}>
                {suhuOk ? 'NORMAL' : t(lang, 'warn')}
              </span>
            </div>
            <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '11px', fontWeight: 600, color: '#0F172A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t(lang, 'tempWater')}</p>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '2px', marginTop: '2px' }}>
              <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 800, fontSize: '28px', color: '#0F172A' }}>{telemetry.suhu}</span>
              <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '13px', fontWeight: 500, color: '#475569', marginLeft: '2px' }}>°C</span>
            </div>
          </div>
          <div style={{ padding: '8px 12px 12px', backgroundColor: '#ffffff' }}>
            <p style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', color: '#475569', marginBottom: '6px' }}>{tempMin}° – {tempMax}°</p>
            <Sparkline data={tempHistory} strokeColor="#0D9488" height={32} />
          </div>
        </div>

        {/* pH */}
        <div style={{ borderRadius: '20px', overflow: 'hidden', border: '1px solid #E2E8F0', boxShadow: '0 2px 12px rgba(15,23,42,0.08)', backgroundColor: '#ffffff' }}>
          <div style={{ padding: '14px 14px 10px', background: phOk ? 'linear-gradient(135deg,#EDE9FE,#DDD6FE)' : 'linear-gradient(135deg,#FEE2E2,#FECACA)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
              <div style={{ width: 36, height: 36, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: phOk ? 'linear-gradient(135deg,#7C3AED,#6D28D9)' : 'linear-gradient(135deg,#DC2626,#B91C1C)' }}>
                <span className="material-symbols-outlined" style={{ color: '#fff', fontSize: '18px' }}>opacity</span>
              </div>
              <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', fontWeight: 700, padding: '2px 8px', borderRadius: '999px', background: phOk ? '#7C3AED' : '#DC2626', color: '#ffffff' }}>
                {phOk ? 'NORMAL' : t(lang, 'warn')}
              </span>
            </div>
            <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '11px', fontWeight: 600, color: '#0F172A', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{t(lang, 'phWater')}</p>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: '2px', marginTop: '2px' }}>
              <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 800, fontSize: '28px', color: '#0F172A' }}>{telemetry.ph}</span>
              <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '13px', fontWeight: 500, color: '#475569', marginLeft: '2px' }}>pH</span>
            </div>
          </div>
          <div style={{ padding: '8px 12px 12px', backgroundColor: '#ffffff' }}>
            <p style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', color: '#475569', marginBottom: '6px' }}>{phMin} – {phMax}</p>
            <Sparkline data={phHistory} strokeColor="#7C3AED" height={32} />
          </div>
        </div>
      </div>

      {/* Ketinggian Air */}
      <div style={{ borderRadius: '20px', overflow: 'hidden', border: '1px solid #E2E8F0', boxShadow: '0 2px 12px rgba(15,23,42,0.08)', backgroundColor: '#ffffff' }}>
        <div style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'linear-gradient(90deg,#DBEAFE,#E0F2FE)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: 38, height: 38, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg,#2563EB,#0284C7)' }}>
              <span className="material-symbols-outlined" style={{ color: '#fff', fontSize: '19px' }}>waves</span>
            </div>
            <div>
              <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '13px', color: '#0F172A' }}>{t(lang, 'waterLevel')}</p>
              <p style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', color: '#475569' }}>{t(lang, 'ideal')}: 38–65 cm</p>
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 800, fontSize: '24px', color: '#0F172A' }}>{telemetry.jarak_air}</span>
            <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '13px', color: '#475569' }}> cm</span>
          </div>
        </div>
        <div style={{ padding: '12px 16px', backgroundColor: '#ffffff' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', marginBottom: '8px' }}>
            <span style={{ color: '#475569' }}>{t(lang, 'capacity', waterCapacity)}</span>
            <span style={{ color: '#2563EB', fontWeight: 700 }}>{t(lang, 'safeZone')}</span>
          </div>
          <div style={{ width: '100%', height: '10px', borderRadius: '999px', backgroundColor: '#E2E8F0', overflow: 'hidden' }}>
            <div style={{ height: '100%', borderRadius: '999px', transition: 'width 0.7s ease', width: `${waterCapacity}%`, background: 'linear-gradient(90deg,#2563EB,#06B6D4)' }} />
          </div>
        </div>
      </div>

      {/* Aktuator */}
      <div style={{ borderRadius: '20px', overflow: 'hidden', border: '1px solid #E2E8F0', boxShadow: '0 2px 12px rgba(15,23,42,0.08)', backgroundColor: '#ffffff' }}>
        <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'linear-gradient(90deg,#F0FDF4,#CCFBF1)', borderBottom: '1px solid #E2E8F0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span className="material-symbols-outlined" style={{ color: '#0D9488', fontSize: '20px' }}>electrical_services</span>
            <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '14px', color: '#0F172A' }}>{t(lang, 'actuatorRelay')}</span>
          </div>
          <span style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '10px', fontWeight: 700, padding: '4px 10px', borderRadius: '999px', display: 'flex', alignItems: 'center', gap: '5px', background: autoMode ? '#CCFBF1' : '#F1F5F9', color: autoMode ? '#0D9488' : '#475569', border: autoMode ? '1px solid #99F6E4' : '1px solid #CBD5E1' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '12px' }}>{autoMode ? 'smart_toy' : 'tune'}</span>
            {autoMode ? t(lang, 'autoMode') : t(lang, 'manualMode')}
          </span>
        </div>

        <div style={{ padding: '12px' }}>
          {autoMode && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 12px', borderRadius: '12px', background: '#CCFBF1', border: '1px solid #99F6E4', marginBottom: '12px' }}>
              <span className="material-symbols-outlined" style={{ color: '#0D9488', fontSize: '16px', flexShrink: 0 }}>info</span>
              <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '11px', color: '#0F172A' }}>
                {t(lang, 'relayLocked')}<strong style={{ color: '#0D9488' }}>{t(lang, 'relayLockedLink')}</strong>{t(lang, 'relayLockedEnd')}
              </p>
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {/* Aerator */}
            <button type="button" onClick={toggleAerator} disabled={autoMode}
              style={{ padding: '14px', borderRadius: '16px', display: 'flex', flexDirection: 'column', gap: '10px', textAlign: 'left', border: aerator && !autoMode ? '1.5px solid #0D9488' : '1px solid #E2E8F0', background: aerator && !autoMode ? '#CCFBF1' : '#F8FAFC', opacity: autoMode ? 0.45 : 1, cursor: autoMode ? 'not-allowed' : 'pointer', transition: 'all 0.2s' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ width: 36, height: 36, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: aerator && !autoMode ? '#0D9488' : '#E2E8F0' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: '20px', color: aerator && !autoMode ? '#ffffff' : '#94A3B8' }}>{autoMode ? 'lock' : 'mode_fan'}</span>
                </div>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', fontWeight: 700, padding: '2px 8px', borderRadius: '8px', background: aerator && !autoMode ? '#0D9488' : '#E2E8F0', color: aerator && !autoMode ? '#ffffff' : '#94A3B8' }}>
                  {aerator ? 'ON' : 'OFF'}
                </span>
              </div>
              <div>
                <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '12px', color: '#0F172A' }}>{t(lang, 'aerator')}</p>
                <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '11px', color: aerator && !autoMode ? '#0D9488' : '#94A3B8', marginTop: '2px', fontWeight: aerator && !autoMode ? 600 : 400 }}>
                  {autoMode ? t(lang, 'auto') : aerator ? t(lang, 'rpm', rpm) : t(lang, 'standby')}
                </p>
              </div>
            </button>

            {/* Pompa */}
            <button type="button" onClick={togglePump} disabled={autoMode}
              style={{ padding: '14px', borderRadius: '16px', display: 'flex', flexDirection: 'column', gap: '10px', textAlign: 'left', border: pump && !autoMode ? '1.5px solid #F97316' : '1px solid #E2E8F0', background: pump && !autoMode ? '#FFF7ED' : '#F8FAFC', opacity: autoMode ? 0.45 : 1, cursor: autoMode ? 'not-allowed' : 'pointer', transition: 'all 0.2s' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ width: 36, height: 36, borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: pump && !autoMode ? '#F97316' : '#E2E8F0' }}>
                  <span className="material-symbols-outlined" style={{ fontSize: '20px', color: pump && !autoMode ? '#ffffff' : '#94A3B8' }}>{autoMode ? 'lock' : 'water_pump'}</span>
                </div>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '10px', fontWeight: 700, padding: '2px 8px', borderRadius: '8px', background: pump && !autoMode ? '#F97316' : '#E2E8F0', color: pump && !autoMode ? '#ffffff' : '#94A3B8' }}>
                  {pump ? 'ON' : 'OFF'}
                </span>
              </div>
              <div>
                <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '12px', color: '#0F172A' }}>{t(lang, 'pump')}</p>
                <p style={{ fontFamily: 'Plus Jakarta Sans, sans-serif', fontSize: '11px', color: pump && !autoMode ? '#F97316' : '#94A3B8', marginTop: '2px', fontWeight: pump && !autoMode ? 600 : 400 }}>
                  {autoMode ? t(lang, 'auto') : pump ? t(lang, 'active') : t(lang, 'standby')}
                </p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
        <button onClick={() => setActiveTab('monitoring')} type="button"
          style={{ height: '48px', borderRadius: '16px', background: 'linear-gradient(135deg,#0D9488,#0891B2)', color: '#ffffff', fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', border: 'none', cursor: 'pointer', boxShadow: '0 4px 12px rgba(13,148,136,0.35)' }}>
          <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>analytics</span>
          {t(lang, 'monitoring')}
        </button>
        <button onClick={() => setActiveTab('kontrol')} type="button"
          style={{ height: '48px', borderRadius: '16px', background: 'linear-gradient(135deg,#F97316,#EA580C)', color: '#ffffff', fontFamily: 'Plus Jakarta Sans, sans-serif', fontWeight: 700, fontSize: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', border: 'none', cursor: 'pointer', boxShadow: '0 4px 12px rgba(249,115,22,0.35)' }}>
          <span className="material-symbols-outlined" style={{ fontSize: '18px' }}>tune</span>
          {t(lang, 'control')}
        </button>
      </div>
    </div>
  )
}
