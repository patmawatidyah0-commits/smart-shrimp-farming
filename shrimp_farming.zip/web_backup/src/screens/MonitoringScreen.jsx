import React, { useState } from 'react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

const C = { white: '#ffffff', bg: '#F8FAFC', textDark: '#0F172A', textMid: '#334155', textLight: '#64748B', border: '#E2E8F0', shadow: '0 2px 12px rgba(15,23,42,0.08)' }

export default function MonitoringScreen() {
  const { telemetry, history, thresholds, language } = useApp()
  const lang = language || 'id'
  const [sel, setSel] = useState('suhu')

  const configs = {
    suhu: {
      label: t(lang, 'tempWater'), unit: '°C', sensor: 'DS18B20 Digital',
      min: thresholds.suhuMin, max: thresholds.suhuMax,
      color: '#0D9488', grad: 'linear-gradient(135deg,#0D9488,#0F766E)',
      bgGrad: 'linear-gradient(135deg,#CCFBF1,#A7F3D0)',
      icon: 'thermostat', ex: (d) => d.suhu,
      desc: t(lang, 'suhuDesc')
    },
    ph: {
      label: t(lang, 'phWater'), unit: 'pH', sensor: 'Analog pH Probe (ADC)',
      min: thresholds.phMin, max: thresholds.phMax,
      color: '#7C3AED', grad: 'linear-gradient(135deg,#7C3AED,#6D28D9)',
      bgGrad: 'linear-gradient(135deg,#EDE9FE,#DDD6FE)',
      icon: 'opacity', ex: (d) => d.ph,
      desc: t(lang, 'phDesc')
    },
    jarak_air: {
      label: t(lang, 'waterLevel'), unit: 'cm', sensor: 'HC-SR04 Ultrasonik',
      min: thresholds.jarakMin, max: thresholds.jarakMax,
      color: '#2563EB', grad: 'linear-gradient(135deg,#2563EB,#0284C7)',
      bgGrad: 'linear-gradient(135deg,#DBEAFE,#E0F2FE)',
      icon: 'waves', ex: (d) => d.jarak_air,
      desc: t(lang, 'jarakDesc')
    }
  }

  const cfg = configs[sel]
  const values = history.slice(0, 20).reverse().map(cfg.ex)
  const minVal = values.length ? Math.min(...values) : cfg.min
  const maxVal = values.length ? Math.max(...values) : cfg.max
  const avgVal = values.length ? (values.reduce((a, b) => a + b, 0) / values.length).toFixed(1) : 0
  const curVal = cfg.ex(telemetry)
  const isOk = curVal >= cfg.min && curVal <= cfg.max

  const cH = 130, cW = 320, px = 16, py = 16
  const iW = cW - px * 2, iH = cH - py * 2
  const vMin = Math.min(minVal, cfg.min - 0.5), vMax = Math.max(maxVal, cfg.max + 0.5), vR = vMax - vMin || 1
  const pts = values.map((v, i) => ({
    x: +(px + (i / Math.max(1, values.length - 1)) * iW).toFixed(1),
    y: +(cH - py - ((v - vMin) / vR) * iH).toFixed(1)
  }))
  let lineD = pts.length ? `M ${pts[0].x},${pts[0].y}` : ''
  for (let i = 1; i < pts.length; i++) {
    const m = (pts[i-1].x + pts[i].x) / 2
    lineD += ` C ${m},${pts[i-1].y} ${m},${pts[i].y} ${pts[i].x},${pts[i].y}`
  }
  const areaD = pts.length ? `${lineD} L ${pts[pts.length-1].x},${cH-py} L ${pts[0].x},${cH-py} Z` : ''
  const iTopY = cH - py - ((cfg.max - vMin) / vR) * iH
  const iBotY = cH - py - ((cfg.min - vMin) / vR) * iH

  const card = { borderRadius: '20px', overflow: 'hidden', border: `1px solid ${C.border}`, boxShadow: C.shadow, backgroundColor: C.white }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', paddingBottom: '112px' }}>
      <div style={{ marginTop: '16px' }}>
        <h2 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '20px', color: C.textDark }}>{t(lang, 'monitorTitle')}</h2>
        <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight, marginTop: '2px' }}>{t(lang, 'monitorSub')}</p>
      </div>

      {/* Selector */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
        {Object.entries(configs).map(([key, c]) => {
          const v = c.ex(telemetry), ok = v >= c.min && v <= c.max, active = sel === key
          return (
            <button key={key} onClick={() => setSel(key)}
              style={{ padding: '12px 8px', borderRadius: '16px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', border: active ? 'none' : `1px solid ${C.border}`, background: active ? c.grad : C.white, cursor: 'pointer', boxShadow: active ? `0 4px 14px ${c.color}40` : C.shadow, transition: 'all 0.2s' }}>
              <span className="material-symbols-outlined" style={{ fontSize: '22px', color: active ? C.white : C.textLight }}>{c.icon}</span>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 600, fontSize: '10px', color: active ? 'rgba(255,255,255,0.8)' : C.textLight }}>{c.label}</span>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: '1px' }}>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '15px', color: active ? C.white : C.textDark }}>{v}</span>
                <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '9px', color: active ? 'rgba(255,255,255,0.7)' : C.textLight }}> {c.unit}</span>
              </div>
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '9px', fontWeight: 700, padding: '2px 8px', borderRadius: '999px', background: ok ? (active ? 'rgba(255,255,255,0.25)' : '#DCFCE7') : (active ? 'rgba(239,68,68,0.3)' : '#FEE2E2'), color: ok ? (active ? C.white : '#16A34A') : (active ? C.white : '#DC2626') }}>
                {ok ? 'OK' : t(lang, 'warn')}
              </span>
            </button>
          )
        })}
      </div>

      {/* Chart Card */}
      <div style={card}>
        <div style={{ padding: '16px', borderBottom: `1px solid ${C.border}`, background: cfg.bgGrad }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{ width: 42, height: 42, borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: cfg.grad }}>
                <span className="material-symbols-outlined" style={{ color: C.white, fontSize: '22px' }}>{cfg.icon}</span>
              </div>
              <div>
                <h3 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark }}>{cfg.label}</h3>
                <p style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', color: C.textLight, marginTop: '1px' }}>{cfg.sensor}</p>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: '2px', justifyContent: 'flex-end' }}>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '30px', color: cfg.color }}>{curVal}</span>
                <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '14px', color: C.textLight }}> {cfg.unit}</span>
              </div>
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', fontWeight: 700, padding: '2px 10px', borderRadius: '999px', background: isOk ? cfg.color : '#DC2626', color: C.white }}>
                {isOk ? 'NORMAL' : 'WARNING'}
              </span>
            </div>
          </div>
          <p style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textMid, marginTop: '10px' }}>{cfg.desc}</p>
        </div>

        <div style={{ padding: '16px', backgroundColor: C.white }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', marginBottom: '8px' }}>
            <span style={{ color: C.textLight }}>{t(lang, 'idealZone', cfg.min, cfg.max, cfg.unit)}</span>
            <span style={{ color: cfg.color, fontWeight: 700 }}>{t(lang, 'points')}</span>
          </div>
          <div style={{ borderRadius: '14px', backgroundColor: '#F8FAFC', padding: '12px', border: `1px solid ${C.border}` }}>
            <svg width="100%" viewBox={`0 0 ${cW} ${cH}`} style={{ height: 110, display: 'block' }}>
              <rect x={px} y={iTopY} width={iW} height={Math.max(2, iBotY - iTopY)} fill={cfg.color} fillOpacity="0.1" rx="4" />
              <line x1={px} y1={iTopY} x2={px+iW} y2={iTopY} stroke={cfg.color} strokeDasharray="4 3" strokeWidth="1.5" opacity="0.5" />
              <line x1={px} y1={iBotY} x2={px+iW} y2={iBotY} stroke={cfg.color} strokeDasharray="4 3" strokeWidth="1.5" opacity="0.5" />
              {pts.length > 1 && <>
                <path d={areaD} fill={cfg.color} fillOpacity="0.08" />
                <path d={lineD} fill="none" stroke={cfg.color} strokeWidth="2.5" strokeLinecap="round" />
                {pts.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={i === pts.length - 1 ? 5 : 3} fill={i === pts.length - 1 ? cfg.color : C.white} stroke={cfg.color} strokeWidth="2" />)}
              </>}
            </svg>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', padding: '0 16px 16px' }}>
          {[{ label: t(lang,'min'), val: minVal, accent: false }, { label: t(lang,'avg'), val: avgVal, accent: true }, { label: t(lang,'max'), val: maxVal, accent: false }].map((s, i) => (
            <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 8px', borderRadius: '14px', background: s.accent ? cfg.bgGrad : '#F8FAFC', border: `1px solid ${s.accent ? cfg.color + '30' : C.border}` }}>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '10px', color: C.textLight }}>{s.label}</span>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '16px', color: s.accent ? cfg.color : C.textDark, marginTop: '2px' }}>{s.val}</span>
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '9px', color: C.textLight }}>{cfg.unit}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Sensor Specs */}
      <div style={card}>
        <div style={{ padding: '16px' }}>
          <h4 style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 700, fontSize: '14px', color: C.textDark, display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <span className="material-symbols-outlined" style={{ color: '#0D9488', fontSize: '18px' }}>memory</span>
            {t(lang, 'sensorSpec')}
          </h4>
          {t(lang, 'sensorRows').map(([label, val], i, arr) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: i < arr.length - 1 ? `1px solid ${C.border}` : 'none' }}>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '12px', color: C.textLight }}>{label}</span>
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '11px', fontWeight: 600, color: C.textDark }}>{val}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
