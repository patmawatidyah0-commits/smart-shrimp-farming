class SimulatorService {
  constructor() {
    this.timer = null
    this.callback = null
    this.state = {
      device_id: 'ESP32_TAMBAK_01',
      suhu: 28.5,
      ph: 7.2,
      jarak_air: 45,
      status: 'normal',
      do_terlarut: 6.8,
      salinitas: 18,
      kekeruhan: 32,
      pompa: false,
      aerator: true,
      rpm: 120,
      doc_day: 42,
      pool_code: 'Kolam Tambak A1'
    }
    this.anomaly = null
  }

  start(onTelemetry) {
    this.callback = onTelemetry
    if (this.timer) {
      clearInterval(this.timer)
    }

    this.timer = setInterval(() => {
      this.tick()
    }, 3000)

    this.tick()
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer)
      this.timer = null
    }
  }

  setAnomaly(type) {
    this.anomaly = type
    this.tick()
  }

  clearAnomaly() {
    this.anomaly = null
    this.state.suhu = 28.5
    this.state.ph = 7.2
    this.state.jarak_air = 45
    this.state.status = 'normal'
    this.tick()
  }

  setActuator(command) {
    if (command === 'PUMP_ON') {
      this.state.pompa = true
    } else if (command === 'PUMP_OFF') {
      this.state.pompa = false
    } else if (command === 'AERATOR_ON') {
      this.state.aerator = true
      this.state.rpm = 120
    } else if (command === 'AERATOR_OFF') {
      this.state.aerator = false
      this.state.rpm = 0
    }
    this.tick()
  }

  // Update state internal simulator tanpa trigger tick (hindari race condition dengan React state)
  setActuatorSilent(command) {
    if (command === 'PUMP_ON') {
      this.state.pompa = true
    } else if (command === 'PUMP_OFF') {
      this.state.pompa = false
    } else if (command === 'AERATOR_ON') {
      this.state.aerator = true
      this.state.rpm = 120
    } else if (command === 'AERATOR_OFF') {
      this.state.aerator = false
      this.state.rpm = 0
    }
    // Tidak memanggil this.tick() — React state sudah diupdate duluan
  }

  tick() {
    let currentSuhu = 28.5 + (Math.sin(Date.now() / 15000) * 0.7) + ((Math.random() - 0.5) * 0.2)
    let currentPh = 7.2 + (Math.cos(Date.now() / 20000) * 0.3) + ((Math.random() - 0.5) * 0.1)
    let currentJarak = 45 + Math.round((Math.sin(Date.now() / 30000) * 3) + ((Math.random() - 0.5) * 1.5))

    if (this.state.pompa) {
      currentJarak = Math.max(35, currentJarak - 4)
    }

    if (this.anomaly === 'HIGH_TEMP') {
      currentSuhu = 33.4
    } else if (this.anomaly === 'LOW_PH') {
      currentPh = 6.1
    } else if (this.anomaly === 'LOW_WATER') {
      currentJarak = 68
    }

    currentSuhu = Number(currentSuhu.toFixed(1))
    currentPh = Number(currentPh.toFixed(1))
    currentJarak = Math.round(currentJarak)

    let status = 'normal'
    if (currentSuhu > 31.5 || currentSuhu < 27.0 || currentPh < 6.8 || currentPh > 8.8 || currentJarak > 65 || currentJarak < 38) {
      status = 'peringatan'
    }

    this.state.suhu = currentSuhu
    this.state.ph = currentPh
    this.state.jarak_air = currentJarak
    this.state.status = status

    const telemetry = {
      device_id: this.state.device_id,
      suhu: currentSuhu,
      ph: currentPh,
      jarak_air: currentJarak,
      status: status,
      do_terlarut: Number((6.8 + (Math.random() * 0.2 - 0.1)).toFixed(1)),
      salinitas: 18,
      kekeruhan: 32,
      pompa: this.state.pompa,
      aerator: this.state.aerator,
      rpm: this.state.rpm,
      timestamp: Date.now()
    }

    if (this.callback) {
      this.callback(telemetry)
    }
  }
}

export const simulatorService = new SimulatorService()
