// Firebase Service — Smart Shrimp Farming
// Ganti nilai config di bawah dengan config dari Firebase Console kamu
// https://console.firebase.google.com → Project Settings → Your Apps → SDK setup

import { initializeApp } from 'firebase/app'
import { getDatabase, ref, push, query, orderByChild, limitToLast, onValue, off } from 'firebase/database'

const firebaseConfig = {
  apiKey: "AIzaSyBs-X8vLW8RsYMVo0fydMkK5qwq1Y10lHs",
  authDomain: "smart-shrimp-farming-a5a9a.firebaseapp.com",
  databaseURL: "https://smart-shrimp-farming-a5a9a-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "smart-shrimp-farming-a5a9a",
  storageBucket: "smart-shrimp-farming-a5a9a.firebasestorage.app",
  messagingSenderId: "33636757064",
  appId: "1:33636757064:web:feb7680c18285247b1327d",
  measurementId: "G-B271LXM8JR"
}

let app = null
let db = null
let isConfigured = false

function init() {
  if (app) return
  try {
    app = initializeApp(firebaseConfig)
    db = getDatabase(app)
    isConfigured = true
    console.log('[Firebase] Terhubung ke Realtime Database.')
  } catch (e) {
    console.error('[Firebase] Gagal inisialisasi:', e)
    isConfigured = false
  }
}

// Simpan satu record history sensor ke Firebase
export async function saveHistoryRecord(record) {
  init()
  if (!isConfigured || !db) return false
  try {
    const historyRef = ref(db, 'tambak/history')
    await push(historyRef, {
      ...record,
      timestamp: record.timestamp || Date.now()
    })
    return true
  } catch (e) {
    console.error('[Firebase] Gagal simpan history:', e)
    return false
  }
}

// Ambil history N hari terakhir dari Firebase (realtime listener)
// onData(records[]) dipanggil setiap ada perubahan
// Returns unsubscribe function
export function listenHistory(days = 7, onData) {
  init()
  if (!isConfigured || !db) {
    onData([])
    return () => {}
  }
  const since = Date.now() - days * 24 * 60 * 60 * 1000
  const historyRef = query(
    ref(db, 'tambak/history'),
    orderByChild('timestamp'),
    limitToLast(500)
  )
  const unsubscribe = onValue(historyRef, (snapshot) => {
    const data = snapshot.val()
    if (!data) { onData([]); return }
    const records = Object.entries(data)
      .map(([id, val]) => ({ id, ...val }))
      .filter((r) => r.timestamp >= since)
      .sort((a, b) => b.timestamp - a.timestamp)
    onData(records)
  })
  return () => off(historyRef, 'value', unsubscribe)
}

export function isFirebaseReady() {
  return isConfigured
}
