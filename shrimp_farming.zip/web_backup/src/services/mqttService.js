import mqtt from 'mqtt'

class MqttService {
  constructor() {
    this.client = null
    this.listeners = new Set()
    this.statusListeners = new Set()
    this.connectionStatus = 'disconnected'
  }

  connect(config) {
    if (this.client) {
      this.disconnect()
    }

    const {
      protocol = 'wss',
      host = 'broker.emqx.io',
      port = 8084,
      path = '/mqtt',
      clientId = `shrimp_mobile_${Math.random().toString(16).substring(2, 10)}`,
      username = '',
      password = '',
      topicSensor = 'tambak/sensor',
      topicControl = 'tambak/control'
    } = config

    const url = `${protocol}://${host}:${port}${path}`
    this.updateStatus('connecting')

    try {
      this.client = mqtt.connect(url, {
        clientId,
        username: username || undefined,
        password: password || undefined,
        clean: true,
        connectTimeout: 5000,
        reconnectPeriod: 4000
      })

      this.client.on('connect', () => {
        this.updateStatus('connected')
        this.client.subscribe(topicSensor, { qos: 0 })
      })

      this.client.on('message', (topic, payload) => {
        try {
          const parsed = JSON.parse(payload.toString())
          this.notifyMessage(topic, parsed)
        } catch {
          this.notifyMessage(topic, payload.toString())
        }
      })

      this.client.on('error', (err) => {
        this.updateStatus('error', err.message)
      })

      this.client.on('close', () => {
        this.updateStatus('disconnected')
      })

      this.client.on('offline', () => {
        this.updateStatus('offline')
      })
    } catch (err) {
      this.updateStatus('error', err.message)
    }
  }

  publishCommand(topic, commandObj) {
    if (!this.client || !this.client.connected) {
      return false
    }
    const payload = JSON.stringify(commandObj)
    this.client.publish(topic, payload, { qos: 0 })
    return true
  }

  disconnect() {
    if (this.client) {
      try {
        this.client.end(true)
      } catch {
      }
      this.client = null
      this.updateStatus('disconnected')
    }
  }

  onMessage(callback) {
    this.listeners.add(callback)
    return () => this.listeners.delete(callback)
  }

  onStatusChange(callback) {
    this.statusListeners.add(callback)
    callback(this.connectionStatus)
    return () => this.statusListeners.delete(callback)
  }

  notifyMessage(topic, data) {
    for (const listener of this.listeners) {
      listener(topic, data)
    }
  }

  updateStatus(status, error = null) {
    this.connectionStatus = status
    for (const listener of this.statusListeners) {
      listener(status, error)
    }
  }
}

export const mqttService = new MqttService()
