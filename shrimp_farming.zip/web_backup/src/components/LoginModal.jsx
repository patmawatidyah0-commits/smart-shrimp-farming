import React, { useState } from 'react'
import { useApp } from '../context/AppContext'

export default function LoginModal() {
  const { isLoggedIn, login } = useApp()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [showForm, setShowForm] = useState(false)

  if (isLoggedIn) return null

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!email || !password) {
      setError('Email dan kata sandi wajib diisi')
      return
    }
    const success = login(email, password)
    if (!success) setError('Email atau kata sandi salah')
  }

  const handleQuickLogin = () => {
    login('admin@tambakudang.id', 'password123')
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-b from-primary to-primary-container p-6">
      <div className="w-full max-w-sm flex flex-col items-center gap-6">

        {/* Logo & Title */}
        <div className="flex flex-col items-center gap-3 text-white text-center">
          <div className="w-20 h-20 rounded-3xl bg-white/20 backdrop-blur flex items-center justify-center shadow-lg border border-white/30">
            <span className="material-symbols-outlined text-white text-[44px]">water_drop</span>
          </div>
          <div>
            <h1 className="font-sans font-extrabold text-2xl tracking-tight">Smart Shrimp</h1>
            <p className="font-sans text-sm text-white/80 mt-0.5">Sistem Budidaya Tambak Udang Cerdas</p>
          </div>
        </div>

        {/* Card */}
        <div className="w-full bg-white rounded-3xl shadow-2xl p-5 flex flex-col gap-4">

          {/* Quick Login */}
          {!showForm && (
            <>
              <button
                type="button"
                onClick={handleQuickLogin}
                className="w-full h-13 py-3.5 rounded-2xl bg-primary text-white font-sans text-sm font-bold flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] transition-all"
              >
                <span className="material-symbols-outlined text-[20px]">login</span>
                Masuk ke Aplikasi
              </button>

              <div className="flex items-center gap-2">
                <div className="flex-1 h-px bg-slate-200" />
                <span className="font-sans text-[11px] text-slate-400">atau masuk dengan akun lain</span>
                <div className="flex-1 h-px bg-slate-200" />
              </div>

              <button
                type="button"
                onClick={() => setShowForm(true)}
                className="w-full h-11 rounded-2xl bg-surface-container text-on-surface font-sans text-sm font-bold flex items-center justify-center gap-2 border border-outline-variant/30 active:scale-[0.98] transition-all"
              >
                <span className="material-symbols-outlined text-[18px] text-primary">person</span>
                Login Manual
              </button>
            </>
          )}

          {/* Manual Form */}
          {showForm && (
            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              <button
                type="button"
                onClick={() => { setShowForm(false); setError('') }}
                className="flex items-center gap-1 text-on-surface-variant font-sans text-xs mb-1 w-fit"
              >
                <span className="material-symbols-outlined text-[16px]">arrow_back</span>
                Kembali
              </button>

              {error && (
                <div className="p-3 rounded-xl bg-red-50 text-red-700 font-sans text-xs font-semibold border border-red-200">
                  {error}
                </div>
              )}

              <div>
                <label className="block font-sans text-xs text-on-surface-variant mb-1 font-medium">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-surface-container-lowest border border-outline-variant/30 font-sans text-sm text-on-surface focus:outline-none focus:border-primary"
                  placeholder="nama@tambakudang.id"
                  autoComplete="email"
                />
              </div>

              <div>
                <label className="block font-sans text-xs text-on-surface-variant mb-1 font-medium">Kata Sandi</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-surface-container-lowest border border-outline-variant/30 font-sans text-sm text-on-surface focus:outline-none focus:border-primary"
                  placeholder="••••••••"
                  autoComplete="current-password"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 mt-1 rounded-xl bg-primary text-white font-sans text-sm font-bold flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] transition-all"
              >
                <span className="material-symbols-outlined text-[20px]">login</span>
                Masuk
              </button>
            </form>
          )}
        </div>

        <p className="font-sans text-[11px] text-white/60 text-center">
          Smart Shrimp Farming v1.0 · IoT &amp; MQTT
        </p>
      </div>
    </div>
  )
}
