import React from 'react'

export default function Sparkline({ data = [], strokeColor = '#006194', height = 32 }) {
  if (!data || data.length < 2) {
    return (
      <div className="w-full h-8 flex items-center justify-center text-on-surface-variant text-[11px] font-mono">
        Mengumpulkan data...
      </div>
    )
  }

  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const width = 100
  const padding = 4
  const innerHeight = height - padding * 2

  const points = data.map((val, idx) => {
    const x = (idx / (data.length - 1)) * width
    const y = height - padding - ((val - min) / range) * innerHeight
    return { x: Number(x.toFixed(1)), y: Number(y.toFixed(1)) }
  })

  let pathD = `M ${points[0].x},${points[0].y}`
  for (let i = 1; i < points.length; i++) {
    const prev = points[i - 1]
    const curr = points[i]
    const midX = (prev.x + curr.x) / 2
    pathD += ` C ${midX},${prev.y} ${midX},${curr.y} ${curr.x},${curr.y}`
  }

  const lastPoint = points[points.length - 1]

  return (
    <div className="w-full overflow-hidden" style={{ height: `${height}px` }}>
      <svg className="w-full h-full overflow-visible" preserveAspectRatio="none" viewBox={`0 0 ${width} ${height}`}>
        <path
          d={pathD}
          fill="none"
          stroke={strokeColor}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx={lastPoint.x} cy={lastPoint.y} r="3" fill={strokeColor} className="animate-ping origin-center" />
        <circle cx={lastPoint.x} cy={lastPoint.y} r="2.5" fill={strokeColor} />
      </svg>
    </div>
  )
}
