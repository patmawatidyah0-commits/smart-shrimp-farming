import React from 'react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function BottomNav() {
  const { activeTab, setActiveTab, language } = useApp()
  const lang = language || 'id'
  const nav = t(lang, 'nav')

  const navItems = [
    { id: 'home',       label: nav.home,      icon: 'home' },
    { id: 'monitoring', label: nav.monitoring, icon: 'monitoring' },
    { id: 'kontrol',    label: nav.kontrol,    icon: 'tune' },
    { id: 'histori',    label: nav.histori,    icon: 'history' },
    { id: 'panduan',    label: nav.panduan,    icon: 'menu_book' },
    { id: 'profil',     label: nav.profil,     icon: 'account_circle' },
  ]

  return (
    <nav style={{ position: 'sticky', bottom: 0, zIndex: 40, backgroundColor: '#ffffff', borderTop: '1px solid #E2E8F0', boxShadow: '0 -2px 8px rgba(15,23,42,0.06)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-around', height: '64px', padding: '0 4px' }}>
        {navItems.map((item) => {
          const isActive = activeTab === item.id
          return (
            <button key={item.id} onClick={() => setActiveTab(item.id)}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '2px', flex: 1, minHeight: '44px', border: 'none', background: 'transparent', cursor: 'pointer', position: 'relative', transition: 'all 0.2s' }}>
              {isActive && (
                <span style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: '28px', height: '3px', borderRadius: '0 0 4px 4px', backgroundColor: '#0D9488' }} />
              )}
              <div style={{ width: 32, height: 32, borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: isActive ? '#CCFBF1' : 'transparent', transition: 'all 0.2s' }}>
                <span className="material-symbols-outlined" style={{ fontSize: '20px', color: isActive ? '#0D9488' : '#94A3B8', transition: 'all 0.2s' }}>
                  {item.icon}
                </span>
              </div>
              <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontSize: '10px', fontWeight: 700, color: isActive ? '#0D9488' : '#94A3B8', letterSpacing: '-0.01em' }}>
                {item.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
