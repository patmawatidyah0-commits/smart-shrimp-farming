import React from 'react'
import { useApp } from '../context/AppContext'

export default function NotificationModal({ isOpen, onClose }) {
  const { notifications, markNotificationAsRead, clearAllNotifications } = useApp()

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-md bg-surface rounded-t-3xl sm:rounded-3xl shadow-2xl max-h-[85vh] flex flex-col overflow-hidden border border-outline-variant/30">
        <div className="p-4 flex items-center justify-between border-b border-outline-variant/30 bg-surface-container-low">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[22px]">notifications</span>
            <h3 className="font-sans font-bold text-base text-on-surface">Notifikasi Sistem</h3>
            <span className="px-2 py-0.5 rounded-full bg-primary-fixed text-on-primary-fixed font-mono text-[11px] font-bold">
              {notifications.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {notifications.length > 0 && (
              <button
                onClick={clearAllNotifications}
                className="font-sans text-xs text-on-surface-variant hover:text-red-600 transition-colors"
              >
                Hapus Semua
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full flex items-center justify-center text-on-surface-variant hover:bg-surface-container transition-colors"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          </div>
        </div>

        <div className="overflow-y-auto p-4 space-y-2.5 flex-1">
          {notifications.length === 0 ? (
            <div className="py-12 text-center flex flex-col items-center justify-center gap-2">
              <span className="material-symbols-outlined text-[40px] text-on-surface-variant/40">
                notifications_off
              </span>
              <p className="font-sans text-xs text-on-surface-variant">Belum ada notifikasi baru.</p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                onClick={() => markNotificationAsRead(item.id)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                  item.read
                    ? 'bg-surface-container-low border-outline-variant/20 opacity-80'
                    : 'bg-surface-container-lowest border-primary/30 shadow-sm'
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    item.type === 'warning'
                      ? 'bg-amber-100 text-amber-700'
                      : item.type === 'schedule'
                      ? 'bg-sky-100 text-sky-700'
                      : 'bg-emerald-100 text-emerald-700'
                  }`}
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {item.type === 'warning'
                      ? 'warning'
                      : item.type === 'schedule'
                      ? 'schedule'
                      : 'info'}
                  </span>
                </div>

                <div className="flex flex-col min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="font-sans font-bold text-xs text-on-surface truncate">
                      {item.title}
                    </h4>
                    <span className="font-mono text-[10px] text-on-surface-variant shrink-0">
                      {item.time}
                    </span>
                  </div>
                  <p className="font-sans text-xs text-on-surface-variant mt-0.5 leading-relaxed">
                    {item.message}
                  </p>
                </div>              </div>
            ))
          )}
        </div>

        <div className="p-3 border-t border-outline-variant/30 bg-surface-container-low text-center">
          <button
            onClick={onClose}
            className="w-full h-10 rounded-xl bg-primary text-white font-sans text-xs font-bold active:scale-[0.98] transition-all"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  )
}
