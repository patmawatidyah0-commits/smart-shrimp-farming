import React from 'react'
import { useApp } from '../context/AppContext'
import { t } from '../i18n'

export default function Header({ onOpenNotifications, onOpenSettings }) {
  const { connectionStatus, isSimulator, setIsSimulator, notifications, language } = useApp()
  const unreadCount = notifications.filter((n) => !n.read).length
  const lang = language || 'id'

  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 40, backgroundColor: '#ffffff', borderBottom: '1px solid #E2E8F0', boxShadow: '0 1px 4px rgba(15,23,42,0.06)' }}>
      <div style={{ height: '64px', padding: '0 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>

        {/* Logo + Title */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0 }}>
          <div style={{ width: 40, height: 40, borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: 'linear-gradient(135deg,#0D9488,#0F766E)' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '22px', color: '#ffffff' }}>water_drop</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', minWidth: 0 }}>
            <span style={{ fontFamily: 'Plus Jakarta Sans,sans-serif', fontWeight: 800, fontSize: '14px', color: '#0F172A', letterSpacing: '-0.01em' }}>
              {t(lang, 'appName')}
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '5px', marginTop: '1px' }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', flexShrink: 0, backgroundColor: connectionStatus === 'connected' ? '#0D9488' : '#DC2626' }} />
              <span style={{ fontFamily: 'JetBrains Mono,monospace', fontSize: '10px', color: '#64748B' }}>
                {connectionStatus === 'connected' ? t(lang, 'esp32Online') : t(lang, 'esp32Connecting')}
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
          <button onClick={() => setIsSimulator(!isSimulator)}
            style={{
              padding: '4px 10px', borderRadius: '10px', fontFamily: 'JetBrains Mono,monospace',
              fontSize: '11px', fontWeight: 700, cursor: 'pointer', transition: 'all 0.2s',
              border: isSimulator ? '1px solid #99F6E4' : '1px solid #E2E8F0',
              background: isSimulator ? '#CCFBF1' : '#F8FAFC',
              color: isSimulator ? '#0D9488' : '#64748B',
            }}>
            {isSimulator ? 'SIM' : 'MQTT'}
          </button>

          <button onClick={onOpenNotifications}
            style={{ position: 'relative', width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '14px', border: 'none', background: 'transparent', cursor: 'pointer', color: '#64748B' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '22px', color: '#64748B' }}>notifications</span>
            {unreadCount > 0 && (
              <span style={{ position: 'absolute', top: '6px', right: '6px', minWidth: '16px', height: '16px', padding: '0 4px', backgroundColor: '#F97316', color: '#ffffff', fontSize: '10px', fontWeight: 700, borderRadius: '999px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'JetBrains Mono,monospace' }}>
                {unreadCount}
              </span>
            )}
          </button>

          <button onClick={onOpenSettings}
            style={{ width: 36, height: 36, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer', background: 'linear-gradient(135deg,#0D9488,#0F766E)' }}>
            <span className="material-symbols-outlined" style={{ fontSize: '18px', color: '#ffffff' }}>person</span>
          </button>
        </div>
      </div>
    </header>
  )
}
