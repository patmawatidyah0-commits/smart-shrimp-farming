import React, { useState } from 'react'
import { AppProvider, useApp } from './context/AppContext'
import Header from './components/Header'
import BottomNav from './components/BottomNav'
import HomeScreen from './screens/HomeScreen'
import MonitoringScreen from './screens/MonitoringScreen'
import ControlScreen from './screens/ControlScreen'
import HistoryScreen from './screens/HistoryScreen'
import ProfileScreen from './screens/ProfileScreen'
import GuideScreen from './screens/GuideScreen'
import NotificationModal from './components/NotificationModal'
import LoginModal from './components/LoginModal'

function MainContent() {
  const { activeTab, setActiveTab } = useApp()
  const [showNotifications, setShowNotifications] = useState(false)

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#0F172A', display: 'flex', justifyContent: 'center' }}>
      <div style={{
        width: '100%', maxWidth: '448px', minHeight: '100vh',
        backgroundColor: '#0F172A',
        display: 'flex', flexDirection: 'column',
        boxShadow: '0 0 40px rgba(0,0,0,0.5)',
        borderLeft: '1px solid #1E293B',
        borderRight: '1px solid #1E293B',
      }}>

        <Header
          onOpenNotifications={() => setShowNotifications(true)}
          onOpenSettings={() => setActiveTab('profil')}
        />

        <main style={{ flex: 1, width: '100%', padding: '0 16px', display: 'flex', flexDirection: 'column', overflowY: 'auto', backgroundColor: '#0F172A' }}>
          {activeTab === 'home'       && <HomeScreen />}
          {activeTab === 'monitoring' && <MonitoringScreen />}
          {activeTab === 'kontrol'    && <ControlScreen />}
          {activeTab === 'histori'    && <HistoryScreen />}
          {activeTab === 'panduan'    && <GuideScreen />}
          {activeTab === 'profil'     && <ProfileScreen />}
        </main>

        <BottomNav />

        <NotificationModal
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)}
        />

        <LoginModal />
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  )
}
