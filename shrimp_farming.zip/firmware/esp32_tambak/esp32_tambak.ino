#include <WiFi.h>
#include <PubSubClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ArduinoJson.h>

const char* WIFI_SSID = "TAMBAK_WIFI_AP";
const char* WIFI_PASSWORD = "password123";

const char* MQTT_BROKER = "broker.emqx.io";
const int MQTT_PORT = 1883;
const char* MQTT_CLIENT_ID = "ESP32_TambakUdang_Pond1";

const char* TOPIC_TELEMETRY = "tambak/udang/telemetri";
const char* TOPIC_CONTROL = "tambak/udang/kontrol";
const char* TOPIC_STATUS = "tambak/udang/status";

const int PIN_ONE_WIRE = 4;
const int PIN_PH_SENSOR = 34;
const int PIN_TRIG = 5;
const int PIN_ECHO = 18;
const int PIN_RELAY_PUMP = 26;
const int PIN_RELAY_AERATOR = 27;

const float POND_MAX_DEPTH_CM = 150.0;
const float SENSOR_OFFSET_CM = 15.0;

OneWire oneWire(PIN_ONE_WIRE);
DallasTemperature tempSensor(&oneWire);

WiFiClient espClient;
PubSubClient mqttClient(espClient);

unsigned long lastTelemetryTime = 0;
const unsigned long TELEMETRY_INTERVAL = 3000;

bool pumpState = false;
bool aeratorState = false;

void setPump(bool state) {
  pumpState = state;
  digitalWrite(PIN_RELAY_PUMP, state ? LOW : HIGH);
}

void setAerator(bool state) {
  aeratorState = state;
  digitalWrite(PIN_RELAY_AERATOR, state ? LOW : HIGH);
}

float readTemperature() {
  tempSensor.requestTemperatures();
  float tempC = tempSensor.getTempCByIndex(0);
  if (tempC < -50.0 || tempC > 80.0) {
    return 28.5;
  }
  return tempC;
}

float readPH() {
  int rawADC = 0;
  for (int i = 0; i < 10; i++) {
    rawADC += analogRead(PIN_PH_SENSOR);
    delay(10);
  }
  rawADC /= 10;
  float voltage = (rawADC / 4095.0) * 3.3;
  float calculatedPH = 7.0 + ((2.5 - voltage) / 0.18);
  if (calculatedPH < 0.0) calculatedPH = 0.0;
  if (calculatedPH > 14.0) calculatedPH = 14.0;
  return calculatedPH;
}

float readWaterLevel() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);

  long duration = pulseIn(PIN_ECHO, HIGH, 30000);
  if (duration == 0) {
    return 80.0;
  }

  float distanceCm = (duration * 0.0343) / 2.0;
  float actualWaterHeight = POND_MAX_DEPTH_CM - (distanceCm - SENSOR_OFFSET_CM);
  if (actualWaterHeight < 0.0) actualWaterHeight = 0.0;
  if (actualWaterHeight > POND_MAX_DEPTH_CM) actualWaterHeight = POND_MAX_DEPTH_CM;

  float levelPercentage = (actualWaterHeight / POND_MAX_DEPTH_CM) * 100.0;
  return levelPercentage;
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  StaticJsonDocument<256> doc;
  DeserializationError error = deserializeJson(doc, payload, length);
  if (error) {
    return;
  }

  if (doc.containsKey("target") && doc.containsKey("action")) {
    const char* target = doc["target"];
    const char* action = doc["action"];
    bool isOn = (strcmp(action, "ON") == 0);

    if (strcmp(target, "pump") == 0) {
      setPump(isOn);
    } else if (strcmp(target, "aerator") == 0) {
      setAerator(isOn);
    }
  }

  if (doc.containsKey("pump")) {
    setPump(doc["pump"].as<bool>());
  }
  if (doc.containsKey("aerator")) {
    setAerator(doc["aerator"].as<bool>());
  }

  publishTelemetry();
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    attempts++;
  }
}

void connectMQTT() {
  while (!mqttClient.connected()) {
    if (WiFi.status() != WL_CONNECTED) {
      connectWiFi();
    }
    if (mqttClient.connect(MQTT_CLIENT_ID, TOPIC_STATUS, 1, true, "offline")) {
      mqttClient.publish(TOPIC_STATUS, "online", true);
      mqttClient.subscribe(TOPIC_CONTROL);
    } else {
      delay(2000);
    }
  }
}

void publishTelemetry() {
  float temp = readTemperature();
  float ph = readPH();
  float level = readWaterLevel();

  StaticJsonDocument<256> doc;
  doc["temperature"] = round(temp * 10.0) / 10.0;
  doc["ph"] = round(ph * 10.0) / 10.0;
  doc["water_level"] = round(level * 10.0) / 10.0;
  doc["pump_status"] = pumpState;
  doc["aerator_status"] = aeratorState;
  doc["device_id"] = MQTT_CLIENT_ID;
  doc["uptime_ms"] = millis();

  char buffer[256];
  serializeJson(doc, buffer);
  mqttClient.publish(TOPIC_TELEMETRY, buffer);
}

void setup() {
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_RELAY_PUMP, OUTPUT);
  pinMode(PIN_RELAY_AERATOR, OUTPUT);

  setPump(false);
  setAerator(false);

  tempSensor.begin();

  mqttClient.setServer(MQTT_BROKER, MQTT_PORT);
  mqttClient.setCallback(mqttCallback);

  connectWiFi();
  connectMQTT();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }
  if (!mqttClient.connected()) {
    connectMQTT();
  }
  mqttClient.loop();

  unsigned long currentMillis = millis();
  if (currentMillis - lastTelemetryTime >= TELEMETRY_INTERVAL) {
    lastTelemetryTime = currentMillis;
    publishTelemetry();
  }
}
