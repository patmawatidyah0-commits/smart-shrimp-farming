# Panduan Firmware ESP32 - Smart Shrimp Farming

Firmware untuk mikrokontroler ESP32 DevKit V1 yang mengumpulkan data sensor kualitas air tambak udang dan mengontrol aktuator secara real-time melalui protokol MQTT.

## Komponen Hardware & Pinout ESP32

| Komponen | Tipe Sensor / Modul | Pin ESP32 | Keterangan |
| :--- | :--- | :--- | :--- |
| Sensor Suhu Air | DS18B20 Waterproof | GPIO 4 | OneWire Bus (Resistor 4.7kΩ pull-up ke 3.3V) |
| Sensor pH Air | Analog pH Probe 4502C | GPIO 34 (ADC1_CH6) | Input Analog 0 - 3.3V dengan kalibrasi tegangan |
| Sensor Level Air | HC-SR04 / JSN-SR04T | TRIG: GPIO 5, ECHO: GPIO 18 | Ultrasonic Transceiver (Pembagi tegangan ECHO ke 3.3V) |
| Aktuator 1 | Modul Relay 1 (Pompa Air) | GPIO 26 | Active LOW Trigger ke pompa pengisian air tambak |
| Aktuator 2 | Modul Relay 2 (Kincir Aerator) | GPIO 27 | Active LOW Trigger ke kincir oksigen aerator |
| Status Koneksi | Onboard LED | GPIO 2 | Indikator koneksi Wi-Fi dan MQTT |

## Pustaka Arduino IDE yang Dibutuhkan

Buka **Arduino IDE -> Sketch -> Include Library -> Manage Libraries...** dan pasang:
1. `PubSubClient` oleh Nick O'Leary (v2.8.0+)
2. `OneWire` oleh Paul Stoffregen (v2.3.8+)
3. `DallasTemperature` oleh Miles Burton (v3.9.0+)
4. `ArduinoJson` oleh Benoit Blanchon (v6.21.0+)

## Konfigurasi Topik MQTT

- Broker Publik Default: `broker.emqx.io` (Port 1883)
- Topik Telemetri (Pub): `tambak/udang/telemetri`
- Topik Kontrol (Sub): `tambak/udang/kontrol`
- Topik Status LWT (Pub): `tambak/udang/status`

### Format Payload Telemetri (ESP32 -> Mobile App)
```json
{
  "temperature": 28.5,
  "ph": 7.8,
  "water_level": 82.0,
  "pump_status": false,
  "aerator_status": true,
  "device_id": "ESP32_TambakUdang_Pond1",
  "uptime_ms": 124500
}
```

### Format Payload Kontrol (Mobile App -> ESP32)
```json
{
  "target": "pump",
  "action": "ON"
}
```
atau
```json
{
  "pump": true,
  "aerator": false
}
```

## Prosedur Flashing
1. Buka file `firmware/esp32_tambak/esp32_tambak.ino` di Arduino IDE.
2. Ubah `WIFI_SSID` dan `WIFI_PASSWORD` sesuai access point lapangan tambak.
3. Pilih board **DOIT ESP32 DEVKIT V1**.
4. Hubungkan ESP32 melalui kabel USB micro/Type-C ke laptop/PC.
5. Tekan tombol **Upload** pada Arduino IDE.
