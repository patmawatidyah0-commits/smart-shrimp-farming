import React, { useState } from 'react'
import { View, StyleSheet, StatusBar } from 'react-native'
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context'
import { AppProvider, useApp } from './src/context/AppContext'
import Header from './src/components/Header'
import BottomNav from './src/components/BottomNav'
import HomeScreen from './src/screens/HomeScreen'
import MonitoringScreen from './src/screens/MonitoringScreen'
import ControlScreen from './src/screens/ControlScreen'
import HistoryScreen from './src/screens/HistoryScreen'
import GuideScreen from './src/screens/GuideScreen'
import ProfileScreen from './src/screens/ProfileScreen'
import NotificationModal from './src/components/NotificationModal'
import LoginModal from './src/components/LoginModal'

function MainContent() {
  const { activeTab, setActiveTab, isLoggedIn } = useApp()
  const [showNotifications, setShowNotifications] = useState(false)

  if (!isLoggedIn) {
    return <LoginModal />
  }

  return (
    <SafeAreaView style={s.safeArea} edges={['top']}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <Header
        onOpenNotifications={() => setShowNotifications(true)}
        onOpenSettings={() => setActiveTab('profil')}
      />
      <View style={s.content}>
        {activeTab === 'home'       && <HomeScreen />}
        {activeTab === 'monitoring' && <MonitoringScreen />}
        {activeTab === 'kontrol'    && <ControlScreen />}
        {activeTab === 'histori'    && <HistoryScreen />}
        {activeTab === 'panduan'    && <GuideScreen />}
        {activeTab === 'profil'     && <ProfileScreen />}
      </View>
      <BottomNav />
      <NotificationModal
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </SafeAreaView>
  )
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <MainContent />
      </AppProvider>
    </SafeAreaProvider>
  )
}

const s = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#ffffff' },
  content: { flex: 1, backgroundColor: '#F8FAFC' },
})

