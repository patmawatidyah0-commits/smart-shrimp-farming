# SISTEM BUDIDAYA TAMBAK UDANG CERDAS BERBASIS IoT
### Smart Shrimp Farming IoT & Mobile Dashboard

Sistem otomasi dan pemantauan kualitas air tambak udang Vaname berbasis Internet of Things (IoT) dengan mikrokontroler ESP32, protokol komunikasi MQTT (Message Queuing Telemetry Transport), dan aplikasi dashboard mobile berbasis React + Tailwind CSS.

---

## Tim Pengembang & Peneliti

1. **Dyah Eka Patmawati** — Hardware & IoT Engineer
2. **M. Zidan Ihya U.A** — Embedded Firmware & Network Engineer
3. **Risky Prasetyo** — Fullstack & Mobile Frontend Engineer

---

## Arsitektur Sistem

```mermaid
graph TD
    subgraph Hardware_Layer [Lapisan Perangkat Keras / Tambak Udang]
        S1[Sensor Suhu DS18B20] -->|OneWire GPIO 4| ESP32[ESP32 Microcontroller]
        S2[Sensor pH Air Analog] -->|Analog ADC GPIO 34| ESP32
        S3[Sensor Ultrasonik HC-SR04] -->|TRIG: 5, ECHO: 18| ESP32
        ESP32 -->|Relay GPIO 26| R1[Relay Pompa Air Sirkulasi]
        ESP32 -->|Relay GPIO 27| R2[Relay Aerator Kincir Air]
    end

    subgraph Transport_Layer [Lapisan Transport & Protokol]
        ESP32 -->|TCP Port 1883 JSON| Broker[MQTT Broker EMQX]
        Broker -->|WebSocket Port 8083| WebApp[Mobile Web App React]
        WebApp -->|Publish Command JSON| Broker
        Broker -->|Subscribe Kontrol| ESP32
    end

    subgraph Application_Layer [Lapisan Dashboard Mobile]
        WebApp --> F1[Dashboard Ringkasan & Real-time KPI]
        WebApp --> F2[Grafik Tren Telemetri Spline 20 Data Point]
        WebApp --> F3[Kontrol Aktuator Manual & Mode Otomatis]
        WebApp --> F4[Histori Log Kualitas Air & Ekspor CSV]
        WebApp --> F5[Pusat Notifikasi & Alarm Ambang Batas]
        WebApp --> F6[Virtual ESP32 Simulator & Hardware Sandbox]
    end
```

---

## Inventaris Fitur (Berdasarkan PRD)

Sistem ini mengimplementasikan 11 fitur inti sesuai dokumen PRD (*Product Requirements Document*):

| No | Fitur | Status | Deskripsi |
|---|---|---|---|
| 1 | **Login & Autentikasi Pengguna** | Selesai | Form autentikasi email & password dengan validasi kredensial dan opsi demo login 1-klik. |
| 2 | **Dashboard Utama (Home)** | Selesai | Indikator status koneksi ESP32, ringkasan kartu suhu, pH, dan ketinggian air, status aktuator, dan jadwal pakan. |
| 3 | **Monitoring Kualitas Air Real-time** | Selesai | Visualisasi grafik spline 20 data point interaktif dengan pita batas aman (*ideal band*) dan metrik Min/Avg/Max. |
| 4 | **Detail Sensor & Spesifikasi Pin** | Selesai | Informasi modul sensor fisik (DS18B20, pH Probe, HC-SR04), pinout GPIO, dan penjelasan fungsi monitoring. |
| 5 | **Kontrol Aktuator (Pompa & Aerator)** | Selesai | Saklar kendali relay pompa sirkulasi dan kincir aerator dengan indikator visual dan feedback latensi instan. |
| 6 | **Mode Kontrol Otomatis** | Selesai | Algoritma *closed-loop* mandiri: Aerator menyala jika pH < 7.5 atau Suhu > 32°C; Pompa menyala jika level air < 80 cm. |
| 7 | **Riwayat & Log Kualitas Air** | Selesai | Tabel log telemetri dengan penanda waktu, nilai parameter, dan badge klasifikasi status (*Normal* / *Peringatan*). |
| 8 | **Filter Data & Ekspor CSV** | Selesai | Penyaringan log berdasarkan status (*Semua*, *Normal*, *Peringatan*) dan pengunduhan rekaman data ke format spreadsheet `.csv`. |
| 9 | **Pengaturan Profil Pengguna & Tim** | Selesai | Tampilan identitas peneliti/pengembang, roadmap sprint riset, dan status otorisasi akun. |
| 10 | **Konfigurasi Ambang Batas & MQTT** | Selesai | Pengaturan rentang batas aman (*Safe Range Thresholds*) untuk suhu, pH, level air, serta alamat broker MQTT. |
| 11 | **Pemberitahuan & Notifikasi Anomali** | Selesai | Laci notifikasi (*drawer*) dengan penanda pesan belum dibaca (*unread count badge*) dan aksi hapus notifikasi. |

---

## Spesifikasi Protokol Komunikasi MQTT

### Broker MQTT
- **Host Broker**: `broker.emqx.io`
- **Port TCP (Firmware ESP32)**: `1883`
- **Port WebSocket (Mobile Dashboard)**: `8083` (Path: `/mqtt`)

### Topik & Format Payload

1. **Topik Telemetri Sensor**: `tambak/udang/telemetri` (ESP32 $\rightarrow$ Dashboard)
   ```json
   {
     "suhu": 28.5,
     "ph": 7.82,
     "ketinggian": 105.4,
     "pompa": false,
     "aerator": true,
     "mode": "auto",
     "timestamp": "2025-05-18T14:30:00.000Z"
   }
   ```

2. **Topik Kendali Aktuator**: `tambak/udang/kontrol` (Dashboard $\rightarrow$ ESP32)
   ```json
   {
     "target": "pompa",
     "state": true
   }
   ```
   Atau untuk mengubah mode otomasi:
   ```json
   {
     "target": "mode",
     "mode": "auto"
   }
   ```

3. **Topik Status Perangkat**: `tambak/udang/status` (ESP32 $\rightarrow$ Dashboard)
   ```json
   {
     "status": "online",
     "device": "ESP32_Tambak_Udang_01",
     "ip": "192.168.1.105"
   }
   ```

---

## Skema Pengkabelan & Pinout ESP32

| Komponen Perangkat Keras | Pin ESP32 (DevKit V1) | Mode / Protokol | Keterangan |
|---|---|---|---|
| **Sensor Suhu DS18B20** | GPIO 4 | OneWire Digital | Tambahkan resistor pull-up 4.7kΩ antara VCC (3.3V) dan DATA |
| **Sensor pH Analog 4502C** | GPIO 34 (ADC1_CH6) | Analog Input | Resolusi ADC 12-bit (0 - 4095), tegangan input 0 - 3.3V |
| **Ultrasonik HC-SR04 TRIG** | GPIO 5 | Digital Output | Trigger pulsa 10 µs |
| **Ultrasonik HC-SR04 ECHO** | GPIO 18 | Digital Input | Gunakan pembagi tegangan (voltage divider) 5V $\rightarrow$ 3.3V |
| **Relay Pompa Air Sirkulasi**| GPIO 26 | Digital Output | Active-Low / Active-High relay module |
| **Relay Kincir Aerator** | GPIO 27 | Digital Output | Active-Low / Active-High relay module |

---

## Struktur Direktori Monorepo

```
mobileapp_tambakudang/
├── firmware/
│   ├── esp32_tambak/
│   │   └── esp32_tambak.ino       # Source code C++ Arduino ESP32 lengkap
│   └── README.md                  # Panduan flashing, library & kalibrasi sensor
├── public/
├── src/
│   ├── components/
│   │   ├── BottomNav.jsx          # Navigasi 5-tab mobile view
│   │   ├── Header.jsx             # Top bar, status ESP32, toggle SIM/MQTT, notifikasi
│   │   ├── LoginModal.jsx         # Modal autentikasi PRD Fitur 1
│   │   └── NotificationModal.jsx  # Drawer notifikasi PRD Fitur 11
│   ├── context/
│   │   └── AppContext.jsx         # State global, buffer telemetri, logika otomatis & CSV
│   ├── screens/
│   │   ├── HomeScreen.jsx         # PRD Fitur 2: Ringkasan & kartu sensor
│   │   ├── MonitoringScreen.jsx   # PRD Fitur 3 & 4: Grafik spline SVG & spesifikasi pin
│   │   ├── ControlScreen.jsx      # PRD Fitur 5 & 6: Saklar relay & simulator sandbox
│   │   ├── HistoryScreen.jsx      # PRD Fitur 7 & 8: Tabel log & unduh CSV
│   │   └── ProfileScreen.jsx      # PRD Fitur 9 & 10: Tim pengembang & batas aman
│   ├── services/
│   │   ├── mqttService.js         # Client MQTT over WebSocket (EMQX broker)
│   │   └── simulatorService.js    # Virtual ESP32 simulator untuk demonstrasi offline
│   ├── App.jsx                    # Root app container & tab router
│   ├── index.css                  # Style tokens, Plus Jakarta Sans & JetBrains Mono
│   └── main.jsx                   # Entry point React 18
├── index.html                     # HTML5 shell dengan Google Material Symbols
├── package.json                   # Dependensi React 18, Vite 5, Tailwind CSS, MQTT.js
├── tailwind.config.js             # Konfigurasi styling & palet warna
├── vite.config.js                 # Konfigurasi bundler Vite
├── task.md                        # State machine pelacakan milestone pekerjaan
└── README.md                      # Dokumentasi komprehensif proyek (berkas ini)
```

---

## Panduan Instalasi & Menjalankan Aplikasi

### 1. Prasyarat Sistem
- **Node.js** versi 18.x atau lebih baru
- **NPM** versi 9.x atau lebih baru
- **Arduino IDE** (jika memprogram ESP32 fisik) dengan modul *ESP32 Board by Espressif Systems*

### 2. Instalasi Dependensi Mobile App
Buka terminal pada direktori proyek, lalu jalankan:
```bash
npm install
```

### 3. Menjalankan Dashboard pada Mode Pengembangan (Dev Mode)
```bash
npm run dev
```
Aplikasi akan aktif pada URL lokal: `http://localhost:5173/`.

### 4. Melakukan Kompilasi Produksi (Production Build)
```bash
npm run build
```
Hasil build bundler akan berada di dalam direktori `dist/`.

### 5. Menjalankan Server Preview Produksi
```bash
npm run preview
```
Aplikasi siap diuji pada URL: `http://localhost:4173/`.

---

## Petunjuk Pengujian Mode Simulasi vs Hardware Fisik

Aplikasi dilengkapi saklar **SIM / MQTT** pada header atas:
1. **Mode SIM (Simulator Virtual ESP32)**:
   - Beroperasi langsung di browser tanpa memerlukan perangkat keras ESP32.
   - Menghasilkan variasi data suhu, pH, dan ketinggian air secara realistis setiap 3 detik.
   - Mendukung injeksi anomali pada tab **Kontrol** untuk menguji alarm darurat (misal: suhu tinggi $>33^\circ\text{C}$ atau pH asam $<7.2$).
2. **Mode MQTT (Perangkat Keras ESP32 Fisik)**:
   - Terhubung langsung ke broker EMQX melalui WebSocket.
   - Menerima data asli dari sensor DS18B20, elektroda pH, dan sensor jarak ultrasonik.
   - Mengirim perintah aktivasi relay pompa dan aerator ke ESP32 secara instan.

---

## Lisensi & Hak Cipta

Proyek ini dikembangkan untuk keperluan akademik dan penelitian sistem budidaya tambak udang presisi berbasis IoT oleh **Dyah Eka Patmawati, M. Zidan Ihya U.A, dan Risky Prasetyo**. Seluruh kode sumber dirancang untuk penerapan praktis pada tambak udang Vaname.
