---
name: AquaIoT Sense
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4850'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#994100'
  on-tertiary: '#ffffff'
  tertiary-container: '#c05400'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#783200'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  telemetry-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.03em
  telemetry-unit:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system serves an industrial-grade, precision IoT mobile monitoring environment engineered for modern aquaculture technicians, pond operators, and farm managers. The emotional tone bridges maritime stewardship with technological precision: reliable, calm under pressure, hyper-legible under harsh outdoor sunlight, and rigorously alert when biological thresholds fail. 

The aesthetic is Modern Tactile Minimalism combined with functional telemetry dashboards. It utilizes soft, deeply diffused elevation layers, high-contrast numeric readout clusters, squircle form factors, and distinct semantic statuses. Interface chrome recedes into crisp slate neutrals, allowing real-time water metrics (dissolved oxygen, pH, salinity, water temperature, ORP) to immediately communicate operational states across distributed ESP32 nodes and MQTT pipelines.

## Colors

The system uses an oceanic yet technical chromatic hierarchy designed for instant scannability on mobile screens exposed to outdoor environments:

- **Primary (`#0284C7` & `#0EA5E9`)**: Represents aquatic depth and network flow. Applied to active states, selected navigation nodes, primary trigger buttons, and MQTT synchronization pulses.
- **Secondary (`#0F172A` & `#1E293B`)**: Marine Slate Navy. Applied to high-emphasis typography, critical structural headers, bottom navigation background blocks, and dense container outlines.
- **Tertiary (`#F97316`)**: Shrimp Coral Accent. Applied intentionally to manual motor controls (aerators, auto-feeders), highlighted telemetry anomalies, and pending threshold states.
- **Neutral Surface Spectrum**: 
  - Canvas Base: `#F8FAFC`
  - Card/Module Surface: `#FFFFFF`
  - Subtle Muted Tint: `#F1F5F9`
  - Border/Divider Slate: `#E2E8F0`
  - Body Text Slate: `#334155`
  - Subdued Meta Text: `#64748B`
- **Telemetry Semantic System**:
  - `Normal (Optimal Water Parameter)`: `#10B981` (Emerald), Container `#ECFDF5`, Border `#A7F3D0`
  - `Warning (Cautionary Threshold)`: `#F59E0B` (Amber), Container `#FFFBEB`, Border `#FDE68A`
  - `Critical (Biological Hazard / Node Offline)`: `#EF4444` (Ruby/Red), Container `#FEF2F2`, Border `#FECACA`

## Typography

The typography couples the human-centric warmth and rounded geometry of Plus Jakarta Sans with the technical precision of JetBrains Mono for telemetry metrics, MQTT broker payload status, device IDs, and sensor timestamps.

- **Primary Typeface**: Plus Jakarta Sans delivers geometric clarity and legible aperture widths, essential for field workers checking quick stats under ambient sunlight.
- **Monospace Accent**: JetBrains Mono is designated strictly for hardware readouts, timestamp trackers, broker topics (e.g., `pond/01/esp32/dO2`), packet delivery latency, and firmware signatures.
- **Hierarchy Rules**: Metric integers must never be separated from their unit label; use baseline alignment between `telemetry-metric` and `telemetry-unit`. Sensor titles are rendered in `body-sm` with uppercase tracking for instantaneous categorizing.

## Layout & Spacing

The layout is built on a mobile-first, 4-column fluid layout with an 8px base rhythm. Margin gutters are locked to `1rem` (16px) on compact handheld viewports to preserve high data density, scaling to a 6-column grid with `1.5rem` (24px) gutters on rugged field tablets.

- **Screen Canvas Margin**: `1rem` on smartphones; `1.5rem` on tablet/phablet screens.
- **Component Padding Scale**:
  - `space-xs` (4px): Internal badge padding, status pill micro-margins.
  - `space-sm` (8px): Icon-to-text spacing, compact list item vertical padding.
  - `space-md` (12px): Standard inner card padding for secondary telemetry tiles.
  - `space-lg` (16px): Primary pond module padding, input container padding.
  - `space-xl` (24px): Structural vertical separation between functional card clusters.
- **Vertical Safe Zones**: Top bar content clears the device dynamic island/status bar with a minimum `2.75rem` safe offset; bottom floating navigation maintains an explicit `1.25rem` elevation clearance above home indicator bars.

## Elevation & Depth

Visual hierarchy uses layered ambient light diffusion over high-contrast white surfaces, avoiding heavy dropshadows that muddy small screens:

- **Level 0 (Canvas Base)**: Flat `#F8FAFC`. Houses background canvas, top navigation header bars, and structural tabs.
- **Level 1 (Sensor Telemetry Cards & Inactive Modules)**: Pure `#FFFFFF` surface accompanied by a subtle hairline border `1px solid #E2E8F0` and an ambient shadow: `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Pond Cards & Interactive Widgets)**: Raised container with `box-shadow: 0 4px 12px -2px rgba(15, 23, 42, 0.06), 0 2px 6px -2px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Floating Bottom Bar & Urgent Alert Sheets)**: Deep diffused elevation tinted with marine slate: `box-shadow: 0 12px 32px -4px rgba(15, 23, 42, 0.12), 0 4px 12px -2px rgba(15, 23, 42, 0.06)`. Bottom navigation uses a high-performance frosted glass backing: `backdrop-filter: blur(16px)` with `rgba(255, 255, 255, 0.88)` fill.
- **Dynamic State Glow**: When a sensor registers a `Critical` or `Warning` status, the ambient shadow subtly absorbs the semantic hue (e.g., `rgba(239, 68, 68, 0.15)` for Red alerts) to provide peripheral urgency.

## Shapes

The design system enforces a roundedness level of `2` (`0.5rem` / 8px core radius), scaling into soft organic squircles for cards and structural containers:

- **Telemetry Cards & Pond Modules**: `1rem` (16px) corner radius (`rounded-lg`), providing a clean, friendly, tactile feel that resists visual clutter.
- **Action Buttons & Form Controls**: `0.75rem` (12px) corner radius for firm touch targets.
- **Badges, Telemetry Status Indicators, and Pill Chips**: Full capsule rounding (`9999px`), framing state text cleanly.
- **Bottom Navigation Dock**: `1.5rem` (24px) corner radius when floating, or `1.25rem` top-corner radius when docked to the screen bottom edge.

## Components

### Telemetry Cards
- **Structure**: White squircle container with 16px inner padding. Split into header (Sensor Name, MQTT Node ID in `label-mono`, and real-time status badge), metric core (large value in `telemetry-metric` with unit in `telemetry-unit`), and footer (sparkline graph and timestamp).
- **Status Indicator**: Right-aligned capsule badge with soft semantic background (`#ECFDF5`), bold semantic text (`#10B981`), and a pulsing 6px circular dot showing live MQTT updates.

### Buttons & Actuators
- **Primary Control (e.g., "Trigger Aerator", "Deploy Feed")**: Solid oceanic blue (`#0284C7`) or coral accent (`#F97316`) background, white text, 48px minimal touch height, `0.75rem` corner radius, active tactile press state (scale down to 0.98).
- **Secondary / Node Toggle**: `#F1F5F9` surface with `#1E293B` text, 1px border `#E2E8F0`.

### Telemetry Badges & Chips
- **Threshold Filters**: Filter pond telemetry by parameter (All, DO, Temp, pH, Salinity). Inactive chips have `#F1F5F9` fill with `#64748B` typography; active chips switch to `#0F172A` fill with white typography.

### Input Fields & Threshold Setters
- **Layout**: Floating label design with `#F8FAFC` input background and `#E2E8F0` border. On focus, transitions to `#FFFFFF` surface with a `2px` oceanic cyan `#0EA5E9` stroke and non-intrusive outer ring.

### Checkboxes, Radios, and Toggles
- **Aerator / Equipment Switch**: Custom tactile switch; track width 52px, height 30px. Green `#10B981` when MQTT acknowledges activation, soft slate `#CBD5E1` when de-energized. The thumb knob is pure white with a soft depth shadow.

### Mobile Bottom Navigation Bar
- **Design Pattern**: Floating island navigation docked 16px above the device home indicator, spanning 92% screen width.
- **Material**: Translucent white backdrop (`rgba(255, 255, 255, 0.90)`) with `16px` blur and an ultra-fine border `1px solid rgba(226, 232, 240, 0.8)`.
- **Items**: 4 to 5 key destinations (Ponds, Telemetry, Actuators, Alerts, Settings). Active destination renders an oceanic aqua pill indicator beneath the icon, shifting icon color from `#64748B` to `#0284C7`.

### Hardware Status Banner (ESP32 / Gateway Node)
- **Compact Header Component**: Sticky sub-bar showing current MQTT broker connectivity, signal RSSI strength bars, and last synchronization time (`"ESP32-Pond02 • 12ms ago • Ping 99.8%"`).